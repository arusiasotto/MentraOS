(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../node_modules/@mentra/miniapp/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../node_modules/@mentra/miniapp/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../node_modules/@mentra/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../node_modules/@mentra/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../node_modules/@mentra/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["RENDER"] = "miniapp_render";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["SPEAKER_STREAM_OPEN"] = "miniapp_speaker_stream_open";
    MiniappRequestType2["SPEAKER_STREAM_WRITE"] = "miniapp_speaker_stream_write";
    MiniappRequestType2["SPEAKER_STREAM_CLOSE"] = "miniapp_speaker_stream_close";
    MiniappRequestType2["SPEAKER_STREAM_ABORT"] = "miniapp_speaker_stream_abort";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["CALENDAR_LIST_EVENTS"] = "miniapp_calendar_list_events";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["CAMERA_WARM_UP"] = "miniapp_camera_warm_up";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["INVALID_ARGUMENT"] = "INVALID_ARGUMENT";
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["TTS_LOCAL_UNAVAILABLE"] = "TTS_LOCAL_UNAVAILABLE";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../node_modules/@mentra/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../node_modules/@mentra/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../node_modules/@mentra/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.CALENDAR_LIST_EVENTS:
        return { events: [], truncated: false };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
        return { ok: true };
      default:
        return null;
    }
  }

  // ../node_modules/@mentra/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../node_modules/@mentra/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        ...options.transferMethod !== undefined ? { transferMethod: options.transferMethod } : {},
        compress: options.compress ?? "none",
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs,
        iso: options.iso,
        aeExposureDivisor: options.aeExposureDivisor,
        isoCap: options.isoCap,
        noiseReduction: options.noiseReduction,
        edgeEnhancement: options.edgeEnhancement,
        zsl: options.zsl,
        mfnr: options.mfnr,
        ispDigitalGain: options.ispDigitalGain,
        ispAnalogGain: options.ispAnalogGain
      }, options.timeoutMs != null ? { timeoutMs: options.timeoutMs } : undefined);
    }
    async warmUp(options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.CAMERA_WARM_UP,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        exposureTimeNs: options.exposureTimeNs,
        durationMs: options.durationMs ?? 15000,
        zsl: options.zsl,
        mfnr: options.mfnr
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../node_modules/@mentra/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    render(elements, options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RENDER,
        view: options.view ?? "main",
        elements,
        durationMs: options.durationMs
      }).catch((err) => ({
        status: "blocked",
        reason: typeof err === "object" && err !== null && "message" in err ? String(err.message) : String(err)
      }));
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
      this.forceLocalRefCounts = new Map;
    }
    subscribe(stream, handler, options = {}) {
      const isInternal = stream.startsWith("_");
      const forceLocal = options.forceLocal === true && stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`);
      const listener = (data, route) => {
        if (stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`)) {
          if (forceLocal ? route !== "forceLocal" && route !== "all" : route === "forceLocal")
            return;
        }
        handler(data);
      };
      this.emitter.on(stream, listener);
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        const forceLocalBefore = this.forceLocalRefCounts.get(stream) ?? 0;
        const defaultBefore = before - forceLocalBefore;
        if (forceLocal)
          this.forceLocalRefCounts.set(stream, forceLocalBefore + 1);
        if (before === 0 || forceLocal && forceLocalBefore === 0 || !forceLocal && defaultBefore === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, listener);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        const forceLocalCurrent = this.forceLocalRefCounts.get(stream) ?? 0;
        let subscriptionChanged = current <= 1;
        if (current <= 1) {
          this.refCounts.delete(stream);
        } else {
          this.refCounts.set(stream, current - 1);
        }
        if (forceLocal) {
          if (forceLocalCurrent <= 1) {
            this.forceLocalRefCounts.delete(stream);
            subscriptionChanged = true;
          } else {
            this.forceLocalRefCounts.set(stream, forceLocalCurrent - 1);
          }
        } else if (current - forceLocalCurrent <= 1) {
          subscriptionChanged = true;
        }
        if (subscriptionChanged)
          this.sendSubscriptionUpdate();
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.forceLocalRefCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data, transcriptionRoute) {
      this.emitter.emit(stream, data, transcriptionRoute);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data, transcriptionRoute);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => {
        if (stream === MiniappStreamType.LOCATION_UPDATE)
          return { stream: "location_stream", rate: "realtime" };
        const forceLocalRefs = this.forceLocalRefCounts.get(stream) ?? 0;
        if (forceLocalRefs === 0)
          return stream;
        const totalRefs = this.refCounts.get(stream) ?? 0;
        return {
          stream,
          forceLocal: true,
          ...totalRefs > forceLocalRefs ? { includeCloud: true } : {}
        };
      });
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../node_modules/@mentra/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../node_modules/@mentra/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../node_modules/@mentra/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../node_modules/@mentra/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule {
    constructor(session) {
      this.session = session;
    }
    listEvents(options) {
      const startsAt = normalizeCalendarDate(options?.startsAt, "startsAt");
      const endsAt = normalizeCalendarDate(options?.endsAt, "endsAt");
      return this.session.sendRequest({
        type: MiniappRequestType.CALENDAR_LIST_EVENTS,
        startsAt,
        endsAt,
        ...options.limit === undefined ? {} : { limit: options.limit }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }
  function normalizeCalendarDate(value, field) {
    const date = value instanceof Date ? value : new Date(value ?? "");
    if (Number.isNaN(date.getTime()))
      throw new TypeError(`${field} must be a valid Date or ISO 8601 string`);
    return date.toISOString();
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler, options = {}) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler, options));
    }
    forLanguage(language, handler, options = {}) {
      const langs = Array.isArray(language) ? language : [language];
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler, options));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      this.currentConfig = { ...config };
      this.session.sendOneShot({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...config }
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${source}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../node_modules/@mentra/miniapp/dist/modules/speaker.js
  var SPEAKER_WRITE_CHUNK_BYTES = 256 * 1024;
  var SPEAKER_WRITE_CHUNK_B64 = Math.floor(SPEAKER_WRITE_CHUNK_BYTES / 6) * 8;
  class SpeakerStreamWriter {
    constructor(session, streamId) {
      this.session = session;
      this.streamId = streamId;
      this.settled = false;
      this.writeChain = Promise.resolve();
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      if (bytes.byteLength === 0)
        throw new Error("PCM chunk cannot be empty");
      if (bytes.byteLength % 2 !== 0)
        throw new Error("PCM chunk must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < bytes.length; off += SPEAKER_WRITE_CHUNK_BYTES) {
          last = await this.send(bytesToBase64(bytes.subarray(off, off + SPEAKER_WRITE_CHUNK_BYTES)));
        }
        return last;
      });
    }
    async writeBase64(b64) {
      this.assertOpen();
      if (b64.length === 0 || b64.length % 4 !== 0)
        throw new Error("PCM base64 must be non-empty and padded");
      const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
      const decodedBytes = b64.length / 4 * 3 - padding;
      if (decodedBytes % 2 !== 0)
        throw new Error("PCM base64 must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < b64.length; off += SPEAKER_WRITE_CHUNK_B64) {
          last = await this.send(b64.slice(off, off + SPEAKER_WRITE_CHUNK_B64));
        }
        return last;
      });
    }
    async close() {
      this.assertOpen();
      this.settled = true;
      await this.writeChain;
      const res = await this.session.sendRequest({ type: MiniappRequestType.SPEAKER_STREAM_CLOSE, streamId: this.streamId }, { timeoutMs: 0 });
      return res ?? {};
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_ABORT,
        streamId: this.streamId
      });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("SpeakerStreamWriter is already closed/aborted");
    }
    async send(base64) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_WRITE,
        streamId: this.streamId,
        base64
      });
      return res ?? { bufferedMs: 0 };
    }
    enqueueWrite(operation) {
      const result = this.writeChain.then(operation);
      this.writeChain = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
  }

  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      const normalized = Array.isArray(text) ? text.map((sentence) => sentence.trim()).filter(Boolean) : text.trim();
      if (Array.isArray(normalized) && normalized.length === 0 || normalized === "") {
        throw { code: MiniappErrorCode.INTERNAL, message: "speak requires at least one non-empty sentence" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text: normalized,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false,
          forceLocal: options.forceLocal ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    async createStream(options = {}) {
      if (options.volume !== undefined && (!Number.isFinite(options.volume) || options.volume < 0 || options.volume > 1)) {
        throw new RangeError("speaker stream volume must be between 0 and 1");
      }
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_OPEN,
        sampleRate: options.sampleRate ?? 16000,
        channels: options.channels ?? 1,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? true
      });
      return new SpeakerStreamWriter(this.session, res.streamId);
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../node_modules/@mentra/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../node_modules/@mentra/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.camera = new CameraModule(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler, options = {}) {
      return this.events.subscribe(streamType, handler, options);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data, payload.transcriptionRoute);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../node_modules/@mentra/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/background/lib/ai-config.ts
  var DEFAULT_BACKEND_URL = "https://general.dev.tpa.ngrok.app";
  function backendUrl() {
    const fromEnv = "https://web-17349-95380467-efyhfdt0.onporter.run"?.trim();
    return (fromEnv || DEFAULT_BACKEND_URL).replace(/\/+$/, "");
  }
  var BACKEND_ROUTES = {
    agent: () => `${backendUrl()}/api/agent`,
    agentDeviceCommandResults: () => `${backendUrl()}/api/agent/device-command-results`,
    agentFollowUps: () => `${backendUrl()}/api/agent/follow-ups`,
    agentFollowUpAck: (id) => `${backendUrl()}/api/agent/follow-ups/${encodeURIComponent(id)}/ack`,
    agentWake: () => `${backendUrl()}/api/agent/wake`,
    settings: () => `${backendUrl()}/api/settings`,
    classify: () => `${backendUrl()}/api/classify`,
    search: () => `${backendUrl()}/api/search`
  };

  // src/background/agent/MentraAgent.ts
  async function generateResponse(options) {
    const { session, requestId, query, photos, photoUrls, model, sessionId, context } = options;
    console.log(`\uD83E\uDD16 Requesting response for: "${query.slice(0, 50)}${query.length > 50 ? "..." : ""}"`);
    console.log(`   Request id: ${requestId}`);
    console.log(`   Photos: ${photos?.length || 0}, hasPhotos: ${context.hasPhotos}, History: ${context.conversationHistory.length}`);
    const url = BACKEND_ROUTES.agent();
    console.log(`\uD83C\uDF10 POST ${url}`);
    let res;
    try {
      res = await session.auth.fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requestId, query, photos, photoUrls, model, sessionId, context })
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      console.error(`❌ agent fetch threw before response: ${message}`);
      throw new Error(`agent fetch failed: ${message}`);
    }
    if (!res.ok) {
      const raw = await res.text().catch(() => "");
      let parsed = {};
      try {
        parsed = JSON.parse(raw);
      } catch {}
      console.error(`❌ agent backend HTTP ${res.status} (auth=${res.status === 401 ? "rejected" : "ok"})`);
      throw new Error(`agent backend ${res.status}${parsed.error ? `: ${parsed.error}` : ""}`);
    }
    const body = await res.json();
    if (body.error)
      throw new Error(body.error);
    if (!body.response?.trim()) {
      throw new Error("agent backend returned an empty response");
    }
    const toolCalls = body.toolCalls ?? 0;
    const sources = body.sources ?? [];
    if (sources.length > 0)
      options.onToolCall?.("search");
    console.log(`✅ Response received (${(body.response ?? "").length} chars, ${toolCalls} tool calls, ${sources.length} sources` + `${body.followUpsPending ? ", follow-ups pending" : ""})`);
    return {
      response: body.response.trim(),
      toolCalls,
      ...sources.length > 0 ? { sources } : {},
      ...body.followUpsPending ? { followUpsPending: true } : {},
      ...body.actions?.length ? { actions: body.actions } : {},
      ...body.deviceCommands?.length ? { deviceCommands: body.deviceCommands } : {},
      ...body.deviceCommandBatchId ? { deviceCommandBatchId: body.deviceCommandBatchId } : {}
    };
  }
  async function finalizeDeviceCommands(session, batchId, results) {
    const res = await session.auth.fetch(BACKEND_ROUTES.agentDeviceCommandResults(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ batchId, results })
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok || !body.response?.trim()) {
      throw new Error(body.error || `device result finalization failed (${res.status})`);
    }
    return body.response.trim();
  }
  async function fetchFollowUps(session, waitSeconds) {
    const url = `${BACKEND_ROUTES.agentFollowUps()}?wait=${Math.max(0, Math.floor(waitSeconds))}`;
    try {
      const res = await session.auth.fetch(url, { method: "GET" });
      if (!res.ok) {
        console.warn(`\uD83E\uDD1D follow-ups fetch HTTP ${res.status}`);
        return null;
      }
      const data = await res.json();
      return {
        followUps: Array.isArray(data.followUps) ? data.followUps.filter((f) => f && f.id && f.reply) : [],
        working: typeof data.working === "number" ? data.working : 0
      };
    } catch (err) {
      console.warn(`\uD83E\uDD1D follow-ups fetch error:`, err instanceof Error ? err.message : err);
      return null;
    }
  }
  async function ackFollowUp(session, id, sessionId) {
    const url = BACKEND_ROUTES.agentFollowUpAck(id) + (sessionId ? `?sessionId=${encodeURIComponent(sessionId)}` : "");
    for (let attempt = 0;attempt < 2; attempt++) {
      try {
        const res = await session.auth.fetch(url, { method: "POST" });
        if (res.ok)
          return true;
      } catch (err) {
        console.warn(`\uD83E\uDD1D follow-up ack error:`, err instanceof Error ? err.message : err);
      }
      await new Promise((r) => setTimeout(r, 1500));
    }
    return false;
  }
  function wakeGigaAgent(session) {
    session.auth.fetch(BACKEND_ROUTES.agentWake(), { method: "POST" }).catch(() => {});
  }

  // src/shared/types.ts
  var MODEL_OPTIONS = [
    { id: "qwen-3.8-27b", label: "Qwen 3.8 27B", provider: "Alibaba", inferenceProvider: "cerebras", visionCapable: true },
    { id: "google/gemini-3.1-flash-lite-preview", label: "Gemini 3.1 Flash Lite", provider: "Google", inferenceProvider: "openrouter", visionCapable: true },
    { id: "google/gemini-3.5-flash", label: "Gemini 3.5 Flash", provider: "Google", inferenceProvider: "openrouter", visionCapable: true },
    { id: "anthropic/claude-haiku-4.5", label: "Claude Haiku 4.5", provider: "Anthropic", inferenceProvider: "openrouter", visionCapable: true },
    { id: "openai/gpt-5-mini", label: "GPT-5 Mini", provider: "OpenAI", inferenceProvider: "openrouter", visionCapable: true },
    { id: "x-ai/grok-4.3", label: "Grok 4.3", provider: "xAI", inferenceProvider: "openrouter", visionCapable: true },
    { id: "deepseek/deepseek-v4-flash", label: "DeepSeek V4 Flash", provider: "DeepSeek", inferenceProvider: "openrouter", visionCapable: false }
  ];
  var DEFAULT_MODEL_ID = MODEL_OPTIONS[0].id;
  var DEFAULT_SETTINGS = {
    readingSpeed: "normal",
    theme: "dark",
    chatHistoryEnabled: false,
    model: DEFAULT_MODEL_ID,
    debug: { unlocked: false, transcriptOverlay: false }
  };
  var DEFAULT_CLOUD_SETTINGS = {
    includePhotosWithQueries: true,
    gigaAgentEnabled: false,
    composioEnabled: false
  };
  function readingSpeed(value) {
    return value === "slow" || value === "fast" ? value : "normal";
  }

  // src/background/lib/cloud-settings.ts
  function normalizeCloudSettings(data) {
    const d = data ?? {};
    return {
      ...DEFAULT_CLOUD_SETTINGS,
      ...typeof d.includePhotosWithQueries === "boolean" ? { includePhotosWithQueries: d.includePhotosWithQueries } : {},
      ...typeof d.gigaAgentEnabled === "boolean" ? { gigaAgentEnabled: d.gigaAgentEnabled } : {},
      ...typeof d.composioEnabled === "boolean" ? { composioEnabled: d.composioEnabled } : {}
    };
  }
  async function fetchCloudSettings(session) {
    try {
      const res = await session.auth.fetch(BACKEND_ROUTES.settings(), { method: "GET" });
      if (!res.ok) {
        console.warn(`⚙️ cloud settings fetch HTTP ${res.status}`);
        return null;
      }
      return normalizeCloudSettings(await res.json());
    } catch (err) {
      console.warn(`⚙️ cloud settings fetch error:`, err instanceof Error ? err.message : err);
      return null;
    }
  }
  async function updateCloudSettings(session, patch) {
    const res = await session.auth.fetch(BACKEND_ROUTES.settings(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch)
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error ?? `settings update failed (HTTP ${res.status})`);
    }
    return normalizeCloudSettings(await res.json());
  }

  // src/background/vendor/display/measurer/script-detection.ts
  var SCRIPT_RANGES = {
    cjk: [
      [19968, 40959],
      [13312, 19903],
      [131072, 173791],
      [173824, 177983],
      [177984, 178207],
      [63744, 64255]
    ],
    hiragana: [[12352, 12447]],
    katakana: [
      [12448, 12543],
      [12784, 12799]
    ],
    korean: [
      [44032, 55215],
      [4352, 4607],
      [12592, 12687],
      [43360, 43391],
      [55216, 55295]
    ],
    cyrillic: [
      [1024, 1279],
      [1280, 1327]
    ],
    numbers: [[48, 57]],
    punctuation: [
      [32, 47],
      [58, 64],
      [91, 96],
      [123, 126]
    ],
    arabic: [[1536, 1791]],
    hebrew: [[1424, 1535]],
    thai: [[3584, 3711]],
    emoji: [
      [128512, 128591],
      [127744, 128511],
      [128640, 128767],
      [127456, 127487],
      [9728, 9983],
      [9984, 10175],
      [65024, 65039],
      [129280, 129535]
    ]
  };
  function inRanges(codePoint, ranges) {
    for (const [start, end] of ranges) {
      if (codePoint >= start && codePoint <= end) {
        return true;
      }
    }
    return false;
  }
  function detectScript(char) {
    if (!char || char.length === 0) {
      return "latin";
    }
    const codePoint = char.codePointAt(0);
    if (codePoint === undefined) {
      return "latin";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cjk)) {
      return "cjk";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.hiragana)) {
      return "hiragana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.katakana)) {
      return "katakana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.korean)) {
      return "korean";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cyrillic)) {
      return "cyrillic";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.numbers)) {
      return "numbers";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.punctuation)) {
      return "punctuation";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.arabic) || inRanges(codePoint, SCRIPT_RANGES.hebrew) || inRanges(codePoint, SCRIPT_RANGES.thai) || inRanges(codePoint, SCRIPT_RANGES.emoji)) {
      return "unsupported";
    }
    return "latin";
  }
  function isUniformWidthScript(char) {
    const script = detectScript(char);
    return script === "cjk" || script === "hiragana" || script === "katakana" || script === "korean" || script === "cyrillic";
  }

  // src/background/vendor/display/measurer/TextMeasurer.ts
  class TextMeasurer {
    profile;
    charCache = new Map;
    constructor(profile) {
      this.profile = profile;
      this.buildCharCache();
    }
    buildCharCache() {
      const { glyphWidths, renderFormula } = this.profile.fontMetrics;
      for (const [char, glyphWidth] of glyphWidths.entries()) {
        const renderedWidth = renderFormula(glyphWidth);
        this.charCache.set(char, renderedWidth);
      }
    }
    measureText(text) {
      if (!text || text.length === 0) {
        return 0;
      }
      let totalWidth = 0;
      for (const char of text) {
        totalWidth += this.measureChar(char);
      }
      return totalWidth;
    }
    measureTextDetailed(text) {
      if (!text || text.length === 0) {
        return {
          text: "",
          totalWidthPx: 0,
          charCount: 0,
          chars: []
        };
      }
      const chars = [];
      let totalWidth = 0;
      for (const char of text) {
        const script = detectScript(char);
        const widthPx = this.measureChar(char);
        const fromGlyphMap = this.profile.fontMetrics.glyphWidths.has(char);
        chars.push({
          char,
          widthPx,
          script,
          fromGlyphMap
        });
        totalWidth += widthPx;
      }
      return {
        text,
        totalWidthPx: totalWidth,
        charCount: chars.length,
        chars
      };
    }
    measureChar(char) {
      if (!char || char.length === 0) {
        return 0;
      }
      const cached = this.charCache.get(char);
      if (cached !== undefined) {
        return cached;
      }
      const width = this.calculateCharWidth(char);
      this.charCache.set(char, width);
      return width;
    }
    calculateCharWidth(char) {
      const { fontMetrics } = this.profile;
      const { uniformScripts, fallback, renderFormula, glyphWidths } = fontMetrics;
      const glyphWidth = glyphWidths.get(char);
      if (glyphWidth !== undefined) {
        return renderFormula(glyphWidth);
      }
      const script = detectScript(char);
      switch (script) {
        case "cjk":
          return uniformScripts.cjk;
        case "hiragana":
          return uniformScripts.hiragana;
        case "katakana":
          return uniformScripts.katakana;
        case "korean":
          return uniformScripts.korean;
        case "cyrillic":
          return uniformScripts.cyrillic;
      }
      return fallback.latinMaxWidth;
    }
    getGlyphWidth(char) {
      return this.profile.fontMetrics.glyphWidths.get(char);
    }
    fitsInWidth(text, maxWidthPx) {
      return this.measureText(text) <= maxWidthPx;
    }
    charsThatFit(text, maxWidthPx, startIndex = 0) {
      if (!text || startIndex >= text.length) {
        return 0;
      }
      let currentWidth = 0;
      let count = 0;
      const chars = Array.from(text).slice(startIndex);
      for (const char of chars) {
        const charWidth = this.measureChar(char);
        if (currentWidth + charWidth > maxWidthPx) {
          break;
        }
        currentWidth += charWidth;
        count++;
      }
      return count;
    }
    getPixelOffset(text, index) {
      if (!text || index <= 0) {
        return 0;
      }
      const chars = Array.from(text).slice(0, index);
      let offset = 0;
      for (const char of chars) {
        offset += this.measureChar(char);
      }
      return offset;
    }
    detectScript(char) {
      return detectScript(char);
    }
    isUniformWidth(char) {
      return isUniformWidthScript(char);
    }
    getProfile() {
      return this.profile;
    }
    getDisplayWidthPx() {
      return this.profile.displayWidthPx;
    }
    getMaxLines() {
      return this.profile.maxLines;
    }
    getMaxPayloadBytes() {
      return this.profile.maxPayloadBytes;
    }
    getByteSize(text) {
      return new TextEncoder().encode(text).length;
    }
    getHyphenWidth() {
      return this.measureChar("-");
    }
    getSpaceWidth() {
      return this.measureChar(" ");
    }
    clearCache() {
      this.charCache.clear();
      this.buildCharCache();
    }
  }

  // src/background/vendor/display/profiles/g1.ts
  var G1_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var G1_PROFILE = {
    id: "even-realities-g1",
    name: "Even Realities G1",
    displayWidthPx: 576,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  var G1_PROFILE_LEGACY = {
    id: "even-realities-g1-legacy",
    name: "Even Realities G1 (Legacy Client Compatibility)",
    displayWidthPx: 420,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };

  // src/background/vendor/display/profiles/g2.ts
  var G2_CYRILLIC_RENDERED_PX = {
    а: 12,
    б: 12,
    в: 12,
    г: 9,
    д: 12,
    е: 11,
    ё: 11,
    ж: 13,
    з: 11,
    и: 12,
    й: 12,
    к: 10,
    л: 12,
    м: 14,
    н: 12,
    о: 11,
    п: 11,
    р: 12,
    с: 11,
    т: 11,
    у: 11,
    ф: 13,
    х: 11,
    ц: 12,
    ч: 12,
    ш: 14,
    щ: 15,
    ъ: 13,
    ы: 14,
    ь: 12,
    э: 11,
    ю: 14,
    я: 11,
    А: 13,
    Б: 13,
    В: 13,
    Г: 10,
    Д: 15,
    Е: 12,
    Ё: 12,
    Ж: 17,
    З: 12,
    И: 14,
    Й: 14,
    К: 13,
    Л: 14,
    М: 16,
    Н: 13,
    О: 14,
    П: 13,
    Р: 13,
    С: 13,
    Т: 12,
    У: 13,
    Ф: 16,
    Х: 13,
    Ц: 13,
    Ч: 12,
    Ш: 16,
    Щ: 17,
    Ъ: 15,
    Ы: 16,
    Ь: 13,
    Э: 13,
    Ю: 17,
    Я: 13
  };
  var G2_PROFILE = {
    ...G1_PROFILE,
    id: "even-realities-g2",
    name: "Even Realities G2",
    maxLines: 8,
    lineHeightPx: 40,
    fontMetrics: {
      ...G1_PROFILE.fontMetrics,
      glyphWidths: new Map([
        ...G1_PROFILE.fontMetrics.glyphWidths,
        ...Object.entries(G2_CYRILLIC_RENDERED_PX).map(([char, renderedPx]) => [char, renderedPx / 2 - 1])
      ])
    }
  };

  // src/background/vendor/display/profiles/z100.ts
  var Z100_GLYPH_WIDTHS = {
    " ": 5,
    "!": 6,
    '"': 9,
    "#": 14,
    $: 12,
    "%": 17,
    "&": 15,
    "'": 5,
    "(": 6,
    ")": 6,
    "*": 12,
    "+": 12,
    ",": 6,
    "-": 7,
    ".": 6,
    "/": 8,
    "0": 12,
    "1": 12,
    "2": 12,
    "3": 12,
    "4": 12,
    "5": 12,
    "6": 12,
    "7": 12,
    "8": 12,
    "9": 12,
    ":": 6,
    ";": 6,
    "<": 12,
    "=": 12,
    ">": 12,
    "?": 9,
    "@": 19,
    A: 13,
    B: 14,
    C: 13,
    D: 15,
    E: 12,
    F: 11,
    G: 15,
    H: 16,
    I: 7,
    J: 6,
    K: 13,
    L: 11,
    M: 19,
    N: 16,
    O: 16,
    P: 13,
    Q: 16,
    R: 13,
    S: 12,
    T: 12,
    U: 15,
    V: 13,
    W: 20,
    X: 12,
    Y: 12,
    Z: 12,
    "[": 7,
    "\\": 8,
    "]": 7,
    "^": 12,
    _: 9,
    "`": 6,
    a: 12,
    b: 13,
    c: 10,
    d: 13,
    e: 12,
    f: 7,
    g: 13,
    h: 13,
    i: 5,
    j: 5,
    k: 11,
    l: 5,
    m: 20,
    n: 13,
    o: 13,
    p: 13,
    q: 13,
    r: 9,
    s: 10,
    t: 8,
    u: 13,
    v: 11,
    w: 17,
    x: 11,
    y: 11,
    z: 10,
    "{": 8,
    "|": 12,
    "}": 8,
    "~": 12
  };
  var Z100_PROFILE = {
    id: "vuzix-z100",
    name: "Vuzix Z100",
    displayWidthPx: 390,
    maxLines: 7,
    maxPayloadBytes: 512,
    bleChunkSize: 180,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(Z100_GLYPH_WIDTHS)),
      defaultGlyphWidth: 12,
      renderFormula: (glyphWidth) => glyphWidth,
      uniformScripts: {
        cjk: 21,
        hiragana: 21,
        katakana: 21,
        korean: 21,
        cyrillic: 14
      },
      fallback: {
        latinMaxWidth: 20,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };

  // src/background/vendor/display/profiles/nex.ts
  var NEX_GLYPH_WIDTHS = {
    " ": 5,
    "!": 5,
    '"': 8,
    "#": 14,
    $: 12,
    "%": 18,
    "&": 14,
    "'": 5,
    "(": 7,
    ")": 7,
    "*": 8,
    "+": 12,
    ",": 5,
    "-": 8,
    ".": 5,
    "/": 7,
    "0": 12,
    "1": 12,
    "2": 12,
    "3": 12,
    "4": 12,
    "5": 12,
    "6": 12,
    "7": 12,
    "8": 12,
    "9": 12,
    ":": 6,
    ";": 6,
    "<": 12,
    "=": 12,
    ">": 12,
    "?": 9,
    "@": 18,
    A: 12,
    B: 13,
    C: 12,
    D: 13,
    E: 11,
    F: 11,
    G: 14,
    H: 14,
    I: 8,
    J: 10,
    K: 12,
    L: 10,
    M: 16,
    N: 14,
    O: 14,
    P: 12,
    Q: 14,
    R: 13,
    S: 11,
    T: 11,
    U: 13,
    V: 12,
    W: 18,
    X: 12,
    Y: 11,
    Z: 11,
    "[": 6,
    "\\": 7,
    "]": 6,
    "^": 12,
    _: 11,
    "`": 12,
    a: 11,
    b: 11,
    c: 10,
    d: 11,
    e: 11,
    f: 6,
    g: 11,
    h: 11,
    i: 5,
    j: 5,
    k: 10,
    l: 5,
    m: 17,
    n: 11,
    o: 11,
    p: 11,
    q: 11,
    r: 7,
    s: 10,
    t: 7,
    u: 11,
    v: 10,
    w: 15,
    x: 10,
    y: 10,
    z: 9,
    "{": 7,
    "|": 6,
    "}": 7,
    "~": 12
  };
  var NEX_PROFILE = {
    id: "mentra-nex",
    name: "Mentra Nex",
    displayWidthPx: 480,
    displayHeightPx: 220,
    maxLines: 8,
    maxPayloadBytes: 450,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(NEX_GLYPH_WIDTHS)),
      defaultGlyphWidth: 16,
      renderFormula: (glyphWidth) => glyphWidth,
      uniformScripts: {
        cjk: 20,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };

  // src/background/lib/answer-pages.ts
  function supportsPagingInput(caps) {
    const button = caps?.button;
    return Boolean(button?.buttons?.some(({ events }) => Array.isArray(events) && events.includes("SWIPE_UP") && events.includes("SWIPE_DOWN")));
  }
  function displayProfile(caps) {
    const model = String(caps?.modelName ?? "").toLowerCase();
    if (model.includes("g2"))
      return G2_PROFILE;
    if (model.includes("z100"))
      return Z100_PROFILE;
    if (model.includes("nex") || model.includes("mentra display"))
      return NEX_PROFILE;
    return G1_PROFILE;
  }
  function wrap(text, measure, width) {
    const lines = [];
    for (const paragraph of text.split(`
`)) {
      let chars = Array.from(paragraph.trim());
      if (!chars.length)
        lines.push("");
      while (chars.length) {
        let end = 0;
        let pixels = 0;
        let space = -1;
        while (end < chars.length && pixels + measure.measureChar(chars[end]) <= width) {
          if (/\s/.test(chars[end]))
            space = end;
          pixels += measure.measureChar(chars[end]);
          end++;
        }
        if (end < chars.length && space > 0)
          end = space;
        end = Math.max(1, end);
        lines.push(chars.slice(0, end).join("").trimEnd());
        chars = chars.slice(end);
        while (chars.length && /\s/.test(chars[0]))
          chars.shift();
      }
    }
    return lines;
  }
  function paginateAnswer(text, caps) {
    const profile = displayProfile(caps);
    const measurer = new TextMeasurer(profile);
    const w = Math.min(caps?.display?.width ?? profile.displayWidthPx, profile.displayWidthPx);
    const h = caps?.display?.height ?? profile.displayHeightPx ?? 288;
    const rows = Math.min(profile.maxLines, profile.lineHeightPx ? Math.floor(h / profile.lineHeightPx) : profile.maxLines);
    const lines = wrap(text, measurer, Math.max(24, w - 12));
    const bodyRows = Math.max(1, rows - 1);
    const pages = [];
    let start = 0;
    while (start < lines.length) {
      let end = start;
      const body = [];
      while (end < lines.length && body.length < bodyRows) {
        const line = lines[end] || "​";
        if (body.length && measurer.getByteSize([...body, line].join(`
`)) > profile.maxPayloadBytes - 32)
          break;
        body.push(line);
        end++;
      }
      pages.push({ text: body.join(`
`), start, end });
      if (end === lines.length)
        break;
      start = end - start > 1 ? end - 1 : end;
    }
    return { pages, lines, box: { x: 0, y: 0, w, h } };
  }
  function pageDwellMs(text, speed) {
    const cjk = text.match(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/gu)?.length ?? 0;
    const words = text.replace(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/gu, " ").trim().split(/\s+/).filter(Boolean).length;
    const wpm = { slow: 120, normal: 160, fast: 210 }[speed];
    return Math.max(6000, Math.ceil((words + cjk / 2) / wpm * 60000) + 2000);
  }

  // src/background/lib/sounds.ts
  var START_SOUND_URL = "data:audio/mpeg;base64,//uQZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAAVAAATIAAvLy8vPj4+Pj5HR0dHR05OTk5OVlZWVl9fX19fZmZmZmZubm5ubnd3d3d+fn5+fpaWlpaWpaWlpaWvr6+vurq6urrExMTExM7Ozs7O4+Pj4+7u7u7u9PT09PT6+vr6+v////8AAAAUTEFNRTMuMTAwBJgAAAAAAAAAABUgJAZTTQABpAAAEyBjVPN+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vQZAAAAXsAWu0AAAgeQAq9oAABFVUjcfmsAEE5ki4/EtBIKAAjkkfuuAAIDQfB8ufeD4fdg+8EAwt4fUCDuUBA/y4Pl8EHYOHP+oMQQBAEAQMjSA2LVPgMACoEDhQMOlwQc4uDgY4Icufgg7//g+D4gCIrqku8KpiGnblR8VoADxIiRpZaHA4RxZDMEbVNTVmEiUErTlqKXrFftMdYUME9r1rwWIsQRnet62rQezFllZoU7D8ebSvLXfTD7hFWJyOTNba7Sy2AWuvtR400AX3EpPlmMRvspnc5bd519eftrkCZw25eWWcOxqVOVRfjjj9WgsQ3G5BL87kopH91WlNBK5Vat/zX5d/W7f/UsYfzn7lU3Y5Xs7pgu7rEAEgsUwp0JIEd3lYdAAAAvelyf2WlSsgfvCVkFPCbouSwmpcC8A7XVC2BsnbazNR9SKnfxhkrmS2rRprTTpcxJLDU4QSAgkdLVPsKOqEiAABlNppEP8yAJU+zUjghR1QAQ7e2aZ6ZDHoel2VPFdIsTSiZGyzKpKiiiSI9SgDdC3Dyf/ptdaSzXZRsktkUUHZFSK26Vb/rossxNUjaCrAC1lT2Z4AAABOjuIAtmE448iNJJVunEqfiogBkxtDwBvYABQyocDnwpEsAJ7prRg0fSIgvO2hKusgRtPnuUWV1LRE1CVFu/nyP79i3ekqKwW17+7dZv75vlANSF1gB6AIHhy1DeQnET4G/kSAANVZ3jP8AAAyB0qhwNgS7w+hDNEdrvPSCgPt8raqtRdm7J4vdcu3K58ui2x/F3CJGPWHipIAG9AA0AAAAKkCwc9CAAA0RDO9wHbVUGQp4dhgX59QADzBfc4QGSsWzSjS9Ozrlau7H7kcEEFVCrlkcArzt60YZ2lADZ3aGX/AAACPtXZYcwXhS6ZcIw+VHmEZMKWyQmSWqa6P7mer2n6zDRpkCro5wHYAAAAAAAF2uQBzTfTbgOs1FYx2IOIV00wCXboRSHh5A6B1STUNaqXV9c2dunIjJmvqUjz6CeAT6lEWAB33/b/gAAQapkMATwRjAIRu4GKos3uORCo2aGMZjtNsp9T7mBvQjZkVF31r69I9+tEKwAAAAAAAI0//7YGTsABJ5MNh/aaAIGkHrb+CYAQfgTVftJadoSoIsvDEYBNedAB3/zxpsJIEMHhGBAbVAhGKEExgFguhxtEcN/3DBHhEeSMYhBRTZpWAFgFrLqkAERWWIS8AAACFtITLOHILC4FcWsXTPiMIis7RZmQUdY/292/A46V0C3AAAAAAAAjSaaVAA1d4d2u4EnYm1g9yEQOkBYGAucYRig0aQE4lUz0zXex0vSMh61uy9PAfcBjewGlAAaHWHfcAAABSSwrAgHXBKgO1iZwG10RCdRDCCtJoGS19e1FY+fPxm2C+AdgAAAAAAAHMs4A3X7/8AM3RuWycZYokUmhvK8/YZW1o4gP/7MGT/AXGyE9V5m2AYDKALjgAAAQW0UVXtMGVgHAAueAAABcXyOUm2sSfQQMy2rAeAGd0M9UABRYdnfwAAAAmxgp/GD6Qgi+w+wX7DIEmKJTENAktnWUYXVwQoAAAAAAAC1lFACaJiIj8AL3ZQvs38hVkMiG2Cc2OCYAs0JgQJWpR5klZayAafVVywGczQAAT4yGClmyAAVod3ff/7IGT/AXFxE1V7ekiaCgAbrgAAAUVwT1OtpWcoGAAuuAAABcAAAC4sAnQfToq2gAbSkkFyUSyMYaor+YmBhACcSF3mfqKKAJ9DgAAAAAGjkobDICMO9VcxITIAAAAAAADPkT4aDjNHByg49ITbqp8Udnm6SRlLKv+tnYkEMwBQAAD/+yBk+QNxig7Va0wxOguAG34EAAFFDFFUjSRlIBQAbjgAAAUAAAAAAAAAsVQ5z9KAFcz+7eAAAIY+XpkPkqy1VKeVzM5KWWsTQAgdMdrk8iD2AAAAAAAEM9vWUAE4d3Zrtwt931gAvdYJBWRU0Y4/EtyryuJ09tz7Su7TuM7p3rQF//swZPKBcTwT1XtJGcgLwBt+BAABRSRPVe0kZSAYgG64AAAFgMBhYWmTJkwAAAghGdosmTu/2gmTJk5A6mgqgDH7PSQPYD2GahQ4UYpnsZo1cN1YRUIRIAW7hJkpVTqzkhwORh0CtSL9uw2lYkKrGNJEBpO/gQ9CYv6KoKOIytAizMQEZepw83ZbQSBliTDEkaILaSvhkdI/tjmY//sgZP0BcVcT1XtJMTgKQBueAAABRIRNVa0wZSgYgi34EIwMci4yxSx40Aq7nBeui1vfbHJfA+uQJNySCJuVxODv////kdiVxenz687yxOJT+Eo//////h+aljuXu4YWJC7T0zePIvUq///////9jfd9///P4zO2oTPy+X2qSmOf///7IGT8ATEeCVV5+UgaCgAbfgAAAUToOVXspMToLAAteAAABZcVNkAik0CwBm8s8mziyBERkFQGBwBmtIkQjO7wHy3BnwJ0WZC50kwJwoo4EE2LhFBSBEGTTQTTdp0t6bpvrIm5umyX/mROuXCJp6H/07fQt//PO4vd/9JlVcEZhDL/+zBk+wABRhPVfWRgCAygG36gAAEE+CNn2YAACEsALfsAAACykgEQFADARt1KpWUCoCrPdXINIqikKLiHA09BTjlaGnRJtFBUJAF0GgVBUSuzAQMJFJY0EApJcwZF38NKNoUgNAq8Li7aBT91Z202nS95i3JQJXUiQdWXAblt3EKocpEiE37SxMCjSZYOnbhLI8sDQ5T/klPwV4H/+yBk/wEw+wrb9zxgCgugC07gAAFHuIdT9YMAIDYCbHqMAARDWoUitfyxY9NrO5ZgBWaJCb2t3ADARjkGU5Mg1mYM4iTJSVlUl6W3HFkQiWM5zQqRImgZAQNAY8egqdocoGgVDXEWCuCroaLA0DTj3LQVBURBR5V1bpJsRHodwaBp//uQZPKABbtPW35jBABTxvvfx8EgCmw/e/z2ACDNhS8/kmAE9qqqBGp1du6UBFRQ8d5HDcFWmT518TEvg19uup6A6e+lAGPfxFhpAIAB3lgf+loAf2Q1Wowa/AJwPUApoPasM8S7LK9bbwmTPqpIRS2lJIqd73+z0eXlm9SlQ0zr/mZP//wwJ520jJLOqCACwzyfAAI93OIjwKxb8qm8rKo+h1b//wKAABWYPcBgAMphm+kHL2GmTkh3kcb0R6NT2fWcMs+4uLUc1Yd5edpAKNFRrYx7Lb0Nf//////+Kelcg7gAGAAAFlZNIUGeZ9KgAACxUhuAJDP1WWYuCIrrIQYYhkeiSRpUoPrB4UqcoIQifLP4YVw/1mHIPSV////3U8AE8AA6tCi0F/1UKkAwAVZ4BcAcACHL9Ru7uM5MaUbDMUODAvWun3bJt+PXYdJKoaRTcxAUB0S9P///////76kDdQWwJAUGSORAEAAAXAAAAB5lhhgkFP5CboBAAWFYHwBQAEgFKs2HPA1wwNBuYipdU9ZWZlttrYvXFpIzUp6C//tgZOgAEqYR3vlvSCglAJtNBCIDCEy9Z+w8SaBnl6v8UArct6SBNg6GvmbI////////PmkQBQYR1WAYAABXoQh7P6KgAAFmeA34EAAisEYtrMRwdkJXGBBQNBnTc0bN3DGokHUVSHeehjYXwjwx3Bymvsvf6///////zC4FkSAGkABeAAAAHe80QsRZGbo3BJUBgARE0E4AoAEmw7J32hoQ8IiCgdoJEZK5pIzKCrKx0Z0ZkLAujaSyC9X////////5kfftAQAAPUIlYa3/m4IgAIlpB3gEACParq4gpm4sGVyEJErB5ZyiSQiDfk3LSKUyoM4hlWIC2hT0rv62///9mWAQ//tAZO2BMcIv1utPEmgPoMueBCITBihHX+0l6SAwAG64EAAEAB4AAAAewcDmr/rlAl0ABd8FfhAAJqU0DC77bkO4lKFw5U3YZc13Z3iLPKx3o3KYRGiTC1Kdnj0pvz5Dq5P/z////v6BBLTgaAChMAD4AlICSML4ocAb96wxnKAAFEAF8oABN2fZ0xsIDmA1t3MoGeF+5LI4IWIrAX3MKBXovNAOkXLn8ls2vtH13xwEboAZ4Un/+0Bk84Ax3zBXeyxqShHgyv8EQwcHaL9Z7LzpYCsALjgAAATw7bO592xc1pEHRFY3cAk9kgsm+XNsL4hBfFA9JWZa4NA6MMCM3/TXvq+8U1mG/dN8ZsYVe5ogSQFWHOhQLABEICBnAhgvFDJfT7+XuETSNxe0Sv0/d0rd3d4cXc+CAIBZ0H6oPvfhgUgL6YA/iAAaloJHAMzwIgfHuIHOHGU/1D4H+0/0Z3pO53oSpznPJ+RTgP/7QGTygDHQL1b7TypoE6IK/xwDZQZsv1/sJakgLAKrkBMIhAhgZwijAANEAAB28YANtSaWGs/E+h5TK671StrJCW62t811i93W5oMOLYFWVmHe7/7dhpl790dfgrenXavk3zM+/fzvtZHlsm1L3idqcnpp58mOU6VL66f/7gAgA4QzGb4AACqQIWowSBqs0rX/EQCxw8azliupbjxL//IvcqqXIANncwb+CAAVUFeNfSHpFBi4//tAZPWAEZMQ1fspejgQAJrdBCYDB0C/Vay8SahOgmt8AJgM7e6uiZnz+IYU3UpZa4PkJIcrVKCREkecbQxwdWMh3/9BYVGPDIWqJE3dBwAOAAaqQUmyeBo87Wz////1AkLDQdRBqiVB8ALkipAwEwt0cSIaardqcKx74z/ACMoyPNu0wBVyGAAIbIBv/zf////y1FUJcAeIhQfAAAAVCqYOA8fIeQyulUnmup1XmQIIbjXcgAr/+4Bk9oAE9EnS609FyC6F+r0UAuFKwMdd5+GSIJEIavwCnHRZAAAAoAAAAmcLZ/5gIUSfgAbiVgkgDTdtX8EUB4AilSAFAcF/9apMQU1FMy4xMDCqqqqqqqqqqqqqEslAAGAAAAH6sp4VB20v/xR6SaM8S6gAgB/i9ACnAH4gAH4UL0MK//ytTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7QGT3AVHBEVZ543uYGiCbLwAiAwQkR1vgJeHoPwKs/ACcTFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZP4FcPwQ1ngJaEgOQKsvACkTAnRDV+KBaqgXAmsQAJiGVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk8oWwthHTaQB6uAdCCfUEB0gBIEFXoIBJIAqAZ8AAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTdj/AAAH+AAAAIAAAP8AAAAQAAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV";
  var PROCESSING_SOUND_URL = "data:audio/mpeg;base64,//uQZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAF+AADDlQAFBwsPERMVGBwfIiMmKCstLjAzNTg8PkFDR0lKTlJVV1lbXV9iZGVnam1xdHZ5e36BhYeJjI6QkpSWmJqen6OnqayusLS3ury+wMLFx8jLzdDT1tnb3uDk5urt7/L09ff6/P4AAAAUTEFNRTMuMTAwBJgAAAAAAAAAABUgJAJlTQABpAAAw5Vimx9bAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//sQZAAP8AAAf4AAAAgAAA/wAAABAAAB/hQAACAAAD/CgAAEAYAAAAAAA8ELDn4H34frgJAAAAAANKRtBUt7BAE/91BSAAAAAABB5EEmQAWARwBgCAKAAAAAAAB8RkukDWL3G2PxLkv/+5BkIgAAZwNPJjQAAAFgCfDAAAACTA1AmZAACB2BJ5cEAAHHH/fgDRDNoLePn5KIjV/gZgeCWDc/8eCbCjAAAAAAF5uFpZCwAALfvk+n/dWEAAAAABGGmlqIABzFkmPiAHHRwwYUOmaTdgEyO+OYGjFgNhyhqPxMWP6/jEoPp6Gq+S1WDQ1NR98ly0rVnBbs/sguSGLUkM0WYOa/T/x5/XijVNzdW5nl2tFruhMd/MkqIIbsgABgbgAAAAAAPzRDlMtRWHv3T5MKlGAABLJdwAAA5TjYSdzE/GVGIFoAzPrQnqPBF+xbuctumKd0sL15CHtLzKNHb/kmIAAsERwAAAADog06Po4FIkhU3DHVatTFQAAAiIb/+lQ885GY8siQlpquqZfwqepPewg2MEzQwYIpD1hFkoGGEGKhmw/ybtZoCBEQmqUAAEYAgcACEMLyYpTsiABsQx+V7Ucb49npUtwAB+P9wAAAmGBfiiqiUqo+mkXGSKMsBa1nt8LAF2QIra04gjMsSiDEABHCH/AAAAMDsBS40HoO041g0OyULXn/+3BkzIABpRzVfj2gAAvgunTBgAANBIFXubwAAGmB7nsMAACN1PRkjorRRdsBCWAAKVWPBhioR2YVGSNR/4+xuQqgVUAWMAXMEkAjPCbBF/gyOnga9UjVplMCiQAAAAAUpgNJBEiBM8cJWxM+CzOwgMuAAAAAQMg+tBrQXjLR5UkgtsJWKUCCoAAoCFwNCg9pQVkaJ4wSqq4gwOpAAXQ4IhQHM5p1mG2DaM2jQnlRAIUAAAAAAsJY8kcNFsrSIGIqCBUSpAbgAAAAALKGzonJUY6CSaJByEZYkAADElcWNVjkBYYBYFQOtKM+VAoADJETB02JQDySXOKlQgSqFLKoACtx0qEdYTxmllCVFl20ImgARTXPiEkRg0KkiJoy1kszJTAABAUBQ836oE8iZaIprLL15LMgXv7+//tAZPWBEW8K1W9oYAoYoLrf5IABBpBVV+ZkZOBqhGs8lgwkKaPd5d900DCAAAAE5CyVh0trSW0YjaT11mb/zyAAAKR2N5SGaPfCAAAAAAGgAkOmDCcZcl4jARgcKgoPsTOzjgxkRDKgVEQbARrj40hFYgsBIn+bGXJs7m0UC9hgeSkO8ohDLZWmKbrvaeYzIBTJkLSiEStOSuiQZ0mCOoUHDFeW3Le6P88kNhbacgXIAABWBgD/+zBk84MxOghVaY/AGCBhGr8ZDAECmCVnx6UioFsD7HiTMIwAAAAATjQ2IMarXBKS+Dh0879YByhYQAAEWiF8wAAAmIGpWUxljQVAGpMAmIIGwkDSbaF3t2rTAAEG0NaWswGwy//jaClNEmAAARAAA4AAAFIpLJEbUQSFakDyg5v/6mwABf9fvAABFHJhmuz7ae6OIUCABGaaKY7/+yBE9YMwsQfX8MhIChahCr4FgQtCcCFdxKQhYFKDq7jzJMVYBQiXHECy/un0nLO241/YvUTmx12W7H/A3bcS/2whRAAB2gOAAAACQL2B+HlQcAuL4nAvEm4QMo3nMuXIo4gIEzNG34W2ZV85Zgwwko0wGpF4gXcVLUji18Y8WmCo//sQZPoDMK8HVXGLMJoUQOrOJMkxAmQfSoYlhiBIA2nQxiRNatVe/kcrKGAAMAAfgAeCc+KwLMNCBo8TnKU4Iv+BvpWsgwKbDAAAAAYxJhai8H6qCaZMMPJj8GnZ9cQgAAQABwAAABT/+yBk9AAAiAdSJTAACBEg+lSkgAED2CNKmYAAAFwEaZMeAADW6UUGZjIrHJwlUuOOf+K1MAQzAAD0mjKrGAoQkHISJIJwGW6EBKAAAHIjRBoIjBYYo91quXIgcAAAAAAHFWHkGERMoH0IKL2suaZRBgAAAAAIDCkOCOSxQfKs33t6//tgZPcAA2UdV35zAIIfIIuOzAAABiRhW/2hgChgg6s/kgAEAtgAL5LNSC5RxMTJj6gaRfrINAAAOmg4iCRNoJYxJdVGICOQAAAAAAYlhtHonJFpMZVxgAHbmyQOAAHQDZkGKLCcWE6G0RCe8/IAwBJzCS6NCLbQYAAAAAAGEQJGTByM53fTlFA8xsLEg8PPzHiw4ICFRlbTNAcuMLEhhOWQX0O5fRpDvWJBbL7rAmSEssOFSQJalgNKSNC6EIY1ZnHm53/80BIpJIK4aW+0Td2tLv1EIfxTgwoKAAAAAAAAAAAAHakb5zgf6xZCHpWgAAae6PgAAP24MmaqWdL8kAQ2qQap//tAZP0BEboUVWtPMooe4Nq/MewxBNglV+el5iBmhGs8xJiUHXMG6TJcPnaty2blAlzRVBuRLQTP8UVCigpO/r0iv/SgAABxIB/wAABBWMEiYiRDwbUCEescz572rWwgAADxEa7huNJWiTRHWZ+84cU2dMgpOsOcCUYRCxXFoIRpKXZCfptWLiEm++Xkxt2BXr+RIgABDhBCRh+Vh7MTBWh7MTaKL6OEpnyIbIjGdRYyLtyABfv/+yBk+oMw0QhacM9IGBlA2s9hgRcCcB1dx6UiaEIDa/iUmEzbvQAAiHT80k6kTfBUpokpCEaQqWHL+5ZnRv/mRFKXyMqOUPWCjSn9JDjP8EpAsTXKdkACAD7gAADcsyJeItsNwzh8k+MmPr2/UK6OOmRCEPUADgBtwBEHFAEskSEj//sQZP2DMKwG13MGSAgTQNruJYwBAiwdVIekwSg8A2nQlJhM7IKtleP8MqaZv+owVWjiFZ1NKzCFUAAqJ5jYyfGALrFh64vEk/qKlEAAZwAAOAAAJis57I9KJzJ5YEyoF1cf/8hTy4L/+1Bk+oAAswfU9TAACBMA+lSmAAENJHtd+bwCAGACbzseAgBAAAAAAEEmEI1lMgDsQFDiJJlTUEQUAADAMPR1otegOCQnHsUQxqEEDoAADgK1SwKBQhiF4jkToi2ZhAOHAAAAAA1Zd4alhBdioRPIRPYZxZTLCBQAAAAAAZh8++SjKhMFWATrzeEQwdQAABQaIxjgmLSQfgmPajEtzXFg4ABUJqiZCQiYoFUIUMDioXWgeAAK3aGA4OqhQlTQKiR8LUgMAAQxlo2RBVsGCbke//tQZPsBMa8L1m9oQAoagLrf5IABBoBDVexoyKh+BKr4x4zMGxLJtIGgACQ/MamAZCF0wgJOJoYyUGAAFpaYQkg/xtQqdJ1xqo5IAAARvkjguIBU0TsZGSRAAAuklCsoqBBclKYOmo7uCgXyhcU0CIgrDVK4mCQAEnLh8GiOTgbQQ1VMQU1FMy4xMFaEAAATgbBeImRrLMjEWgAAASroUScLLRpgXMVixvoDCUBZJLUeISAhA4STTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVf/7MGT/ATGpGFVp+Bm6HuIqrTwDdQP0I1OkvSLgVYQr+JSwDVVVVVVVVVVVJlAAAF5WhkgCzlUoWAAAAuFRkTyYSkv8JRHhqMy2/yjzQFYmNgAAAAADw9wIAuJ+vT8jsFoFBkAAAAe6lGPQL3HTgVA33D8CIzja1NaY2YwAAAAAEIG3nage78BrB/BvvbcEkgCAQAmr+bNr7QC3hv/7IGT2gzDRCFX57DEoFUD6/h2GEwJsH13EvSBgTIPrOMMkTHikXDKBSGTe4LrsLjh/J8oc////+mpDVVCHh3mIdnb7/8MAAAAC4On0IU3TA0S+rga4oSkiry7g3lwaDGsapSBCpfd63tjH/1vFt4//pEv851qma+tbsafVc0CaqxH/+xBk+oMwvQhWcekJOBQg2s4xJiFCpB1TxiWAKEeD6ZCUmCTtCixxuOJ3lnJgAEhmdnZ1Zvu7EgAAAAHpC7LipWjGMjuwssulwUFCQPJIyaeiZN8sYcJDHDrXW0UQQlDm+Ned26nLnP/7EGTzAzCKB9OhiUgIEYD6VDEpAQIgG0iEpMJoQoNoUMOkBbk3Zv1JY9oedM3Pygw1H01tJawAH8sX6/JVqRSAAJ4iOA0AAP1KpdKo1Kn+jrGwgrS4ukCicJhowDSUpBUBf/rWCoKn//sQRPKHMG8G0MEhSAgQwPokISkTAZAbQQSYJKg6A2iQkwSUWYgACmIjjqgADeEqr8iUNP9HVEwGVL9t8NRSdsGVSsXsdFRylb/yr3q//U7OEkgyd4dwAAAAAAAVI7MyEaJhARBYJw//+xBE84dwbAZPwCFICg1gydgZLCEBFBlBAITAYCICKCAQiAUQYBMAAA4AADlKNVoPGTqmH0Nb+I+R///6SWGoYjvEd6QiE2O7PCA4AAcjrcDrVyEBYPuzZkxBTUUzLjEwMKqABAAAB//7EETvB3BaBU/AKUAaCWBKCARAAUEIEz0UkAAoGAJnlowABECpT4YHQWlOOSgAAKOy9NCKlcVw5LPwATg98SyAQAXBQfh80FVVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sgRP+AAIcFUSY8AAIZoSoUx4AAAmgZSJjAAACSBKkTMAAAVVVVoAAAAABAb//////1QAAAAAwANxgAAKBcf/////+XgBcHBapMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAAEFA8MQAABRlP/7YET9AAKAJlf+YeAAVsV6z8wsAAUwG1X9gAAgvhFq/7BQBUXMAIBlBJgBdGws1UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwAAAAEoNWPQAAA8B+4tAOQ4AqwYAaB4ZYTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUCQMkKRBAirHwEhCpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkAAAYCkDQAABgHgHIoAlgzCFUxBTUUzLjEwMP/7IETthzCXBtVwaUiYG0Ea3w2PIwEwHU6EhSDgRIOq+DGwTVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVYAAABIAAyAOmABYDUA/oQ4FgAAAACdClOSAAABwBD0Mx2AKAwIAwIAgAAAAAG1l0qehuwH/+xBE8wMwYwfOwSBAGA8A+jQMzCMAqAc6pgAAMCYD56CQmCRjinYE6Bl6T//1zyPyocH4XgCjiZ/58dhRJf/wVgCYBcB1GE//NDYkCUBCwvf/+5fcp/6LBXAIBAKBQIAgAAAAAC61S//7EETvB3BhAVGhgAAABsA6GCQgAYFkCUSFiAAAEIDnVMEABA+4JfI/PPSqcf/779U/YaGf6j43J/+o3cmf//PHyYOCCgBgAIiYdnVnF/ppWwAAAAGqmfOz8xmQcaKpDxfneDDhxnM8//sQZOkHcDMBTyngAAoF4CnVPAABQJwJRQSMACAWASigxIAEjk00vhMBFmE8oC4bDdP9vFLU6TXBptKHA2ELI25PIUrj9Np7mwqcJhJnejKLzK21u2zH4TtWqwvqYa2qW2sdyfvqQbv/+xBk6gdwPgJRQSYACAaAShUwYAGArAk4p6QAIBWBKCCUgATp6fXbo0FcAIACqOpJlFhP6RCwAAAABnpiZe3MwYtTxIBciA7ZmoLDh0bYMiTcGcIpvUUAsXKsRuASxEHar1aQ9XlShv/7EGTjj/AZAc2BIQAIAmAp4DAAAQBIBTQGAAAgDYDnAMEABCfQ4/hbFGZ6FskJtdeKepUh+JSR4kDPNRifGMMNhYni2yJ9VsCdgObVbLXBiztsVVzIaXbFvSEYEFxN3PG/9SIQG75D//sQROaP8C4B0CmCAAwFYDoFJCABAGQHQgYIADAMgOfAtIAGR9rwABZClyyvUNP0AWhDhQIlSrOqsWLzGOAiTOymKQMK3XtMWh0oWy5v+go0NG6gMhEAs0yquRPgAWneoZbDMVbqZPr/+xBk5gdwMQHRKSYACAIAKhAkAAEAwAlBBjAAIAmA6RQggAZhJcNQdOBceRapfoIUHAQWeEiQNeWOioqxH1KPNKgq1VJ8VTRL1UVgAlmYof/AAAT0RuYoRk0UxaFKjxOxwoAkGZsBxP/7MGT/gAA/AdNFPAAMBqBJ5aSAAQkAv1m5loBAw5OqNx5wAJHfhJRKIEkYddImmrHIrgBNUtH2iAABVM0GT5DKlHRYqCotjJv1ZpAAhcGjzjpENI0AIsBHwoc+HsGjNhOOByUMVWOEzCy7mgF3f/sXICrEAQwAAHDYaGDD6KEsj0NSPi0WQL//1VjP+dVMiYgAACILiW3k2GHZvf/7gET3gANuLFb+ZeACfGWK/828Agawi2X88QAg4gXsf7AwBJigALBcYfKdGBZRbUpLhouGsqGklAANDS4JVtjWBgqITEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqiAAAABxgJqQAAAAKjANuHBZAggBhioWC0AACgdyrfDwwAbAAAM4zM/Ax/jcqjDQcAgEBQAAAAABmSDll2QqLZ2YCXX64VMcsipHn3tYV+Yx3YyJwQE/+AWC80J//F5AH4FDf57zzBwEQDwnBYAX/mX5ouDIMg5/wkcT27RbxKBhMBAIAQAAAAhDQP8hhKiGqk9WmBB4Dmf/13Xv3mHfkA837YCwelBz/x4RygaLf/mAtEofUSP/+WJwqqYQOWiYZSJMAAkC1ClEQEMk0xIqdYs93DUJyJVTX+TFMCovG4c+Nnn/09eZZiWv5lqqyLT//Pbd8tUkcg0stjA6//tARO+DEVsPV3mCGogtISrvJwwjAmwbVISZImBug6q8ZLAESUgEnaql95FAANpHa6OpmH4Tcg7aP+C9ZdQtQiu6OUYFiqIZaGAw0WlUwktNDPQxv0MhfylMZ/4iKu4FQqABy8RHuwEZGWfrxXPlc7DoYgAXNXKjaySwmWFhxmhVI8ClElvTWrGAPDAED8AKqAZiVFk8aQkzQdTkEgL8Qu88Gip1AkpZZQKYCJAAAIjCBeUEIsL/+xBE9AcwXgbRQSEQqA3gynQkyQUAuAlCpKQAMDYDaJCRmF0h0n51KQd5UFY1JwIAAQBAc02CoiQibTHAFhKF1jJEXBgrSFoAgD0n2Z5ooHMyTEFNRTMuMTAwqqqqqqqqqqqqqqqqqv/7EEToj/A5AlLAyAAMB4BKOC0AAYB0B0gGJAAwDADpAGSABqqqqqqqqqqqqiABKAAcBsP5KQBAAACwkifEWAFhMDBGx8iFBFVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tAZP+AAFwCUyUwAAoIoEoFowAByfi/TbmjgAD9l+q3MnABVVVVVUCAAAAQmRsYZhwKR4QlKp6nU96cFw52EMJkA0gZopAylReUAAD3zgavn6LwPEZu8s6JEYAAADxmJrD9REBcIxIJBaEwAAAAAJxuciZrIiRkP4QfoSRE/+9Tt9LuSvVqEb2FyKLOQnxQkOEMHhABAP/PIhAmPDg8T/3OJtEAoAqAqgCiwRgAAAAAJMwusuT/+1BE9oESDiPWf2DACDtlSu/nlAFE8B9X572A4HuDKvyUvAxrS6pPoMpZLwxb/7v/2Svs6QH/U6fkZyKVDS/zngAA7xJX8BpSAAV7qav+wAAZFjqEZDkO3EThKeNvyh8VRwQYmASdyABgurqCsC3F6uhh/yWKDfx//6EUIU3BAILAAAMnAVkGylVDEkHnNqw1+sFvEVZ0TPrBWCru4AENEL9sA0E8ztHklw3GREoWLXfCIjQuhMIwOwq6RQPG262WA0IYN8hqDECZTEFNRTMu//sgROqHMMYH1nEoSBgNQMokJGkTAWgZRoWYwCAuA6fgwBhEMTAwVVVVVVVVVVVVVVVVVVNQIAOkJgEMpKg1yElpE1+oGiAgAABgoNBDLIH4UNA3ARgYYG5MQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTrh3BEAdMhJgAICOA5+DBAAQC8Cz6kpCAgD4EmwJMABKqqqqqqqiAAAACQlAVAAAAfIowYKheGn4VwlkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQRO4HcEYCUkEmAAwDwEnAKYABAaQbOQY8ZiAagWaU9IQGqqqqgAAAWlDh4AAABXYJAjMf0SiKH4ABytpVu2mbwAAYAADAAAAn79ENQnxpuZyPAOKs3995f/+///////3AGABH+H3/+zBE/4AAiAXRxWQADgiASjSlgAFH3JljuYKCQOETar8wIACmAAAAAAAAhjPRp7wF0Ynh0VmVGVdbUEAAAAAOINysgFXiahKmjTkvxZwpBbmy2FoGqjVM/95pSNFC59hBkeoujQEAEQeWEo1OufjUddL2FrHVTd7Vw2BHFZwQ+Wx//5ogi7EU0kAAAAAYGgAAAACxXwsnAhh2rFv/+0BE8wFxnxBX/zBgCiAAuk3ngAEEfENX5gRs4CiC56DBjEzcVI2////kb/Az6iPlJNV0UQF2iX//AAAtVkqkUtLiSqGRIouUHTy4JIRwpoZljvHH4wVEMCvqsFG3po6AAADR0XlvcAwrVh/6AFlQTJqGySWwMybYcrAX/IwAKqIVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVkEQIAAGsOMsxY6ObAAABpCNACAAAZ4a0G//7EETwB3CQB1QhJkgYCOBaWBkgAYCgCTymLAAgFAEnFJWABhlMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVgAABENFoAAAKAtKmAA6JQWYAI0Qs//sQROgH8DkCUcDGAAwGoEnFMEABAGwFOAYAACgPgSbA8QAEIUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAAAGBKxwJhtvMwAAAAMA2CSJGUDFQAQDxABCIaCyADagT/+xBE6YdwMgHOqeIACAQAGhUEAAHBFBc8tIAAKBEA5+KYAAQVd4jgAAEiAABNygBFO7RyDkOTIgAGfwH//+CAIAgojlAQB9YPvKOBAEAwMgAAAB6OIhcoBhHZSRHIHJFVgWPwYYwGHP/7UET/gAFGJ9TmPEAADABqNMSAAAr8pVX5lYAAioupsyIgAHhhaxqQwww4/Cl2C9UqTf/qSlsZHylr+vHuJJwxuqim+DZBQUNvxPA5BNlWKQvAygyqTEFNRaqqqpSJQAAUSE3TrKxDhNRW2AkAAAATZPsKEqg6CM7g2Cgq0GooAS8VTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVRDwAAAB5Z2AhQFQnRgqaFAADCxMQU1FMy4xMDD/+xBE/YdxXgjWfzAACgygufjkgAECSB1WgaWCYA6A51SRAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAAE2mQRL0CaqIACGVUxBTUUzLjEwMP/7EETqg3BfB1IgYEiIBUA59SRAAYDEA0EDAAAgCgDngJEABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVYAAATJYQaEhgKX8ZHAA9oAdTEFNRTMuMTAw//sQZOiHcCwBTqkgAAoF4CnlLAABwKAJQwMYACAVgShgkwAEVVVVVVVVVVVVVVVtBAAAEgRDIWB9griaZWqYDqAAAA3Y4vBMNskRgjIRoRPuwU6FGzricVMAk1w0VWRMQU1FMy4xMDD/+xBE7wfwUATOqSFIGghASeglIAEBmBk5AeGEIA0A6ECUgASqqqqqqqqqqqqqqqqqqqqqqqpOBQgAALLZ6dPCEFUfh8BhF5gAAAAJpMFRIQw5xCSk8VrJLMIAADYOykxBTUUzLjEwMP/7IET/gXFPBtHqGEiYC0BqGDDpAcZke0etmGaoL4Jn4PWATaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjAAAAAGuoKKYAAAAEahATQoAAtC0ELB0cKVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE8IdwdgZToCZ4CAmgqfgwIwMBQBlGgIEgIA4A6JSRAAZVVVVVVVVVVVVVVVUUAAAAAssLIAAAABSpHMAA1NAGKI5MQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETnD3BUBlBBABiYAiAqMDAAAQBEB0QDBAAwEIBqUJAABaqqqqqqqqqqqhQAAAABB9MOAAAAAE0kBwAArDBgANDgdkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqF2DAAArd//sQZOSHcCkB0SnhAAwCICogLAABAFwDRKeAACgMAGkUkAAHODRmQCgiI7mBgAAAAAcArIBSrGYFhdCAUSIxGAAgcJUtTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE5gdwKwHQKeEADAJAKfA8AAEAmAVApIAAOBGA55TxAARVVVUNOgAAMi8FnDo6B8omAAAAAKLC4ISE5ReoNB2gBZVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EET1h3CABE9Bj3iKCkB6ND0hAwHIFUCE4WJgHYFpEPSEBVVVVVVVVVVVVVVVVVVVVVVVDl8wAAAAETQzAAQeEsgDKkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQRPIHcIkG0CGGYQgG4DpYPCABAWwZPQeN4KAUgSrQYwAGqqqqqqqqqqqqqqqqqqokyVAaUaIAAAAxccnv/14ACkyKTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk6ofwPwJPwggACAgASlg9IAGA0AlIh6AAIAwAqMCwAAWqqqqqqqqqqqqqqqoUAAAAACMrAAAAqyNIMg9oxmSsYapMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGToB3A4AdOhYgAIBsA6WDBAAYB0A1cDgAA4DgDnlLEABqqqFgAAAAGsEx5gAAAAUJcAgU+oAhB0LiWdUUAAGKsGbkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqQAACgHeL//sQROmHcDkBU6EgAAoGwCq0JAABQKAFVIOAACAUgSigsQAE/Gv/////rgAAALgGEHSEcCd//////lEBCASA//////8vTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE8QdwdQTRoZgAmgXgGqgYAAHBgBVEhg2AIBiA6NBkgAVVVVVVVVUcAAAAJBmPp+YAAAAaDYGsQ4AcCQJHYUIBM6pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETsh/BjBVEhI2AYB0BKeCxgAYDIB0MGBAAgD4EpgMQABqqqqgYAAAAmECEDAzSQAAABhZOh0OhABYEy4B9QUFBVRUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZOWHcBABVIGAAAgGgDo4JCABAJwJUQYMADAKAGiUYAAHVVVVVVVVVVVVwAAGg5DhJhfAAAAAoOg8HqQMIQLUImDKTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk5wNwFAFQAeAACALgKZA8AAEBKAVKh4AAIBCA5+DwgASqqqqqqqqqqqqqqqowAAAAoCJraAAAQGgcADBCEkIShipMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGToB/A3AVOhAAAKBeA51UQgAYB0BzoMCAAgD4DngYEABqqqqqqqqqqqqqqqqqqqqqqqqqpAAAQMBdwAACgpoIYCxkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQRO0HcD8CU6EiAAoIYEoYPQABAQgPTQMkAjgZASkQxYAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//ylTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk8Q9wZgJPKe8ABAYgOfUkQAEBPAlAB6wAECiBJ1TCgABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVW/jQxMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTrB3BDAlMhbwAIB6BKGCUgAQDAC1SEFEAgEIDolIEAB1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZOyHcE4DUiEpMAgIgFo4GeEBgOQLSISwICASAWfUZIQGVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVBAAAAAwJgPeqowDAAAAAAWVOvr4yhrmFgUAAAAAAALGrqBWAUCAQBkAAJxD/+xBk6YdwPwLOqM8QCAigWfghQQEAgAk6oLAAIAuBKBQRgAYga4bJUEt1xA2AAiEA//eoX40K/hPHPhZ3oSIQAAAAAAaaHf1SAAA8ViIbDkgIAAAAAAEYcMpI4EEA0u8GWhcdGkBwYv/7EGToB3A8Ak7AbwAIBSA51RxAAQCMB0cEJAAwDQDnVKSABDB5394m2EIa4S54ITix7XAYICbjiQgUZQGph3my7xZwJDT0iMRf2agaMg6ifyZix5y+7zjSyYl8tDmUNqmhiROzIaW9//sQZOSH8C0CTqhpAAwEoCn1DAABQFgHOqEIACADAGfAAAAFDsp7TfzDff+mv8a//chIwCFOAAGAGAAAAAABX3w5l5K53xD0sOIAACezfgAACHqegjrjMDLzBDcygk6Kw7AtajeQN2n/+xBk3w/wAAB/gAAACAAAD/AAAAEAVAM8AAAAIAAAP8AAAATlvDBCxrFq9UkKSflGurBnhypzMAAWCA4AAAAsA2nBSAmJhtxfXr9HFFIAABWIf7+gABCPGCEHpWgFBZxS6pi4xCDZvP/7EGTfD/AYD80AICj4AAAP8AAAAQAAAf4AAAAgAAA/wAAABKLYIPIpNMg5ODIhBY4Aj5VfuI//Iv8zyyo8D1KgAADAD/gAAAHIKKQbCUXDIazmJuGje72Xv9wTGtLvKK+IAF/+/AXy//sQZN2P8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAEaZJUnlMKSny2CaBbY24JpTloStOW3CpMlaqIjYqZIIhSEACIiGxenME6UedJ1I0v5SMY4BDpMCZ6aUHddFW2IAA6AAH/+xBk4gAAAAB/hQAACAAAD/CgAAEBBAFCuAAAAAAAP8MAAADAAAAAKpghPBBQOUChcoL5SYv/6qeRAWwAAAAABUzggB2jR+fJyFADTVGml7hSA4sAAoxgcNiGIWOpCGYmR5lZeUAYgP/7EGT/gAB6A1MmYAAACOAKRMAAAESURU1484AALAFqUwQAAwCVSuBQC3CTHxcMFQCsjSO11bmQM6gAAAAAgksYB/kzT3cVelzqWzyzD3dugHQAAAAADpIcAaUTYsGZ95ceTOUdmCCV//tQZP2AA4Mh025zAAAYQGuewYAABgxfVb2hgCBcAyt/kgAEEAAAAAAAAAAAAFRl6EhmITpftsk6DFAtrrMse/sH/Tb4g54AAAAOlFKMOPJEcWXuY4jytMfpve4e2mKVIhyAAAAB8I6CJL0oSYAEoGc9EMPZQvdFj5la5oriYAAAATkEK+vjTO63Zr7wUrD06W981abWxggAAABtXZLXhwwxwCSMCRyKoW3bNG51TTj0YJAAAAEtJQKg6bYaKch4XIXk2NmFP37GNbRsIEAgAP/7UGTrgTGzD1X5mhk6ISEarzHpMQTgKVWn4SagdoRq+PENRAHGgF63ik8VGQhhxA5RZx5DflMu42UCgAAAArninCRIhlM1sXaLIOhGvnxtCAAAQTwUsEOMecEAAAAAATy8ENTKVCUdMJAZljiHvlMZHJ5i82mCgEHAGFiQqlI0FkoDkLunx6ROSEo8t55jkJCGMby2XVUKoyKkzE2J+FYrD3Mk/Zo9KZBSgoi8trpPQYlq///2tusGT9fqeqABIAABoaAAAAAAAsiNpn1IIoD/+yBE8wMw0AhX+SZIqBgBKx4liRUCcB1jxCUiaFcD63j1pIXL936TuUVAAAJWuW94AAAjjt4vU5Txl5QMoKHHcEpu6bX521FfvQwEORSruWFCsrfoagNFnCAAAOBwAAAFCaIhOoDIPsIWBv1/v2GQAAA8Otu4lj8y2SMDpIcAhDa6//swZPQAAMMIV/U8AAgV4Pr+pgABBGwjUdmAAABtBKoTMAAAVmMhmGUBAyWaEg6QUpJblSvZc8/nN472KfduAz9iPYAA9A4AAobkRKkc0mc5bBqmuhId4hlf/84tB6qFIAAHiI+4AAAH+XJqOdJM4mhbhZDBBMgfQLMWg+OzXd5YR8xpiEGCj2XatzsKgAAQER/wAAAeimfm4LOp//sgZPmAAOAJUiY8AAAZQOpkzAAAQ1wbSpmAAAhpA+jTMgABakhJzCW16MwWGbvDUgOSTa1SaES6gAOAAA9SmwCjF5KOSJQfR7M5WKuL/0S5gILAAAiUgwlQsDIpAoSpiUwVJYCV342VQDGgAAAAABaHKGRLNoETILgGWCQiO26GB//7UGTzAADPBtMmYAAAGEEqNMeAAA1YkVv5x4IAaoIu+x4AAAAAAAAADw0uA1AkHxUjZRxH6qCAYAAAaK3EkEIcj62FS9Yd1NmZlkIFAABQJlIOBQbAoEoXrVV4YEFwAAAAAA9GsiUBBGjPCwSPwHHLJyAUAAYQyWLSIvH3AyQeDgQaAARTgAAsQFMTx/Ukm68dDWCNgiAAEgSyvctQonwqK6EWPWXQCgDWqmmkIDEVgUAAAAAAgBh4sEJUbteFUMMpMkGmVHsMBnoqauxiSIn/+1Bk7QERdRfYf2RAChYAur3kgAEGOC9V7GjIaG8IqrTHiCXg75l5aVAQHBRejfibzJJHmAe5+EEQ+A0K2T7f//NgICOENy6mtRb///OCkaJWoIuiej0vps+UicBBoWz3uwrQAAAAAAAAAAAAJCN8B9gRojOWwpAnV3vuCcAABtKy+AAAsO6Mee0LiDGhAaDMggNv4FZB2DBMRvzG5ycjo8wSM7FbYWblrpUrVKyGErZ1jiJKjgABgAf8AAAB4RU0jJUK4LCdzDv+Wd10sUpD//swZPmDMWcK1fnvSFojwRq/PEZRAwAfWcex4mBhg+r4nCQEAAA2eH3oAAAqzM4/7pvLDBehVIGDyQicAYuh4qQOXRysbU1Njtx5PJ2GmOPk7F8AAFw2/AAAA1ZGIwQDQXAdaTQ/mV/tTQ97RYMuNAzJqEZ4OuSAAA0RF39fCc+ItcUeZ4/UyvoQhAhUYKWdB1ni0blIyM6VL2cL//sgZPUDMLcH1vFpSAgUYNr+JSkTAogdW8wlgCBCg2u4NKQMKGpHqGExXJAU3rOGWnqHQgAAOQC/gOrhIRxRz9UJITcPGey4MkfW3wYWGBYXiCAACGAP+AAAHxiJQgOkJNrxUkmDcCYk0kys/Y5gQa3kbdyAZkAAAAAYFeEAWMtBaP/7EGT7gzCxB9Xx6UgYDyDqZAWGFQJ4H0qUwAAgRgNpEpgABZAJABASbJUCGgAARJaOh2Oi/JWCERNI0xmwAAOBJYDhEctSDB0jzBWYUSCAAAAAABxDFYA0QF7E4yXD7jdpdUqQLYAA//tgZPgAAyweWv5vARAdgNu+x4CABxB3V72igCBjgyt3kgAEAAAAwauCyo0K3n5E8iYZVyXUEoAAAKNVM6EJcLHC0SEhMhKz4ZSAYAAB8DWYNkpc8U0EZGFmVXYSIJAAAAAAASAFh3QKMEjoQjGoIFdnZAmAAKA2UEZwMiRBdMUMTvWA4AAH2oVZlF6AZARtECpxpvhxMOsjqIQBsKKCuBdjFakCUAAAgZwqEQCyIh8kIVrzcQoACRGdSyPPqCRESJTJp5WgQwAADiZkJEawhD6JFjC0VhDh5hsQCEICjEdC6ipMQU1FqqqqZjAQAAKH5DoqYI3p4ZV64gAAGMkMISARCocO//tAZP4BEXwUVftGGyojYOqdJS8TBpRfV+wYbCB6A6r8hjxEIFRMNqACFJgQaMBZpYysjKM5yJpCiE6QkwlVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVUJuQAAPQcmojQVQiF4vQAAAXBKqEMFUnrQ0On4NnBsVmJKB19DgMVB0QrYAAAADREjngcJbR6GlIphMAAAAbrVW56YBe2ydU7ciEX+we+NGuws004AAAAABJH3hSn/+yBk9AOxCghV+Y9hGBVA2w4kRjFCcB9hx7EgIDuD7HiUmEwnZNsNyvLhukhQaYAAAAbIwSJKmyITNXCwg8D/qvZzAHXM4zXtp4kwiIeXB3d2H+9YAAAAAZQenNiMq4CTEOLwSEf06ygSv5Veu5JdVEowPE/x1rMz1xxrX//wUy1F//sgZPaDMLUH1XGJYKgVIPr+JYkBApAfX8wwwKBIA+q4xKRMzJOYKGHkSUC8IWKpQVnwGiyAA00sgcybRN3mEAAAABEwLGqWoeACjZknwyxx0hhYYjapMlE9I25mqAYZBT9zGiATNA62R+e5C/bpQ20ezR7/693xTpAKDBOILIg6rP/7EGT8A3C2B9RxhmCYECDKdCTJE0JMH0yFPSBgOAPo4LCkBJL2F9/xvgRwPfyUOQACPARh2QABhdIc2wU6yp1eIwBGSCEb1/txIK4bdEX7GI/g0DT5QgAFeWjjqAADJkVqI0spjLuw//sQZPoDcIIG0iGHSAgRIPo0POYhAggbRoSFICg2A6kQYKQEYlIGqcBlbb2KP8jgIMu+5HNDGf/5k1JU3/RnRwJ/Wgm6oDoAAAAAk9AaACyPKkItC1TTKBzQAAOAAA1GnXoatYVcuR//+xBE+INwcgZQoSFICg9gyhghKRNBiBk/AKUiaC0DJ2CUmEwi0bw5wh5lv//+oO4GIAMvXJ2jaFgETJA4AGqiE4uJOgqMXU1MQU1FMy4xMOA8AAAbIhHv2FUAqMEVsAAEoNQa5ggipf/7EGTyh3BlBlCgI0gIC8DJ+ARpAwE4FT8UkAAoHQKoYooABdkXwMAsJggBi8yAVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVgAAAABAM//////1QAACQXdYA//sQRP+AAGkFT64kAAIawSoUzAAAAlwZRpjwAABzhKiTMAAADeU4//////9aTHELTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWAAAAADUgFhoD/+2BE9YACRSZX/mEAAFkFGv/MJIAE3ClX/PGAIMSR6v+wIAQABgYkgBQNRJRQO4xMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowAAAATC+YXgAAEIBgxAEaAmiJDkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAAIjFwAACALSDMpaTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqrAAAAAcDAwQQpMQU1FMy4xMDD/+yBE6QMwkQbYcAFICB6BGw8ETwEBIBtHAIHgqDwDazgEsE2qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqmIsk9AoFAgEAoCAAAAAArVZKDQa9CVr3AFI2mHJFuD//8i5//sQRO+HcGUH0EEiSDgNgRoIBAwRAHQHOqSIACAWA+fUgBhe4kCx+eBUJP+CAa//gvgFxDkA8//j88xh///uLBiL2NQABQKBQMAwAAAAAKj4jg+FtMdkBuFv/1f+f/znf/0ACAZ/4YD/+xBE7IfwWwFRQSAABATAOfUkIAGBUAlIh4gAAA2A54DxAAa38vUgEAFmtVpDdQb3xclgAAABW5DRzwvKQ6CQ4iI6QwIIYeYCB4uDUFh/ADDTyxWOAh0ApEq4D0MCsaHyypCkMkqQ3//7EEToB/A/Ac9B4QAMBOAqRRwAAYCkCUcFpAAwDAEogGGABm6BBYjK9Yoro/h9FsFPNBH0OxlRD5+p4irORXPyenIpcwNRaTssSLNLK/mvrXnnhUlUAAAALULLFCER2YKGQAAAAKLF//sQROeHcD4CUEGJAAgFYDnVMCABAIgLNgSYICAJgOcAsIAErYGJKj8mFUA82wRPR2zNj4Q5PB6Wo4LDojEXfuJ7Sh7J3SgjRBwEJl0Myh7Iy2Nk81MSmGn6+rZIBr+eZ5HgjEjwwkT/+xBE5AdwJwHQKWEADARgOfUMIAEAUAc0BYQAIAMAJ4AAAAXkS65Zl0slEYtOzFJLvHtPSyqWx7D5C/rE7OOuZSSjtYa/5Tt3ZWXNQSKyGfbbgADZ1q3V1xoB6AVw0x+pp7AdxL7mOP/7EETiB/AzAc/A4QAIAAAP8AAAAQBMBz6hBAAgAAA/wAAABFGDCr1qVH/a6PZauyq6m9S0nASqLgapLkQEsU5rHUeABfgOM1Ik70MiGAWTLfr5cyQXL8xZ7yhSZs2sdUFf/8OG4ILH//sQRN2P8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAES/63ViXnnBYko8taR2ACd4aPrYAABkSgiOhk6wkCA/Did6CI+rbrNZmuys6waHD69xFV5mDehzIcRlACapWPrWAAKsz/+yBk/4AACgDOBQQACgAAD/CgAAEH6L9PuaUAAKOPKvciIADKYTegaqMgOoC7TrYivgKCUUfZvhtqTNL/n6kpOWcmV50s9VEM/TDA6grBAAB8BOGqE2BVI/A1Wt3/7RY834ih4QAZwAAP0HhMhHREE0ASDEWi2iUOGj3/+SXAw+LY//uARPmAA5ks2P5t5IB8per/zWCARpSLZ/zxACDhC+x/sjAEi11MQU1FMy4xMDBVVVVVVVVVVVVVVVVVhJQAAB34ZuUGXaHaBAAGkUix4LYnphP4dPhMIPKwZwoyVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWEVEggAC8nBMH7Y9QMHQKBQKAwAAAAALNPKU57I5PvED4uJmTj//9d8D7yQf/iwo//xbAbEgh/8YjIQgjCb/+KgSg+FQbiH//2UiBUCf9mpm4eAAFAoFAYAAAAAFC7aZZjTBhs9W0A/uIPIZx/99rFX/8eCk//IBPHjf+IgJ4IYoJv/2G48EQMwQ//88Xjour/sQoUCKFiIZOEkACaYjB4NQa2AhTFiBQCbD/mWHBdLjfqztojLs+kw1Ptb5nNJbM1Wo5lU8yceRf/+Wrz/+1BE74ERaA9V+S9BKDHkSt9gw1NDDBtV4IEgIIGDaryVpMTjbNabJYOtPZUZIAIs9TTfSKAAQi2vi/I5jCPCwD0QisgKZ+9ZLwl3ZYPCgsq1yKkhMGw+1zmq7+a9VVvhmbj/6hphmv5VWKFkoKK8ZD///24SeKSFkBVSaQOtrE2d1TNjtLvaDlLqdIox5awTM9RO/fPylDwIA7gAQPwEkY6RSGQRZHKmxafKZ8n8OiVtIrUaMPAAB0f48Kg7CpF8OiKzPXIRIAAIAAAA7EiZ//sQRO6HMFMGz8BhSCgLgNpEAMYDAFwDPKAAACAjA2eUAIgFwU3JMGCJYIw4ihN//g0HW3GKAADGlICYAqY0Wh/XmAABcPPRAVCZSExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE3o/wAwDRACAACAAAD/AAAAEAHAM4AQAAIAAAP8AAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqooEA140CAAN9QdAOLMdUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7MET/gAAHAM6FCAAIBuAJ1aAAAQikv0+5hQABDxfqNzCgAFVVVVVVVVVVVVVVVVVVVVVVVVVVVYgAAAQt+SgpZE2UkHQ+qXAqCliAAGX8qu218A1PpEcGTRaq10o4CzE0wAKDMDOPxMAQAAABYgmERIhYzG87IBkPt9RqsvLN/6/19u//vCCAWrf+7uKISZIoH//+Z6IIYVF2OP/7YETzARIfJFV/ZMAIQWVK3+egAUUcX1WkvGSobQMq/JewxF/7lgWggBgAAVgVRYHAAAAAAEyOJ0GsKEIR4WC6EmMBH00f+zkPF/Y+x6fOdyKhWt/IRiEORwHFhf+TkxA2usut/8AAJfkrQjiBEmjufIsInV9dCPDREwuwTKVaN8u0MToQWr+QnrrlH7v9//8QUFkITggEkYAAFIiaSY4aOg6b1RrDR7yrgWeVOxLxMevwa9YKgq8wAC7xDe4DKiCB0S8Pj6NgjuIa+Nv1OLDaEOrL0UKb/NWsd0CGJVtMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqkS5AAAAZPAKxZkwyOYnuf/7EGT+gzCIB1KgDHgoGkD6PRnjJQG0G0aAjYCoLAMooBYYjUQHaQAAZPAKxYBMuI4znOUJYeOO2FwIMGtEjUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQROSP8CQBzIHhAAgFgAnlAAABAFgHOgSEACACgGfAEAAEVVVVVVVVVVVVVVVVVScgWSjghwAHUWNwEATSTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE5gfwNAFPqMAACAAAD/AAAAEBIBc9BIHgaAKAZ8AQAASqqqqqqqqqqqqqqgWJ1OiwMsAcR5MuOcAVDtWKOABgAAACXVt5vSaexS8weG3vz//+33////oPlP8giAAAAAAAAGMJS//7MET/gACPBlAlYAAIAkAJwKAAAQgEnVv49AAA4xOqvyRQALKFBiAbZnNZRIJfJ2KAAAAAPS9p15LRO62h3iZcjPIHiV/UTHtqWsP3wihZR2gicEkS7s6CK8lyUqsVYjuX5n4Q82pTiRlQQbDQjVWeKY////tKRz+7Zy6uQMAAAAjIACVKqF9zaRtHJnPeWzSZz3/52Uw96YfEKv/7QET1AXGkD9h/MSAKI+C6PeSAAQR8PVfksGaoDwJoIAAIDQV/oZUQAomof/8AAB5CQgFiKQqYFIQEc0xklJhEiARCDXk59DcsceQvzPFLv8a70ilIAAAfVJ5X0QfAhZd3ZgBVcINrg1gIWAD+UA/qKwGm26FnfUHYArGVTEFNRTMuMTAwVVVVZSDgABIJW2et+xVC4HWrMJmQAAbad9vd2RJVHbCtAAgACADd4dgAQAkBA/1B//sQZPKHMHsGUCBBwBgPwMoEBDkDAJAFMgYAACgYAOZAkIAE1UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVYAAAJgSFQAAAKABRzmADbhRqALiYDP/+xBE5IdwGAFMAeAACALAOYA8IAEAlAc/B4QAIA0A59SQgAaVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVcNAAAAAQYvpAgwgAABIBYNCppiuBzjZM/OJUFGL1pAADf/7EETlg/AXAU0B4AAIAoA5kDAgAQDgBT60kAAgCwDmgpIABGDkdgAgAAO0GIvgVAAwho+ItyCNDccP//wfB8//hiXiAEAwI2AAABaJIMqKBgbOQAyNqvatFJUuzD3AJ9X+pE0uHyEV//tARP+AAPcJUqZgAAALoDoExIAACrizYfmEgkCOAylvMAAAITwGrA+rOUv+N1djL8mX9hXtSEoyoKNhFTcgoKG9EjIdLwQZtQ8WEBnpTEFNRTMuMTAwVVVV8Ce9ABRLgCpE0AVAYJgU9SUAOAAABPWyUTIooAN5xSEYp5nSan2KfWpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqxAD/+yBE9oNxaQvW/yRACgzgqejkgAFDEBtVwxniYAsAaBSQAAcBM2cN4NA0gAAAHPsAj2BD6kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqCN3/////+gGCNAF7ob/////+kAJlTEFNRTMuMTAw//sQZPSDMHkH0CDBYAgOwPoUJC8DAPQFQwSAADAgAKfgkAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVgAAALDAYII+GQBQyoyobYlVMQU1FMy4xMDD/+xBk6QdwLwFOqSAADgbASaUswAEAmAlDBJgAIBOBKBSTAAZVVVVVVVVVVVVVVRLUEABYpLSpG1NGEW26A2aEYAAAAAKMN1AClYLkIqGFMVTCGgOhkSDfACbQmhOBrUxBTUUzLjEwMP/7EETuh3BRBM/BYUgYB8BZ1SUhAYGIGUKB4YQgD4DpIGCABlVVVVVVVVVVVVVVVVVVVVVVVVVVVXSwAAALic0lQKoMqh6fxkAAAAAAChChACJ6ZmrpARJrjgAAJQplTEFNRTMuMTAw//sgRP+BcQ8Gz8mPCEgLgIoUMSMBBnRzQ40kZqgwAigQ96REVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTAAAAAGlxkigAAAAZUglEAACiMGXIAbH1RMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EETyB3CIBlQhCUiaCYCqBDAJAwEgGUkBgSAwE4DnQPEABFVVVVVVVVVVVVVVVVVVVVUcAAAAAs4WwKuMABXIUAA2OkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQROcH8EcCTynlAAgFIDpFJCABgEwHQAMEACAHgKmAwAAEqqqqqqogAAAAAgqFsYAAAABhiEKwAA2B5EeKAAFZFDa1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVFsDAAAX/+xBk6AfwOgFPgYAAAAJAKiAwAAEBIAk8p4gAAAiAqECwAATutCQGp9cnpMAAAAADgGpAKTcYy5FxDRNg64goAAASAixMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETmB/AuAc8pggAIAoAp4DwAAQC0Bz8EhAAoCYBnwPAABaqqqhJLAABAeHeiwUKC1GAAAAAsMhZRIhjMQGw6C6IIlkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQRPWHcIIFUKM4EQgJAEo0MSABQcwVQITlYmAggepQlJgEqqqqqqqqqqqqqqqqqhQAAAACKNKAAABZpmABI8DQAk51TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE8IdwdwZQQSZgGAbAOmgwIAGBUBk/Bhng4BWBKlBhAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFrPEGLoDfGpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTqB3A7AlFBpgAIB2A6RD0gAQDECVCGLAAwEIColMAAB6qqqqqqqqqqqqqqqqqqqgktgAAAACY46ASQ5qgBSVrCakxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOYHcDsCVKEiAAgB4CpwJAABAHADVwSAADgPgOmQEQAEqqoXAAAABVEFEDgaAAAHBrCAYaPraAQgGFLLORYISWO1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVXAAAFwE5A32///+xBE64dwPQJSwYMADAYAGqgsAAHA8AdTxJwAKBkBKNDEAAT////rwAAAPiODOOQISA8DO//////ykBpDhB//////y6pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETwh3BmBNGhjAAoBeAaqBgAAcGoFUKGGeAgGAEpEGQABKqqqqqqqqqqqg4AAAAmB0JpEAABonHg6AGBMAFrKgEGtUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQROyH8F8F0qDGSJgHADqILEABgOAHQwYEACAPgSmAxAAGVVVVVSKAAAAmOBlAJcQgAAAUIQrxuLECBEVAdcFBQCFSTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk54dwNwFToYAACAUAOjUkIAGAkAVTBgAAOAwA6BSQgASqqqqqqqqqqqqMAAAAYDNgDBLIAABISFhKyQDGNKqOctVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGThj/AWAU+B4AAIAiAp8DAAAQA8BU4GAAAgA4BogGAABFVVVVVVVVVVVVVVVVWAAAHgEONgAAAAQEDwA0AANwJhCkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOaPcA8BUwGAAAgHYDnYYCABAGgHPAwEACATAOdVgQAEqqqqqqqqqqqqqqqqqqqqqqqqqqqAAAYKITacAOIQwVBNTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE7QfwTQNTIYgQCAfASdVhYAGBNA9OgyQgaA2A6QDEgAZVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX//FVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTyh3BoAk8p7AAEB4BJ1TDgAQFcCTynrAAAJwEnlPEAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVb+CHL//IkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOmH8EIB0qGLAAoFQDo1JSABANQJUIQkACgNASfAkYAGqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk7AdwSgNTISkQCAkAWhQl4QEAvAtHA6wgIBIBaJRhBAaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTph/BMA1BAbEgIBsBZ1RkhAQCYC0EApCAgCIDnwCCABaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOeHcDECTyjKAAwGIDn4LCABAJQHQwSkACAKAOcAowAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk5AdwMQJNqekACAKASZAFIAEAWAc6oRgAIAYAaFQAAAWqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqrC9pAPDy7aM8ZuBMAAAAAAO1+GKNcAxB5b088FVoAAAAAPDPhDDDJcJW3AGP/7EGTfD/AAAH+AAAAIAAAP8AAAAQBYAzwAAAAgAAA/wAAABAaDMAAAAAAoDZg8RqyoLiMAmkhk5TNl2A4BnUV2ZwF1joOE7dA41ICPwb5cy5G99ZZwBWHWMKYc3/9hczLnL1U9jG////sQZOCP8BYPzgAgEPgAAA/wAAABAGQDOgCAACAAAD/AAAAE5lx9+4PqOeTWy///31n/qR7BFD/8RYgRqAFAAAAAAAAAAAAPGyBTGqcbSjjnKAABXM4VuAABBr8+7zY0qklTNADGzA3/+xBk3Y/wAAB/gAAACAAAD/AAAAEAAAH+AAAAIAAAP8AAAATgc2KPdXFgrKepaUCYkzNWgpQob8sUFYGBqkIVCSgor+IgAAJATP4AAAHQPCYEom0omPYjqdQE0bIKwIAAIrOuvFXexP/7EGTdj/AAAH+AAAAIAAAP8AAAAQAAAf4AAAAgAAA/wAAABGUwlriwqwiPghFOfY5b41ABr7rywNrMmLKkki7zIePkWH3Rrj3+hYODQ/TCAAMAEicQkgFB/YQTlgiApbYR8JAK2pAQ//sQZN2P8AAAf4AAAAgAAA/wAAABAAABpAAAACAAADSAAAAEAAd4e//AABhqfW6CFNUWghKWQMkiIk5I1vUuhqDRO+vlVTz6fEghTNDUsjnm3mRKColDQNQoAABDu/4AAAEwWeE1hEL/+xBk3Y/wAAB/gAAACAAAD/AAAAEAAAH+AAAAIAAAP8AAAASg6RbUUMykW9MhGzmH65bIH27XdVKiIFNgBIEapPWh0ZLDoJKnzceEtjKgAJ9AMD5R4Bw8G6Oyx5YImONA95u+h1ICqP/7EGTiAAAAAH+FAAAIAAAP8KAAAQDoCz4Y0AAABwFoAwQAAAAAAAAbVDE3Ak6DVkqqFR84yKp0AQiQAAAAAiF2AeHEeJQC5K0IpE2KuCAZAACEpCjQlgPNMEXHFpZiBZgAC3UDHEaM//tAZP+AAJ8GUSY8AAAGYBolwIAATFSXb/nHgoBggu17HgAACiGw80O2LoRhEFcAAAAAHrFFVfKhVPUNkUbjHTVYa0xRg0gAAAAAbarqgGYSCRAuNmeIvyxUKEkAAAAQgFAts/LeMkZdMhEBMA04+jvfS4WMioIAAAAN+BRm4lQB9WqqASV905jMtJj5Fznvl2rMoNgADlRLxiWWyjW0yGlFZadSiIABAfwH5hAUiMSISKJK7Gr/+0Bk/gExtQ9Wb2hgChmAuu/jAAEGiDNV7OkIYFyEazjDjQwBCXLR68eSSKlp2fxhNrzFAAuskij6B0AEOi+eUoxttQhQm3CXCVCVAwDAAAAAAR/BQOXOI1IyVJkckdCoepMJF8PW5FwwYqTPJCxBYRzRBAWeA1ABs/NHgHeGpiHBtn/gSMjiIE+l+GQwILorkIqAAAAAAAAAAAAFcq0nTOCnMEfCj19eOqgAAEUqZIL8AAN3Lv/7QGT5AzG1FVX7JhM4I0EaryXpF0KsI2XGJOaoWgQs+JMklOu4FQAEkZbhplGHycxhxolZrvy/G6vR/rloleMzFGZgJ4LVgqCr1gqdrCfvBoGTGpkAAJgCa/AAAAeBIGQaxMo0JJMYFfnwYAoUuxEqIRAANYhv+AAAGFSwDmU6daQqjGAEQJYgsaZ07bDXJBxK/MinNW8PfPkNxlUyAACAAOAAAAE8mNjQKSUAABYrWDaVf1Pg//sQRP8DMLQH1/ArYAoWAOr+JMkTQhAbY8MlImhHA6v4hKRNAD/fbekJEB7C5m5LFLeIAgKIWqNWQMflmoxDNMqEa6/avPZaEF7ar3ctf6lu2g3YuDH6prIAH3H/AKmFRCAqq4LEQ0n/+yBk+YAAwQdVdTwAChWA2u6ngAFDYB9EmYAACHaEqNMyAABqtRLj0I5De7EZ4J2rJw4KVWIAAAiHD8AAAApokDWFSCKl+HOZpBhPB1X1d5HhzPcrSERUcJYUdRAABwCOAAAABlJUBQNHxIDJQkDJM3CSJ/nlmGAW5cgJoAAJAbgg//sQZPUHMI4G0qc8AAoRQPpk5IABAcwZRRTAAChFA6lSmAAERiGknzqesSOVKiyumQQNwAAAYJUqn50Aw4PQWw+Va3ARsAAAAAAUNkohFgDyE2LD+BZiDvRAlAAAAAARULAsLgHMpob/+1Bk9YACYB5ZfmpAEBtg+z7HgABHfENf/ZGAIG+DK3+SAAQNKjwAOaYAUgAAAnUIbAnEGh5Q8FhOJdUmWICkAAIC2QGB8DQpaLGWiwpHYhCmAAAAABOdvYe0M8SdHFgGywo75gnAAC4wPDs2KTmD8VnnjR27oCyDNIA4A4BAHAAAAAAADmp2uC8ai6ol7SgtkTKEgWp3n7JBpB+DYGn8SsL4Bl/4BbgXYEmc/8CTIg8DA0eINQZ3AAAAAAAAAAAAbR0E3GxKKAB0lazGHqhG//tQZOuBEVwKV3n4MaoYIMrfJSkTBqRRVaTkY2iBhGq0l4yUMH+83LfKAAAApndYRIZo08AAAAAAAVXMHBowAARYs0YNBBj0YjQANC0YFOcwuV5YHFhk4YPWKjQJyHKLa2I5mkXClJyjkkooTHYL4bo+hLlCaRcSQN0FWnSNIuRtKJUn/eJqFWDMNXQiEYLQYAAAAAAAAAAABC11fTCmaGAAJd9deAABWfV/aCCVll7UthEjNfgOLDAwciDsFd6pIshCNSBvSdVr0l8jMu7f8P/7MGT0gzEwClV553gIHcEKvyWJAQKgHV/EweAgRwOruGeYDBhlpIRI1OhAAC4BH/AAAB1FioUBg0uIQLNOP2/kBel/QLoqhQAAFYedL6AAHb1VZ/BVZZJfhTlNsq9OCAdLLmnaYmZMdgaAcTBcgTA+PcjYXbiZwgaaNWEAJcD7gAACuXy5RcVTKsmjYL1lZH+1pX/wYIoPb6wmLP/7EGT7AzCrB9fxJkkYFWDa7iXmE0JwH1vGGSQgRINreGSYDc5AAAjhF/4UrSqxunSuCDpozRilYFBd8idzcv/l1L/Zyagr8RSJ3OJku/ZiCAARwAEokgNjwWNBkLLj5UI40k5/JemG//tAZPUAAK4IVfUwAAgR4PpkpgABB7x5WfmGgACIBKr7MAAAkl6VQAA3AAvAAAARBD4hdh+KBvJMuj/FkfiEnSr/fKh0RZUAQ1YAAAAA2GB+SBDEVqOFi9B2ak2VaA9gAAcAyZJZIQiESYqOhBgqlKOICoAADYliAhAKf0TwRquZ6pRQoAAAAABcC1yrCLVZgKAhxGHB8wYAMAAAAAAGIDHgLUPFAMgdKYSbaFUCdwAAWFsSFgL/+1Bk+gADER1X/nHggBPgu87BgAAGvGdXvaGAIHGDKz+SAAQABbkxK0JJC7p1IJAAAmDi8A0OMExVYmE4VZXiPgAFHwtcSnQCjZRFIGEMspRFAAiGCUQXDDwiKHSW6fo9kJIgAAARxhDHCdUMhpZGqqigIBAAGcKE+H5eFJ76mOhM9KIoAAhpS2oaRcROFkUkqkzAoAAENksfAaYNGE6HwnvzkAB9Sg8GJJWgRAgcLVmKtxsIADQ2mRBVUlAmjiV7TEFNRTMuMTAwVVVVVVVV//tQZOuBMZ8O1fsJGpghAgqtPCJjBWwjVeexKChqA6r4l6UEVVVVVVVJGAgACFmCmbGXg6m5OWIAAASNcoEyZGGLFOEIco8TWUTaIPxGSWZECNFNDtIUYBZMQU1FMy4xMDBVVVVVEpAAAK9K7jQiWdjzwABwRhChgwgaiWmAAAAAA6Vpcs8DPFFR/HzD/xAAAAECUgsIKcKQg/gDKmwUgAAAAAEgJ1REnjNJJNSZsXSAAAAZKGGtpkGYqw/yFkDLg3Ic+FbMU0wq7asbAUCgUP/7IGT0AzD/CNT57zBIFgD7HjDJI0J4H2PGJSJgRYNrOJOkBTBwAAAAADV5nphy6SozLhdgWBrrDQaXX/TWJfM+cb+TVP8xUN/8dGxEUv/axhilQEDU0e/mKZ1AJdANQRQRBICQAAAAAPYg+DcpOF1tPcp8FYy4ir5DiARpxqqO1zz/+yBk9YMwqwbZ8eY5GhSg2r4wyRdCYB1bxJkiaEWDa/iQpQVKCvJiQwwTIfQxjDrfU95hEx4z/5hk8Hg/Hv7fsRW3/1UEAAaYiI+pQAA/5uDWAqldQu8quDQQHUgywqxDWVulDxB7B0VIYWONZ0Fziqeqfml6ffzCIDBE55aWAAJY//sQZP0DMIsHVKElSAoRoPpEMSwTAiAbSIYlImA7g2hQ8DAEhW/qRAAmqSC41Ko1EkViqEAnGtQ3EojhGe5QjqtIxzPyMH3Vtdc7f9f3t/UN/5QchgQzG//2YqniEEFiAAAcRKstCHj/+xBk/QMwfgdSoeZIGBAg+kQZJhMCCBtBBjGCaDsDaJBlsAwdEUpgRGgiGRghd///zxaJkQAZgJA+tn0MwUa6w1ltM0C6FMIxfD1sqdfpCL//0//6Bg8JQ16lAtqEAEQkiWVGB2khE//7EET1h3BrBlAhIkgYDkDKCCTIMQFUGT0AvSIgJwMnoCSMTE5BIAAAAAb0lB84DYrJSoWclcWUhBBCcw2AsJmcAAkCBwAAOAp4NEzslUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVV//sQZPkAAFwGT8UkAAgJYJnloQABQlAZRJjAAAA7BKgXBAAAgAAAWAYR6PUFJSiAADhNkpNv7BRh8lRM//////8MYAQAmCT+IkxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+1BE/4AAfQZRJiwAABwhKnTHgABHkJ1VuaOAASWXrD8wcEhVVVVVVVVVVVXQAAAAQgw//////8vQMAOAVTv///EmAJgDg0wqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMAAAAEw6FoAACAcBAqh4NOTAEFZMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqIAAAALEooBk4J3AkA2ONwAeG//tQRPyBEcgi1X9koAg7xSrP7CABA2gbWeClgGCeEGs88InUzkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpwiKaCwMjVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWAAAMA4WpMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EET2hzBbB1OgAUiYFOEK3gAsAUE4Hz8BASYgMQOquAOkjVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVW0AAACSiAEAIEBI6Yg4AAdD82h4AAgDRCKiuRuE9doTAAAA//sQRPAHMEkHzijgGZgMwQn4CAYBAQgHNASAAAAbgOggkIAEGKlaeph2r9ngMvO/YC1wMHzkLpFgW/pxpE0XD5HM2G3w5mXHR1BQ7EOvx/f9q8JLro5u1D8Bvn/8w8s2qg3V5FSCELv/+xBE64dwYQFRQSAAAAHAKgAkAAEA8J00BQBNwBcBJ6DEgATxtokl/W8+4yyLPDDRKJCwHDT1d5YZYRo/e///8MQ1IO9/T/p0yub5ZO+/00YcIBL7ChJAxD0SCEAAAAZMomhQD0GVjf/7EGTnh/A3AVHBYAAKBOAqNRQAAcCYCT6mGAAwDgEnwJEABDIcbzx8sHf+Nt3YITdpeLOodg9DeR/Z2TLpQHYMj5onNDAQQoD0H8P37KLizE2CVGMPElQu4fP60VeYDmWTAVmOmH2+//sQROcHcEACUUEpAAwCYDmwJCABAJQHOqYIADgPAOhgsIAE/AAyEuYp24twhRdQA2UpY37DX1jZ9hLjiNaqkoWMyl+qlxYxn/DIv+/sQrQz3uCgWKo5gCPG1CSaTcAZryiVuaWkhKb/+xBE4QfwEgHNAQEACADACfAAAAFAbAc4pIgAIAAAP8AAAAQyArtBWvT0tXGV1bTlFgKouCPUrVGoYxfKuikc2vmylXdy3xJQq5ohCfRyAKlQ0zxU0QAWZhm9l0Co0bWFUBF7ih0dsf/7EETgh/ArAc6pAgAMAAAP8AAAAQAUAUAAAAAgAAA/wAAABCKLblqofgwJgox2qqhjIr/rs31SUufV43/O9/o3vGEpmAG1QyeQzCSzVHqgZEDRCMNo4wKD64gkm7yccXFVK0xSsvvM//sQRN2P8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAEapSsXT/+ryknEEpFd4MGd3dx92AAAsCTRkyXSkIwcgaCx8IoiVHGosFP2Lc1QMjQaaIsacyLsoAkQEQP/QAAzGi8aZH/+2Bk/4AAaATOxSQACgagGeWgAAFP6MVT+awAAVKXrn8w0FCNsZwF0TIEKWNGv1Khv/6VL1LZHUylZkSuoL3kFweQIYe0STGhO23kBIbbXIkgRJdVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVBAAAlKGFFi6AABpkSeliE4JhaQ8cBCsFdYNPpUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWMqDYBAAAAAAzoYYE7wwKQEAAAAPZLBH9UdYOyzfQOBp7hc7NLYqSQAAABSJz1GF5EFLoS5y5YqpP3/+2BE/AERySLb/zxgCkKkq3/sFAEGTJdd5OBk6MKSq/2TCSTbb2WmaOzuvPTN6UXLC5SZk8pxVXJKBOOxkbzv0o6tWHZ4dLiXa1Ce/23gW0Ts1hOR8EqWsz/+Y1poqwIB34AFotpYWwAAAABXEJOqZ6Zkk6TJ2JiYNH5K6RONFES66rJfv///9eQC6RD6Nq++yKpcWMOFuI/j2VdzMJgKITY0/Fi1+39oj9+1Pk8c5gnjr5i490PUe74omDpYo+Aor+EzxFX/ppYAB4iYe74AABdDeNg/06fokpiCB4AkFSy3cfJupVspbGR/dWakx4qC9EUCN/+N5pmIABXV4jb4AADOmK3/+yBE/QdxTQdVeSwwSCrkSs88YkVBLBlXwITAYCmDKhAQpAxjtCQicCdmQhb/MHWv/X4zYE8PVarNSDONYHBJf1Bx5kQOHCIH/CsDJTMaOEiYpNTFmJBjWgqDKCvxG4qAg67rfU8SYNQoLi060hEpEB4Hjv//w1VMQU1FVVdgAACV//sQROuPMDEGTyggECwN4OoIACkBQBwBOgAAACgbgCcUAAAERLSJPEnQVQ+2WYBNRgAQmTaqTSFeFNNV69xBAHTZgJaAAjblEkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE3o/wAwDQgCAACAAAD/AAAAEAGAM8FCAAIAAAP8KAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqiEf8sIIzYLJMVG1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7UET/gABcA1ImGAAAECDKZMWAAArgnVW5lgAJpJaqtzTwQFVVVVVVVVVVQIAAADAMv9QDBGohxIgAXr9wE4I4BAIWpz7jUSq7XlNgAAAPOnoR0LWy6hRaCg8Jbdt5O5x//8p//oCABAICAAA48HwBm0FBJuwvXOH9/9tfv9bQAAAAABKgJ64QMlCQgOgcAEVI6WBrUe2D/yg+OdhApqULgwlUP0BNqd0jghX2LySYiPT1kib35+uLOUwnQxTQ6VtmlotgcEgsDQAAAAAAgsD/+1BE54FxhhfWfzxgCisCqq/njAEEVB9X5Dxi4EgC6vgzMATibqFC7bCNwdtiM4y6Tb1/8ykfpIyJ3NVf5WFxZDGy/qQXDB506JeCGqqFIwSoqGt3AAAzFxKXHxkjDw7BnQeUaE/MqIYLZhwCrtQJhP/W22OHayS9fUA0AAAerDwRhwLRJbbQTDfYcCygo4KF8pA1BwpjAtu7SRJR4DD/yQKtSFVFwWM1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAk//sQZPKDMHoGT8BheIoP4PoEAC8DALwbOqMAYOgTg2dUkAwcAAADT3p50FQpKCSAAAEe9POgqA03B54ALoX7TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk4w/wGwFNgSAACALAOZAwIAEATAc2BYQAIAiApsCwAARVVVVVVVVVVVVVVVVVVVVVVQTTBokQCGYCIGlMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EETsA/BYBU7BIUgYAAAP8AAAAQIYGz6U8AAgAYBoAoIABFWAAAAaQflAwJkd0ALppPTROAe9A8KgiAKM6qMJUGVgRANQMxIGgAAAAAI9GZkA/xQQwxTgedtFqh592+3OF7TU89yo//tQRP+AAOwGU6ZgAAAQYMo0xQAACTSRWbmEgADjEKp3MFAAljf6NEs0kDj55+eIp6mfzywjiWJIOxSXEw1Zv7kFfopZXIJAAAAAAQwAAAAGn0x2AGxm8+n/////k/8Id9OKQL/udSBDeJh7f8AALIc3H/FXKkPI4CbrfeuojS8coq1zbhQF3xbKRTe4ou62Tt4P1wVCFMnsAAMAAXMgZCEJRaeTLG///gyCtXkwAYVgbb4AACBATyNbXGExCfHqOKpkMLELqfmJhPlRqZPUMP/7IET9AXFjC9b/MGAKC+DJ6OOAAQOsIVOhsAMgEwAnVAAABHVU80q6WwAAACKhWtqoUKeIYQUAAGvTgpmA3CElcDY/AAmDpUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVAAxgAGBfE4AYDTUA0AAAESv8UgsBpqAhjEaAQwkP/+xBk7AdwWwbPQMEwGAqgyegEJgNAVAU2B4AAIBGA5+DwgASqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgwwgAAD4PwGmgAh40QD4//7EETij3ARAU2BgAAIAoA5wCQgAQBEBUIEgAAgDADoFGCABrVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVUToAAAAJ1RGiAbkGLHgAACIlE0bIAC2Kie7ZkAWiXAAqoB3E7B//sQROqDcDQBTqlgAAwCQCmwJAABAbgZPxTAACgMgOeWkgAGjGaARWVma65gABTMbwmppYpjzhyPxvYHWlDHEU+ckkf84KS4h/h5aqfnYbw8DDNFvL0jAlYuAAAABlgAnTgHac7Iu9D/+1BE/4ACUjBYfmDgkCDDimzGiAAGND1f/PEAKE8CqCeYAAQDnQD5KQcqzwwYEEkcOf/6WfyJJckZIeBoCAZQRXmqTEFNRTMuMTAwqkDIgAAFCVDqg6aIAGeIsWc3cQbIAAIIsvAAqGwFFUzDe57UCR+GqL9AGAQGsDyTFOfkOQ4BFUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUgAALC0VyyAAAAUPoomAZNf/////oIAAqkVTEFNRTMuMTAw//sQRP0DcU4Y1PnhG1gJwJnVJMMBQggbV8MhJCgPAOhgYIAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWAAAAiUHjf/////yyAAAHRxUUoGVTAAFHVrGVMQU1FMy4xMDD/+xBk7QdwWQdQoCBImAtg6igcCROAeAc6pggAIA+A59SxAAZVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWAAAC8QSgAAAdWFJqAAunhYCBwVjDAAUwT0kxBTUUzLjEwMP/7EETlh/APAU6BIAAIBsBJxTDAAQBYA0SjAAAoEAEnAGSABKqqqqqqqqqqP5QAADISctPZZAAyKB+sWxGIiYAAAFzileq3EC5GNRU7MvJ5HH6miqS4t5gAkSnDQLCqTEFNRTMuMTAw//sQRPCDcGgFz8DBeIgFYCnlLAABQcgbPQTgZCAVgSeU9IAGqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqRaEAAAqCrjCwLkoVUIAAAAA2XIIgbgKuJP1VEkKAAAIjCFpMQU1FMy4xMDD/+yBE/4NxoAfT+fpgiguAigglTAEDFB9ShDzCYCQCZ6CRpAyqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAAFSpAwSyAAAFDsfCGh31MAKBpCFqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZPiHcIsGTyHjwBgRILnkYHgDATgXOweJIKAlgufg8LAUqqqqqqqqqqqqqqqqMAAAAAMPByAAAESIccAAKUP4AIsPTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE6odwNwJQKWIADAYgOgUwQAGBEAU0BgAAAA8AaaDAAAeqqqqqqhQAAAAEYFSAAAAAJmQovAOBpGdECILcANxdYApMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTrD3BfAk6rAgAEBsBJ5WBgAYBMAz4HgAA4FgDnYYEABB78AAAIGRqKwKoEATMT2gAABYwhY8DgxsWjICBQtj7f1UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQROqHcCwB0ClhAAwFwDnlYCABgTAPPwSZICgTgSmgxIAGVVVVVVVVVVVVVVURNkAAMHBRLyiiw6UEgEkNUZgAKOJKTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE9wdwjQVPwThgGgsgeiQ94gEByBlIhjxA4B0A5+D0gAWqqqqqqqqqqqqqqqqqIAAAAB3DETMigAAAAOkcAAFwEPVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EETvB3BmBlEhIWAoByA6WDwgAYEQGUiEgGIgGYEpUMQABFVVVVVVVVVVVVVVVVVVVVVVQAAAMCcIzKGABU8O0ATq0kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOkHcDsCTisiAAwHQEnVYSABAEQFSgeAACAWASkg9AAGqqqqqqqqqqqqqqqqqqqqIAAAAA1LIAAAYDIgVVDgA7b6TEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk6AfwOQFTwYAADgVgOiUkQAGArAlSgyQAIAyA6ECzAAaqqqpgAAB+I4JY4izAAAAAQIgiHEw4ClZUicW5AAgikbpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTrh3A2AlggowAMBwA6SCxAAYD0EUUHiGAgGICqEJAABaqqMAAAAAICApL//////QXsYYZMJCe0C4EAbv/////9FUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQRO4H8HUFUyDvSCgE4DoVJCABAUwVSoMZgKAJAKjA8AAEVVVVVVVVVVVVVSAAAABUGQEIAABgJRqbHACQKjcoRADbTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE6IdwUgLRIOIICgKgKiA8AAEAiAdAp4QAIBEAqiCwAAdVyAAAAHwYRPDc3AAAAA2klBQA3lAwAmCIfQiPICAYxypMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTnh/BDAlFBiQAMBaAadAgAAQCAA1qDAAAoBYCpwCAABKqqqqqqqqqqqqqqkAAAAEgqBJGJAAAQAsQIgDgwtBAMVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZOWHcC0B0anhAAwCACmwPAABAJgJRwSIACANAOgUwIAEVVVVVVVVVVVVVVVVVVVVVVWAAAOLCeAYHQgwDG2hAw7qTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk5o/wMQDTwWAADgVgOiU8IAEAZAdIBiQAMAuAp8DwAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqQAAEKE+IAACwjqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETsh3BGA8+p5ggcByA6iCVgAYEYFUSEhEQgFYEooMSABqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//xAa+MDKkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZO0PcGsCUUEtAAADoDnAPMABAHAJSgWsACAngScUlYAAqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//0VTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk6QfwOwHSwWwADAZASeUxIAGAvAdUhJgAKA4BJ8CkgAZVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTth3BKAtFB7AgICiBaBD3hAQDsC0aErCAgEYDp4DCAB1VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZOiHcEYCzsEsCAgE4EoFBMABgKAJOKSsADALAOeUUIAEVVVVVVVVVU0AAAAAAAHfl4MRFCwWTGqmQAAAAAAABhnVtDBAACAAAQ4SYGKch53gsb/20i/3goAAAAAAAZYQdUQAQAb/+xBk5YdwKgHOqGwACAKAObAowAEAjAk2pTwAIA4BJ5Q0gASUjSyKqrNg6AAAAAA/yKYhCze9NroiE2FoDzxT8yQeNALjFQt58jLAB40OwEBaTScasMUqSxvLQGeCnmZjsymOSx5Lcv/7EGTjD/ArAk4oqQAIBIBJ9QRAAYAUAT4AAAAgAAA/wAAABMBpxgYMklTTUlmLSzPDniXWtRmA4hEqbL+f///yuW3HAL9JnGXYAOsAAAwA0AAAAAAOQdlDCyYYlE/1+NKKUAAAJ4RN//sQZOEP8BcAzgAAAAgAAA/wAAABAGw/NACAo+AAAD/AAAAE+AAAG2d2lbqwFPQGhAFKMmsExgO9pBR61Sy6VRYFIMn9qnqn79v6rdnc86aKXxFqRgAEABPAAAAFB+JQBALbkiTJ9T//+xBk3w/wEwDOgAAACAAAD/AAAAEAAAH+AAAAIAAAP8AAAASXn1QoAAHDu3/Ffus4yhzgTay3RAyTfIQxgcDVw6NNugyohpFvlCISCY0YAnlAzW3/WD7hObhgQACQh9wA2KNjJEr20v/7EGTdj/AAAH+AAAAIAAAP8AAAAQAAAf4AAAAgAAA/wAAABPg+ybmIeEdqCC9ZRNdmqqrxgAX7acQAABsv4SiT+C66wMqFRwbAedAAu+aP4w3kqJbiyGlQVXA48FX/3xMKB2DIAAHg//sQZN2P8AAAf4AAAAgAAA/wAAABAAAB/hQAACAAAD/CgAAEI+AAAASENCCTCwJZkyKBJfTveHSAn0jEpOgGm7ggFbAABG5BkShKguQojRhBLnZW6GQFgBiBLA+Q/gKuRgTG2IZvKwv/+xBk6oAAAAB/hgAAAAAAD/DAAAACEA1AmYAAACQAaRMCAAFVt0IQywAAAABvaGGzjYiICROAhLBtO5AN0AAAAAaIng8fGYUHpCURpIGzlmEBZwABCBvQkDUrEpswUHx+YuncQSQAAf/7QGT/gACpBlKmYAAACkBaJMKAAA1ki2H5vBIAZ4Hu+wYAADP6HRYNmBI2Q4mTqxW3UQJ4AAAAAA1YEBeKRMfoiaeyoEtNyyCIUAAAAAA2H6IhhajQwsCuE0LogcAADBLUFgkuCKhUTYaNX8WFwAFTag+oYFQaLo0YVNP1cIJgAATlFWahwSYUBWGPBI1coSWAAWHAt44kOhYQoB4ehYgAB4dyscGlrHb5fVcO+xgBsPoz4MDY//tQZPYBEasX1v9owAoXQMrf5IABBlxBV+xoaKB3BKr88KVENDJKSECMNeEKANV7VLRbNRaAgAAAAACIBGAwChJMEgcwILjNxFWJbQ3MHgU6ifzJAyzyBRHdgx2GHbeRcmBIhQV3JwGywbBYGaBo4BCV4t5oOscYHbA26AJIBgfEACyRNMvhkEMSiljE9/+pFFRi79U2D2EyoAAAABAAAAAAFbl8H1TCgchvlyNHjrv/oUAAAJq4nwAAICZkisXmWHTgTfNMoNrCOK7JgC9ZNv/7MGT9AzF6CtTp+WEoIEEavyWGCQJ8IWnEpMKoUwRsuHSMVB2Q3dwCNpmtaXBGizsSliIdI4KuOrTbmBLIB/gAAA0siX4XEyF/LOYSIxAAB5hvuAAAHTJsciyDMBDAGSWJHnpoMWj/3eSY1BRhjPJRiPqeTq4M+hkMAAIaA4AAAAgPIBrAcED5DSxN0QsmaMWfQU0BA1AAAHhw1//7EET8gzClB9lxKTCaFWDrDiTmIUJoHVnEpSJoSQPr+JMkjPgySqgk158H+aFTonEDTpkjDIsB4pMshoLAXknBwiY2pF16h1bqJhkEAAIAI/4EHL5SKF8rRHTQNFAryHyB5zOhQgKg//sQZPaDMLEG1vHsSAoToPreJElBAhwfUoSlImBEg+pQlCREYOH2LbPE1cgAB9xxwAAASZ/orhrwKonINkR1FDnLzbvLsaXa3CSCHgql5LNABYAcAAAAa7UNCIEguGhAoIR0WRB3+lj/+xBk8ocwjQfSIYlImBAA6mQhKRMBzBlIlMAAKD8DKGKSAAWstwU8oAAZJXygVRqLbByylETJVD5QLHhapQQGQAAeCKmCqemiI0BhpqIQaaqQJJAAAAAAAlCePEMYAf4qwFzaELrRmv/7YGT0gANPJtx+ckEgHYCrPseAAAZ4QVm9oYAgS4Fue5IABJIDmgAAAAA0SkTRH4FedOGrOyHyYasQBHQAAATUixgU4ZIjJKgA0RlIhgE4AABMRPOgVMjZIUBpJ2pXQyCAAAAAAACA3pOXKBVswTM2GTcHp2MKAAAAAAOMLAAHxAG0Zc5UEBJG7CKCbgIgKYJYDgMAAAAAAOEG7lvlHkE5psykBDJgQyIQE7NLEjSx4CC5ECl8CA2fYDJAAHPL5EzEO4ACIBEfN0UjQAeYASwDIBhX/wJlA2hGoGBAtM/E4HJ5iZQVMgAAAAAAAAAAAFSGAC5B3X4QoMNDTv3z6W1VQQAFN//7QGT+ARFaCtZ5mHmaHUEKvzHiMwW4K1fk4MMgjARqvHegJIZEVeAAG6yCgsJrGAWBgTGeBfY4WbYoZJT5S+9Xmk6EmvlS9azVW/vMznOG5PiivBayf/6/tgoL4VABgG3AAAFoUK1tCFgG2JgH/yHsjKXAAAEWIb78M+d6JSN/WzskXSYwuZl4cdcagIGAZ6aPVNDN3Cjy6rkpfdzPvdz6go7pbU5gAAEQEcYAWMs04KV1QHDY//sgZPoDMSII1OnseAgZQOq9MSkTAwghYcex4mhMA2t4l6QNCHThYMH28gJ2uOe0UUqUAAAImI33wAAd6XdfWNTLSlxO6MBbqZKgYNTss97N7IcrbpGOLAotBA9RnkK/63v/yMDLotUupAAAkAHvAAADPHIiDSD6ckg8CwpCMHBsmf/7IGT0gzC4B9dx7EgYFmDa7hnpA0JkH1vEJSJgQ4Oq+JYYDEAbvBINP0tE4uBHgQAAdgj/gBq6OBJesJhMRWBygdCc1o8uVDPH2IEKw2QzC3LlTABFQABASaDg9kAGSPg2cPFv8lWEMABYAA/AAAAFKPyuJBisCk6fDEtD8ubd3+r/+1Bk+oAArAfVdSQACBVA+t6kgAELNHlj+bmAQHcDbrseAkELx+PAgmUAAAAAAcJYDQ2AWogcyWgNuXLS0GIOAAAy/SFAcRB2DQTpioY0IHgAA4ekImQ/YoHT38LTF1XIdCCAAAAAAB9l2wGD59UaJ0TPJkd26AUgAAAAAKAFQlGDYVBhJj8DE6klAQdwA2qLplCM60qXiDdIfmgYAAFyypbPjleST1NGG0JpYFgAGoRQtC1CIoayEsDNFZ4uugOAAIDuYPhXLQzCpAWBCbTC//tAZP8BEesV1/9kwAoVYLra5IABBlRrWe0YbGB4Ayr8ZLBUVAACdhaABoEQakE0UAW1SATEHUx8TBoeHXkNkSm1soSAAALeiERi46NCVJncRAAADQ+lQNiNsI0CZCKHPEmCgAAFe4QWp1wHjLGD2aO4iAAAUZliMTBeBUKyQsQGqkxBTUUzLjEwMAZQAAAK4js+Gg2qMOjbAAAAZeoHKpJBtVZZoPZyIwOCDMpJ4kTsPvQ1mDX/+0Bk9gExsxTWewkaqiQg2q8x5kEEeCNX5j2CoFCDKziUpEx1FlAAAGKYePj2I4rYcZc9P4AAAf9oErsQwKgUmAAAAABVn3NuEqao6ASQBE//islgUjQGAQAAL0y8OwzpLFvA6/IkY4SVBQaAAAAAApOiKaOHA2wKmCEmgiAAAALiINaL11RpSkLglwUlCe5iqw5mPCZRG8iSCUB2QEQEQAMWBoAAAAACIQLHhCrtDOG2vgkZYf/7IGT1gzDpCNX5jGCoFkELLiRsIwIUG1/EpMJoSwPrOJMwhYjRm9caZVa7fyx5Yb88xjnM/2U1vjcboJbmik1U/PEcF4Tuaxokg8zg5lk2gwAUUQ7Sqgii0KAkAAAAW1BaUqirK2p0I5wlfwcd1J7OCbQQZy7wTCc4H3ew4IsXGFf/+xBk+QcwpwbY8eZIChQg2w4lJhNCKB9Xx6UgIEGDahDBGQX+j5qa/+WMqi75U7//LPt1QVACiDf//nmb14wWkwADl4h/+AAAKrdbLowzGXBUBQxRvMSoKZvPWO4ecSksqlqXKYpfR//7EGT1g3CVB1IhhXgIEIDqdDDGMQH8G0yFFSAoPYPpUMSkTP0czzF/+Ugp4MgACiVX/AAACag+ano1aiKJoIOF1gQE5D+HJPexDEDPlKV1mMUytlo79Wobl/6OAjAQ9ZboEWABM4lQ//sQZPYDMHAGUqDLSBgQoNn4MSEJQfQZQoYNgChDg2jQhiRNtI0QjKEhCcsd5dAAIgAA8jMpN0KbCCTRSLaA6kOr3bGCLP/7LPrDQdpMQU1FMy4xMGA4CAAMbe25AhtQTV2CVYAAAAH/+xBE84dwZAZPwCxImA4AyhQlCQEBCBlBAIDAICKCqCAUjA0TMMrQAL0yZkLGDG4hAwAAQDPyisBUUuoH7HAExCLwQ4DoVzsXTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGT/gAB2Bs5FMAAICqCqGKMAAULEI0CY8AAAUwSokyIAAFVVVVVVVVVVVVVVVVXAAADAjHfETAIcAAhN811TlC4EAIOgYSpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//tQRP8AAIAGUKYkAAAfATnkzIAACQyXX/mTgkE6F2y/MIBJqqqqqqqqqqqqqqrgAAAAiCI3/////9UYTgdBn//////WgmBQmkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkAAAdAwoxAAAAAmGgccYA6Bl4nQRC0DTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqQAABeD8LiBwAAB4NNUNCVgAD4P/7UETyAxGCI1X/YEAIMyRqv+wIAQIsG2XAmSBofwRrPBY8HMJMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAABYkUXAChO0xBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAABCKyTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE+YMwVQdRoCBYGBQg6w4AKQNBeB1EgQEmIDWEalAQJAyqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqGvUMCoCAMAADcySEAx4IBKDzyG8AhsAAAAADrMQdefTBGzAwBP/7EETph3A7Ac8pJgAICmD6JBQmBwBoBzykhAAwCIDnAJCABABWpml0VjL3s1KAAAABrxf8RCzv/27gB6GDE6qqSYKdv5FPJgL+w7KE0c8FCG0lJcxwHQZyHAvGA/lPEHrR7wQ9OaGO//sQROqHcF8CUsEiAAQCoDnQMCABAOwFPgYAAAAOgOhUkQAGr5aKIuCcOg10MCjLilTuPAfKqszO9WYGSE8ViHubxDUAn0xbL+I8OuP/+qikkl8erqaOY/G3IACQPmLUtLtDbeTn4AD/+xBk6QdwMQJQqSMADAfASigkwAGArAk/BiQAIA8BKBSxAAYAAMJIbEooDiL3VLxDgyq+eakDnT+9GjpLo9ehCTQVY6BjCRtRJAkqGUaNuK6nny6KcVR3Zo0bJG+nXqMGA+VSEjc2P//7EETnh3A9As2piQgIBOA59SwgAYBoCTgEjAAgEQDoYJCABv/IG4b/REGKQQAEe2VLLNwAOxWvGaWItJGUNWc1rMVg7tq5ZvVIBEFiXMXKwVqv9VgymRvKFZujmegUbcrI70MgmbLF//sQROIH8CUB0CkhAAgA4AnQAAABQHAHQwSEACAAAD/AAAAE0ACd8hlm/n4Auywzpgq03Qeg2jUJCeLjXvrQakAkcurMsv60VWBhRRxeWDsMniwTOoCp1VzP+tZqQADxCr7JqHUuUr3/+xBE4A/wIgHPKKEACAAAD/AAAAEAGAM8AAAAKAAAP8AAAASJMnIWZqo6pSPl5l0htPm1L00LoZDVUpWMbylr9a3a44thcoymAAjQiewKkYFZdWkcp4SQArNEVm1KhOgrzk5JlblaYP/7EGTej/AAAH+AAAAIAAAP8AAAAQAsAzgUEAAoAAA/woAABM7I15UMYtRmNoZ//qj3YMXqh2MFcHdgLgAACYAIwKm1oqVASB49HZ3KQUQZBV//hM6QEsFck0MAA7BED/MAADTYwiWF//tgZP+AAJAGU6Y0AAAPAMo0xoAAD4S/Y/mnkgFlF2z/HpIBb1FGUTITMhbCaPBVYbV6zollWBQGjoaXz1QCgtCwAD6K2NAMCgV4Aib1kQPLMkOdTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQDgAAAuVBUZGAAAvBZWNAKJKG1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUYJTCJAGAgGAggAAAANd7CoSj+JYBopjMvwO3ws70Tn6z5/+kg7/pVoVnBGAAAAAAABAAAA/DOo/pl//tgRPSBEd4pWP9gQAo4Ivt/54gBBfCVWeeYSujDkms9gwlVzvkzEEkLf/z7Bz////y/+OIIMBaYJnR4V3l6rCAAAAAe8RIuplJGni5PVoAsinJsuupW+b0P61Op3V62ro01LPLXJAAEQlFlgfC0WSs7BZeiLZ+io8cazlvzWBFQVdz6zflmje7WZmcjDQZmfngCABHWQQFSWaLRGEAAAAAI+K7g1VaqCwKIyJak8HdpS7FCyn7WH1HqCdRR9jyzNRwQCwwGgn0PTOi0PwaD5ZKOh6g2/9hoO8lEGBo2qiBSb/+TA+EuQYB5/1KFAAVnaH+2AAA0pUWaMVTEGJMGy1ApB/KK//sgRPqDcSUH1HkmYBgpYQqvJekjAUAZToCEwmgqgup4AKQF8XMHXn0M1vqRXI3YyUlbGPnzZx2uVdAADhgCP+AAAMUbWpiTyiM8N04EtCjXxn//Vyl5flCiSJuoLxBgkODwPwA1C/nLbEN4YQ8QhQnbZI9YCMG/hUJXIo+FlajYlP/7EETnD/A4ANDAIAAIC2DaCACmBUAMA0AAgAAgAAA/wAAABInG2ZEKTEFNRTMuMTAwqqqqqqqqqqqqqqqqU1gAACsTJRLyqEeHlSAgygAAA8o0IfwCkTbIt4APVEigNpqAS9VMQU1F//sQRN6P8AcAToAAAAoAAA/wAAABABwDPBQgACAAAD/CgAAEMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUTudOAAfERCUxBTUX/+2BE/4ABKgZS5jwAACNBGq7MAAALqKNd+YYQAWeUrH8wskAzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWBsAAAEBtecgpYjbZUbZoWK5U4BeBaAswTscNhZLDSwDAYEAgBAAAAAAxbJd35GwrU6ecZHl83987U36L/f/uMLAP/BCBAIR+XghLVIAgGAgEGAAAAAsvkqMeHkA0Bp420DYo+/3b/b/tb/zhBFv5MoASYGq0iwZuiPJ0QAAAAABExxCCQuonKLGlkSzpGcrY5zTWb6e6agSJo1myzTUZ7GW5VIcRtIPkLT2uXODCsYyg18jky72HyLHWK5hb/+0BE8AFxdhdVfzxgCCOiqr/niAFDzB9V4L0g4CsDatAQJAX121otFAoFAgAAAAAAC6BTUP/B2jPRQmkU2li+c7/mdssW/s6f7GMxf/c7AKoDfiF4kgSId1u3AAAyzSaI3ZFIPCWQIU1oTGmJ2EyFgUChQUUfUvTfwVl0u+jgAD/+4oSQCgyhjEwgCwSE6wC2LAOEIlkKk44i4iDy/XBpVUxBTUUzLjEwMFVVVVVVVVVVVVVVVf/7EGTwhzBxBs/AIXgYDeDqCAXjJYCQGzyhAGDoEoNmwCAIFVVVVYAEAAAmZx4+8O4AAAAArD/WS0fSgQiJKkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQROGH8BUBzQHhAAgAYBnwBAABAIQHQQeEADACgGfAEAAEqqqqqqqqqqqqqqqqqqqqqgsagHKJDeAAyDTqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqoIsAAABmLxAEpRQgD/+xBE64fwXAZPwSFIGAAAD/AAAAEB/Bs+lPAAIAKAZ8KCAAQAAAAMO310PJBRrJOqiwK3eEQAAAAAAA+ATNqCNAJXcAVFYGQWqMEAAAABmRgaYBUF9xRNWjJflYeEp9fEaRP+m8mlpf/7UET/gAFzHlPuPEAAJkO6bMoIAAmIhV/5lJIAwJCqtx5QAEsWPEAM9zwfg/EY0IRJ+Pzrj5jl9zGQwmDoJwPFQaqNWNb+w6TNlhlAAAAAbIAAL51EB3hUwkDw43BZF7////nPlC90t8pC39NHIAcRMt9vwAAQyzpJLJbHkWkwfw/RwtGJkvWsBGOzT1BVULMVN3foXOubNfyjvqGbuNxUAAACRoTExrcBd7h5iWQEkICR+AAAHL8BhSCJCZfH+A2QmY6WRKOxBZlYilgq5gT/+yBE7QNxTQdV/zAACgsAyeXkgAGCgB9bwZkiYA+AZwAQAAUAAAHGhLlQFeHmRBIAAcUqKagvFVDxZy6IPP//////VUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVwGQAAAUZ7VPBUagAACAEYDngIEgG//sQZOmHcE0Bz0HgAAgHQDn4MAABAGQHMAeEACAMgOfUkIAGHUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQFDaAAAaAZABtYFiZVAgaDYKAn/+xBE4w9wEgHQgMEACAHgKdAgAAEAQAVCBIAAIBCA6CCQgAQ1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVQTIQAAIWURiX2Bnsrf2sqgAAAnF6jLhjxceHVh+HJmsk+JzoBABBf/7EETxAAA9ANFFGAAIAQAZ4KMAAQKAGUSY8AAAJ4FoExAAAOqSiaxyNxoAAJh+Ti4z6k425YjNY/NJ5ubF6aqHZbyyUy+ykaytT/eIaky+8izSw49Jlm5qRqQoEGgAAAAyC4ePkUNh//tQRP+AAngs1X5k4AAi4uprxogABlQvXfzBgCg2AuejngAEgvkQroAHGqVQlABH1sK0AdDoVGitwC1mkmFpB5pMQU1FMy4xMDCqqqqqqqqqqqqqqsqgAAAEYOMDsuEIZiQ+NL1BjYAABrXEeIEgZjo+KXoBiiKRppQDT4CxbJpIDT5MQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqhQAAAAEyJQAAAkbSMEKaf/////y4LiEqkxBTUUzLjEwMP/7EET8g3EMB1X5KXiYCcCp6CQFEQH0G1nBBSAoHwCmgJAAAKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqsAAAAAFInmcxlAJoBKtA+AAC2UjTEFNRTMuMTAw//sQROiHcFQHT8EgMBgE4Dn1ICABAFgHNASEACAOgOeUYwAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqQAABUON4AAAABgSiS4jLAhxSkIBggEcIAWKOABQABNE2DCBMQU1FMy4xMDD/+xBE54fwEwFOASAACAbgWcUkwQEArAdApIQAIBOBZ0DEhAaqqqqqqqqqqqqqqqqqCkRIAAKqOw/wIABRhoiwtJFx6wUYAAAD4yTYIyqQkBYtFYrEotBwG5nGBQoBakxBTUUzLjEwMP/7EETxh/B7Bc+hIcAaBcAp5TAAAUHIG0CEhwAgEQEoQJMABqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqrkwAAAgCGCUtnxIAswAAAAHesicEGsdRPwVCVq1TEFNRTMuMTAw//sgRP+Dcb4n0emaGMoMoIn4JYsBAkgdToGwQSgjgqjQYJhEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTAAAAALClg/RgAAAACXYdIoAACzUKkdDqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGT0h3B/Bk9B4WAIDuDKBGAsAwEIGT0GgSJgGwMoICAkTKqqqqqqqqqqqqqqqqowAAAADVcd0KYhQAAccDMKAANOdUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZOmPcDQB0yFCAAgF4DnlPEABAQAFOggAAAALgOgA8IAEVVUwAAAABdSAoAAAE0jBIu4Al1AweMJhRgDfaCAoRmOqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqg7WAAD/+xBk54dwOQHQwwEACAQgKXBgAAFAfAc8p4gAMBOA6CDwgAQKFUb0ZMJBPxXAcwAAAAJA8C2G14Cn1copAEAwTgHWagpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETvB3ArAU+pIAAKCGA52GQgAQHIEUCGYeIoHAEokPSABKqqqqqqkIAAAB+CPLPgIWGAAAAAOvjWAAwGkiAAIGwl6kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQRPSH8JkFT6E4yBoJYHqUHMkBgawZRoSFgCANgOkAwQAGqqqqqqqqqqqqqqqqqqqqqhwAAAACjDgBmUKAANOYdIxuTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE7AfwYgZRQeMwKAcAOmg8IAEA2AdBBiQAIAmAqoBgAAeqqqqqqqqqqqqqqqqqqqqqqqoUAAAAAYXVFROEASiA+9VMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTqB/BDAlDDCQAIB4BKODTAAQDECUiGGAAgCICpAJAABFVVVVVVVVVVgAAALghGgAABPUYjgAc8QfoAHAAAVGBNlUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQROeHcDwCU0FpAAwCACpwMAABALQJToYYACARAOqQkIAEVVUbCgAACVGDSyQjQYAAAAAgoHugoQQATXrSKAA4RAYmTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk7QdwOQFUQYAADgZAOgU8QAGBABFQhITAICMCKJDwoASqqqqqqqqqqqqqIAAAACUA47hgAAAAPAsKsFgkoUACJBhMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETwB3B0BFEhmHiKB8BKCDzAAQFQFU6CmSCgEADoFPCABKqqqqqqqqpAAAEIIQK+gAAIHwpEADQGg+WDPCAmAQECFUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQROuHcFUFz8GBGJgHIEqIMGABgIgHQKgEACAVASlgwQAGVVVVVWKAAAAuDDADj1IAAAAqCos1MQAEAsAIPaBgYAArTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBk5gfwNgFVIOAACgKgOeAkIAEAuAlKh5gAIAaAqACwAARVVVVVVVVVVVVVVZAAAABhQGRSkAABCIhU4JgMBteBwo1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTlB/A4AVOhYAAKAiApoDwAAQBkBzoHhAAgCICoAMAABFVVVVVVVVVVVVVVVVVVVVWAAALhcJIEQoaCo4dGAEIN5kxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQROoHcC8B0KohAAgFoDoFPCABANAJQwekACgZASnQlAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAAAQiOagAAODlTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE7QdwVQPTISkAGAcAOmgk4AEA6AdBBJgAIBgBKNCUgARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWvgh1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTpD3A/AlLBKQAMB4BKGCRgAQBkCVIDrAAwEgDpkCWABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/8RExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOqHcDcCUCmMAAgFADn1KEABAPgNSoYwQCAYAWjgkwQEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk7AdwSQLSISlICAgAWiQwwQEA5A1IgKTgIBMBZ1RjBASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGToh3BCAtBAaQgIBgBZ9QUhAYCYCTikrAAgCwDn1GCABqqqqqqqqshoYBAAAAAAAJsoRYZy3Rhu5hAAAAAAAAJNG1xHQ4AgEAIjBxVpQMbEoBPZYbBIqNf/37+enmUkEAAAAAAG//sQZOYHcC4BzqksAAgCIDnwHCABAJAJOKY8ACASgSegFoAEvCYfqSAABobIU45ZCgAAAAAAIhgZYJA4TjFZxUBMHgUxIBDCwKPgEo0efzX8EPGgwxQAS+ZkkOF9RoVP4iwkfHJ7cSb/+xBk4o/wKwJOKKkACAQgChUAAAHAAAH+AAAAIAAAP8AAAAReWgSIiE0hlG3kvhxGBGAwYhQaOtJSFljPmvNOA23uikvyY0/byxmii1fC/hzPPv/DIVW7g/2/fKLKBl2AAGAF6AAAAP/7EGTfD/AAAH+AAAAIAAAP8AAAAQBYPzoAgEPgAAA/wAAABAAEoI4GYIiY0WV+f9LQVSAADdZbwAABGr/WuqGiQFASDpJkQxzgJHzKxbbuzLaJ/sixtkAxNy24VLgr/BcUMUk6EAAb//sQZN8P8BcAzwAAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAEhM8AAAAUBqQ0FCJRQkbRYRR5NdinYAAAeYa7iwVIIEe9uD3siTJd4tkZ2IumL18s/r5p8LLEOQtp/sggplyjn+0IgcD/+xBk3Y/wAAB/gAAACAAAD/AAAAEAAAH+AAAAIAAAP8AAAASAuiGEAA2CH3ACEDjQD45lM5DgugwD1wYkK/EFKbMqZBAABodvuAAAEyakpdVyVI2GAtulu0EyJBxrj8cWez9Un8fVW//7EGTdj/AAAH+AAAAIAAAP8AAAAQAAAf4UAAAgAAA/woAABANutv5XIQAAhwj8AAAAQIs6cAUTimHwFAD+sd+5o0xlZIQhocbRTlOYhOgAByY8ICkhoQwhWUiTiyJG+MOaAEUAUlVA//sQZOsAABAAUAYAAAAAAA/wwAAAAfANQpjwAAAlgCkTAAABy8JkYeHEyEgYA1JVn1QLlGIDoAAAAACo4obAykB5Q6PuTYlVWgFMgAAAACoYiwwJobuB+V2hCeS6clmmIQYAADQASAz/+1Bk/4AA3glTJmQAAAugepTCgACO6IdNucwAAGyB7nsGAAA0T6Ih1xHBku0CAO4AEtB8igDLS0KQDQEHzPoRIAAdQmLxIIJLwhiaAGD4sImDEEgAAAAAAcCAJwjRixMsQacgKqGBQoAAMG9Hx4mGgDPJUiMDhYFaFAcAAqgmIVBAOEgSjWJjAdU6LAAAM8RCePg6n4JhlwygJ3JsYACUTAATAy2DQSEKHItWkCYYAAMRy6WCYVFhhKcTquYZ54+5gpgAIhoAADhQVKQIIDb0//tAZPiBEYkK1W9owAoYYMrv5IABBjhTV+ywaqByhCr8lggkKpAIANNMRdA8FBYCAAAAAAKYLgkkDZnNqiAmmfFiEA9g5rcKmFBYdiShhcmtCshBsZeUDFimJx3nYT3bgXhdk7Wh0G6qSfM94LmP8vROR5qpc2Qn//hlAfEPUrchpzKI1xKKhv8pgNRrQKAAAAEAAAAAAAXwcP0d5uBK1Xaipexqf/cAAAJM6pwAAKBsbKapbkT/+zBk9YMxTApVefhJmiIhGq8ZLAMCsCVrxiUkIFsEa/iTJMyAg0wGsjKrz+tzBCkhHutbpbGBQxpmMbZ5wESpX/WoaBtBVSYTx0AlfwAAAAAIBgImHS5wPQVGAAAmiGu4AAAfh3JC6jQWhMPKpZsKiMg4+DiJBU+FseRrE3lxFAOKy9yf8xB2mR+dBlJaSHPgPgAAABE7RiOQ1WT/+yBE9YMwoQfX8MlImBdg6u4tjAFCLB1fwyTA4EgDqzimGE2FzKcGII24SQYGv+XeH+iUAAAJh31+YKdmokGvPSpujyou0pMYwsB5renDpYrYaiL2MedMAsDSdKQ4vXz2pSIAAIAH34BxbBgmqXUQswmy5OBQvZiiHW9MuGpNqRUM//sQZP0DMJQG1KHnSQoToNrOCEkBQogdU8SlgmhEA2nQkyRNCgdAqqowACkADgAAAAFUtjID9R5Qoaj5Runqcwm4Fs39KPkAFwBwAAABCeNw+iA4DwIkxwTPDTRd363i8ugIUgAAFpb/+xBk+QMwhwZRwYlJihCA6nQZKRMClB1MlMAAKECDKRKSAARTEoNIio0WgsHWGldKYgcwAADwwqNsiEQTFBoYaA0KmWIBcAAAAAALE6WBC4EzAgrDspWPEswyEESAAAAARfQH4PiBUP/7UGT3gAMnHVv+ceEgHUDbPseAAAZ8X1W9oQAgQoFue4YABazoF1M7ARSwAAqj71ksIMEx8dCKEjQoG+kDwALkDIhWIqaJujMjkzcCJIAAAAAAIqYDgs44Ho9VCUakAShHglRIoAA4HYrD4/Kp0oBqPHGZPjvgCoBTxLrLGCmNQEAAAAAAXFRMGAYaJAaaGUKrO7IcFmHAh+zQZqNxbA0QIT4M0DQcQb0Anphw6rbzDbL2UgkLg3Gxf/+rGgEQCLUV1K3VXb///lt0U3Xa5Dj/+1Bk6gERmRpVeykbGh3hCr0Z6QkF0CtV5+DDYI+EanyXpFzAH+VHImu/3pySzQvpAAAAAAAAAAAAfhQPKJ68MOj8gCfbnvMovXAAADaHWm8AABr8rtNgQ2h9fBFeYnIWTA4a/rM/T40lOHxIDDFmFtWo8tfmN1mEjOt2ESAAaAJ6AAAMsdPukIcisNI6K32L/1VNgB7UsQAAI7w324pYLjMZhlwmVsPT1MFozejXLQDM4iRKPQWM5kAWuS+whPIzIuz6+wZ9Iv1Q4gAA7g/+//swZO4DMPAI1nnrGogaYOqtPSkTAnAbW8YlgmhMg6t4lJQlAERKquCwlDBZ6zlotMnw95AQAJxo1ZaKqXUgAAWIjf+gAAhLOHgAxDbirmWIykjDrhb9SuAiylhHMjUjuRkzhRQkWRrmrFQt/qia/4TEa7emQgAAKADfgAADeeHoQVZwKlESIxF7vG5pnpf1E1E0D4RAAAdgD7gF//sQZPqDMLEG1vHpYAoSgOr+JCVBQoAhVcekIWA9g6oQZKRMcW+V0pJJye5GBSRwl8BKWwcO/KILKIdE8WozEAOAAOAAgbw5p5kQ4aA02FlyP8wqtmEwegAAAAAFQ40WgoyuGjYqCrL/+1Bk9oAAvgfUdTAACBNg+kSmAAEMTHll+bwCQHSDbvswAgEM3NmqpjAXAAAAAAA4eIgWIhAgHsWMSOwzKJQgAAAVEVcCUUBLDAgQHtHBV25gVgAAejcwlGqVsIkNMYDpFtW5ZAR4AAAAAAH2ZqJoFR8BMRBgQwjC1OgCUAAAAAAPhaoMiKTSozoPykZ9DCCZAgAAEFAaiwmh8QhePJ9Q9frskBQABgTnBY0dLBYQLEbYaIJMQVYgoAAB+soyTn+dYDDiNszs0VGAAhvykeAX//tQZPcBEZUaV/9koAoagMq95gABBkhnWeykbGB9gyq8lLxMZLA7tiKSGyIkAob4MiYHFxkwbJmXofuIAwlBERiYlQhQooIJVUxBTUUzLjEw1gSYAADiZgygBCZQaQmSscKFAAgLxSRjcDwNroCU8zpRUBzYJhw/IQPB5seiTCYAAKD8xMSqB4ykSIdlTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVW4oAABJh2Q2yjBSOL1oAAAAVyBkphCOIRrRqnpkMuEY1M4wEs8I6ophgP/7QGT9gRG8GdX5mBk6H4DqvzHsMQQwI1XmPSSgVoOrfJSIzKJMQU1FqqqqFpAAAM/ScjDCEfRyygAACPhnYAEGLmJRBAAAAAA5GjRqg4Wk7AptuANhAAADb+hycfT6xSLOSh/Y54t4fkCigAAAAAMAXpmC9CmDAvdULLQAAABjCZpG3Jr8VZ/IoMCUo/Pfpl16i4akZk0QDMCoqptnWAAAAABcEQJmRjo3AKSCBEcNgDVhApMI//sQZP8DMLwI1/FpSKgUwNr+JMYTQmQbYcY9IChLA+w48ySUMTnprxpiLteaqiv9p1HpvWsV9U7vY0wWFT5KcaO3hH2UBIVOJssv7pQCAKJnRHRXIxJmmAAAAAIbb1o4OOqqAv+46db/+yBk94MwswdXcekwGhVA+r48bAECcB9Rx4WAIEYDaZCUpE1cAwrQ1QMTkysMyBjVxQ81MZJMG+QJaoHg6e5fs+KuP/zpqyyHm2pjs0z+b24khkbnlT5WmTOtn15Ydrb6UtWGQACXcJ44AAAmYrKXdpaCmiU2naVionMllMDZcFcs//sQZP0HMIUHUqEvSIgQQOp0HYYHAeQbSIYlICg4gyhgtJhNAyoaBpn87+CoKyxgAA7w2HAAAG25U8sjVNTQ9BJAkbY4j8c7P58cpbmbqpSsY3/yl7VN/1BlAQEoTUwEAAAixeeAGZH/+xBk+4cwewXSoShIChCA+jQkySEBjBlAhJkkID8DaFCQpAUGAlESkzJiBTIAAOHqhEguoJqIT2CPB0xe5SAyn///ySpLRAAAH5CUUC4Vkegd4UDcAAAAAqKCCysUXB4AYdyF8RgALf/7EETzB3BkBlEgaTCYDQC5+CRJAQEsGUEApSJgHwMn4BGMTCEdC9iJE1FBRIMAS5EQll2R6CYfgGpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqQAAAAJA0GfqDsEAAQICvRwwE8//sQRPwAAFsEz8UkAAoLIJn4oYABQfAVQJiQAAhbBKkTHgAAAgDJ3/////8ucCpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqsAAAAEMpx//////6IAAAuyHDgAC9E+P/+1BE/4AAewZQpiAAABsBKoTMAAAJVJdX+aQAAWiXa/8ysEn//////lkEQMDi6kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpAAAGAGVCgAAABxgBTAEgmgCghCkBqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjAAAACBjgmwAAAAC6DBQKjjgEtMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqq//tARO2DEUcH1f9gAAguxGq/7AgBAfgdX8AFgCBvBGt8NLxUqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqYDRUsHioRUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVYqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE9IMwXgfQwCFYOBNg6q4AaQNBXB9DAwkg4DkDqNAUsI2qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqGipNBUBAEBAIMAAAACimeFMAANaRuBtBg1vLjfX9xaf7CLf+AP/7EETsh3BNAk9BJwAICQD55RQDMwEoBT6kgAAQCIDmgGCABAxZz//55z//8WikzuoFAoGAgFAgAAAAAFimRcXgGGRJxtF8DQBB3eXG85f3DY5/sQV//Gijch//sPuI4O//9yYgAADv//sQRO6HcGICUiHiAAAFwDnlPCABAVgFPweAABASASgUsQAGbLDCyg+nb5NAAAABUGGqlJlHFL3hwaHWK4eJZQHRJWxOBAE0pTNCZQqDpXRpw04XIbysljJZlUUNtJqLIVqekYFePUz/+xBk6IdwLQFQqWAACAbgSmQYYAEAnAlDBIwAIA+Ap1TAAAUtiFF7IaYR+F4JHfEjYk/HPml0XI5nKjifNzzMWWKzNlZpnjZDvqniuoGvrsWgoAAABWpoZoVjTSpQygAAAAkJGyzPEP/7EETnB/A6AlDAqQAIBuA5+DAgAQBcB0KkhAAwCADnwHCABPI7wwbBaB3yhbEAeIa2yfasFwwAeVQdAs02/w40pRZ024wyJKh1ypl20wS8iNENXIAhtypmMS5eyIsPMEXLBfOVKGG+//sQROEH8BUBzgECAAgAwAngAAABQGgHOKYIACAAAD/AAAAEVKkui9eZiy5XzjFa/2n5N2pzueUSaR+/w3E4rLOfj8qxJGzdREAkfFZvrfwAMo3Fb+4efYqhGiMsf6XSL8uW7/1QzgL/+xBE3o/wBQBPgAAACAAAD/AAAAEAGAM8AAAAKAAAP8AAAARFtGcSd7/Ymwmh2re/+HeNvLO/5lPyZDAVe4ZrbFwAJVDcO39R1uQqseQuxW51oP7uHKXtUBAQzgJErE1Est6kguMExP/7EGTej/AAAH+AAAAIAAAP8AAAAQAoAzgUEAAgAAA/woAABGf6j08qJTuhJZNNKsQAUQ6v9ZRkcbBaZLWUVCCsFRYeUa1NjwlFFXFY27+JI4pNiTeJ//+1zPCHvUd3ADaaaP8rMv6///uARP+AAW0v0mZQQAI1ReqdyhwADtS9Yfmnkgn2F6w/NYIB8MSdveoggLKVsO3J7DMBECQjCHhWJzk0xMmIYF1X/1Z9mDZVZ3UEgHAAOAAAG6AqsIwJ0EnOTQsi53/8sWIlWaDAFcGAD1gAA4Gi44zoh2qB9FUPYJsaiFN//5s6HT3qCuCoDL7DwNIk2CAExzYkoGQOhCFMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWIAAAfoDRMAAhYB4YUBIKkzUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVCCQb8CABRYJWAkADAFAEDBAAAAvVIPFA4xAAMl6N7DByGwFWLM/+/nb8w38SwkET/IAPJDT/yaMQb/88WFxoPFf/9BsDwSg//yaERLQ4ADgCgDADAcBgIAD/+1BE+IERsBFZf2BgCjliKz/sDAEFxC1X5ODEaLeSq/2AibUAAWK7ETDlgYMvUphI8Ybfn//0lj0X9yf/PHyZn/igBgkBOZ/+eOk0/4DNWoGdPNTO0RTAENIGLqTzUxXwBZUq0f5YMhQrtrdLS6Fex9WaHwAodDBUxpDkPBOC66KPEEV/4tVqTf/9dva4a5hmZm/Uk1x34bVO9UwBI73NTPYkAB7j5J9DGEK1DA/FIKiLBQ2ZfQnL/a3tINKOV/5yt7VyKS/OVWnJYgoqW43K//swROiHMNoHVPhpSJgjYQqfJekVAMQZQwCBAHAsA6kgBJgGpK7xXWQoKOlVhCACh3dvsAAADwaPLikYbxwgiZCWxZHrjsdvo0kv1u0ljQ8pRS3EluwACOoBG+AAABgUimayucj9GklA6SrRI/EIalcDB0RPQloYwMfgXgJMbGU9h9IETvEiNk7/+JSqUJssEgADDUdEsaDIh9RM//sQROYH8C8AzyggAAgKgOnlACMBQAwDQgCAACAAAD/AAAAEQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoLMAAAHNY4wlFeO2IxAAAIhbE8Cx96yAAEG8jAAPGH5KkxBTUX/+xBE4I9wBwDOAEAACAAAD/AAAAEAHAM6FCAAIBAAJ1aAAAQzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqhX0AxwCUVsqTEFNRf/7YGT/gAIpL9N2bOAAOQS6z8wcAAmAqVv9lAAg9I1rv55gBTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpAOEAAMCZ9sRILdWhhJeoBTZ8pIYdgwMBHS6adMhtWeHX6b2XC4WiUXBQAAAAACsp1HTDRshR1d2i3MEnaK3nP32ve/fFP7rqiv/d8h3G/+lYomJRUUDz//e9KIEc5zwd/mnndG4AwIIw6AgAAAAANN0WQWYfQwZV3YBILczPLX5z8/r2Pt+pC+5zuIKq/bIweKLgIBf7+g8ocb/D7SIQ7MzJdYQABcd4EpAN9MViIjCBQRpUHYuDQ1NYFxu7mq622JP/7QETsBTE/F9V5Lxk4IWDqrxnpBwMIH1XkvSRgMYMpUBMcHBi3z4pT2gdIhELnDhRx9Nj3ST6lW0zNTN3NBQU3b4QVeDtdrbrGAAK0PCoDiNUqpQrQ3kMhDcst2y2dxzr0FdIGtCST+fCEOmgVJAJAcwcKOT3FfUkrWv0k0N4b82UcG11qDWiAAXd4bW8AACT5ZJB/hSBkDMPLFR3EP1tRyCqY2g0gUK/+Wnv++UWFx0owAANU//sQZO4DMFcG0UAgeBgL4No0BAwRAJQHOqMAACAUgOdUkIAEFHItUuoEwAAAlvKNIVdUMxQs2CcXzSpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqCdx7siD/+xBE4YfwGAHNAeEACACgGeAEAAEAbAc+pIQAMAIAZ4AQAAS6jeHRyi9PABKDNdVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVcAAAP/7EETuA/BlBU+hIXgaAIAZ8AQAAQJYHTkVgAAgAgBngoIABAApkPYwDZAiOxEISkxBTUUzLjEwMKqqqqqqqqqqqqqqqjpgAAAMOxVbAQCKFKIMAgAAABylrc8gJBzjNEAxmi4z//////tgZP+AAggnVW5lAAA6pMp9zJQACKiHTf2TACkMkal3sGAF0/8e9AAAAAAchLnqAgEu7lmzssjgIAAAAAuDAHUytgVBoEvTgnDCrU1uWKeEJ/t1vjNWMjNjRc2FIfvfY6zwIID5V1PXZ05rK4as6WGhsarlxaSjUEogTht//ZxCZYi7JIAAAAAwwgAAAAZIDrAJsUIbEhHYbkNb///+8obz+Cf5wuF89xkKQBDzEx/+AAAuFUIwTCILA0FgbBpAofISVAiDYhMUgI0XMZnwXYCMdvobtZnekgAAADaFe851ATqoTEFNRTMuMTAwqodlAGYAgDgAAAFThJlewkifqHk1uB8X//sgRO4DcVcO1XgsGFoHALnlACYRAfgfXcMFIiAOACeUAAAE+eLfyoKoAAAMvBretiRwAAD7XACZITA0awMJTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqogAAFIcQliUAAASEZAQloNiYf/7EGTmD3AjAc0BgQAIBCApsCQAAQBoBzIHhAAgEYDn4PCABJlMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUH1RgAAAAgcmCDBAChMrD8AkC4//sQROUH8DcB0EHhAAgCwDmwJCABAFAFPAYAACAJAOaAYIAEtUxBTUUzLjEwMFVVKFaAAAWrh+iHAB4HQ4SPwwAAAAC5sPYxJAAAIAb6X2JIXgKtHljHkir2AQ//4IQfOQCEfQAMBxb/+xBE9QAASwFQxSAACgIgKbCkgAEDYBlEmPAAAB8BKBcOAAEhbRBjTV+ABjYwYOYUOcYwkWjkZSInhBoqOsvw5UP/4ZrtU/ZWVVWZNaNMOjMFKaX+JsQU+AAAAWUUTdKJEkQbZR+gt//7UET/gAKZKVTuZWAAJsM6XMkIAAW4J1v8kIAoMYKn45IABAACjThaEaJlCpgGSUbYFXkBNcMCqkxBTUUzLjEwMKqqqqqqqqqqqo3AQAAD2UmQiAVcfyIAAFYbby0gJM0uLypZAOyM6kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqhQAAAABB4PQAAAccd4AAaay//////9QYC0dTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE9oPw4wdVeM84uAcgOcUlIAEBmB1KgJkiYAcAp8AgAARVVVVVVVVVVVVVVVVVgAAAACNtVQAAACEyNAXBwGF+lUpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgP/7EETnB3A9AU8pIAAIBQA59SQgAQBIBzgBBAAgEAEn1JMABgAA8C1QAAAdXFkPggA0AGiBgBwUVpd50QsWgFaeQGuCCkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqglmwAAXQk4VYYhs//sQROeHcBEBT4GAAAgHoEn4HYABALwHQQYAACAPgOfUkQAEcsIjAQCYgf4AAACagNqNqjOMJBcTuFKKimA8gwAARQGqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE+gFwfAbPoLhJCAbgOjgkwAEDNBtHp70iYCMBp+DEiAWqqqpR0QAAAIqj+4CrVQZggAAAAGRZGECAKhjcNGAAa1VMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EET/g3GWINDjSRmqDaCJ+D3pEQH4GVKDJSJoHAInlPCMBVVVVVVVVVVVVVVVMAAAABcJxK5AAABqy8iBQAAGMTBiokxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQROyHcGIGUiDBSBgGoDn1PCABANwHPweIACAOAOhUwIAEqqqqqqqqqqqqqqqqqqqqqgV0cAAAACFAKAAEjwdzABQhTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk6ofwOgHSIYcACAVgOhU8IAEBQAVBB4AAAAwA58DwgASqqqoQMAAAALAbQYAAAAAHMjpCsYHu9FUSAZmOoFAJ0TVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVEdoAAP/7EGTnh/A3AdDDAQAMBaA59TwgAQCABzyniAAgC4DoAPCABBybqFpyKgTw4wofFAAAAAUeFWEtrMDwrCKAMGx+zAAJQ0xBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQRO6DcCsB0CmBAAwFwDoFYCABgeATOwNh4iAegegg8wQMVVVVVVVVVVVVAOAAAAuE9AaEAAAAAvWCJRARnCgAAFaqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBE84dwjAVQoTlAmgogepQlIgMBXBVGhI0gYBMA6eDBAAaqqqqqqqqqqqqqqqqqqqqqqjAAAAAFHowUpoABj6MAys5MQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EETsh3BmBlIhg1iYByAqWDAAAcDABz8DGAAgDgBq4HAAB6qqqqqqqqqqqqqqqqqqqqqqqhQAAAABlYbpAASFYAQcoExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOiH8EACUsHrAAwGgCoFPAABwKQFToSAACgIAGlAsAAHqqqqqqqqqqqqqqqqqqoLUgAACcDVFMLAAESkIgADFYBJTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUXW0D/+xBE5gdwDgFUgSAACAYgGqQkAAFAtAlOhggAIA4AaqDAAAcAAFAWikbU6MUAAAABwjHcE6OUMm/FnQDgGgXn/////5RMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EETsh/A9AdUgxwAMB6BKaCTAAYFwEUSHieAoCoCqAJAAB1VVVVVVMAAAAENKIHv/////0wAAAuRHBSACBuyAKCwp2UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQRPAHcHgFUSGPYQgHgEpEJQABAVgXSoMZImAPAOrgYIAGVVVVVVUTgAAAMEYHohgAAAASGAzUQADYEAS8ZIEAQFmyTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE6Y9wQgHRwSAACAfASpQtAAGAXAU8B4AAIBMAqlBgAAVVVVVVVVVVVYGAAABYAUhg2AMSA7wASDmINlYBgYfwONVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EGTlh/A3AVRBgAAOAgA6ABggAQCMBUKmAAA4CgDnwLCABFVVVVVVVVVVVVVVVYAAAmJwNRhQAAEHEKFcMgRkGBwCFUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sQZOUHcDIA06GAAAoBYCowGAABAHQDTQYAADgPAOdU8IAEVVVVVVVVVVVVVVVVVYAABsYArgAAAAMD+JCHYAZdQsCdTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+xBE5wfwDQFTAWAACAbASeU8QAEA3AlKhhgAKA6A6AD0gAZVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWAAAQzgAAEKBVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7EETvh3BaA9OgyQgaB0A6dCUgAQDoBzqnpAAoKQEnVMMAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/8mX4MykxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOuPcGcBUUHgAAAF4DnlPCABAIAJTASsACAUASigZoAGqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk64dwQQHUoQwACgdAShggQAEA4AtMhKQgIBaBaKBWBASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTqB3BCAtMhKwgIBCBJ0CEgAQDAC0EDLCAgF4FoIGYEBKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOgPcDoCziksCAgFwEm1FSABAHQJPASkADAOgOcU8QAGqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk54dwLgHOqewACAaAOgg8IAGAkAk0pqwAIA0BJsBUgASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTiD/AgAdCoQQAMBEA55QggAQAAAf4AAAAgAAA/wAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZOCP8BUA0AAAAAgAAA/wAAABAFg/OACAQ+AAAD/AAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/+xBk3Y/wAAB/gAAACAAAD/AAAAEAAAH+AAAAIAAAP8AAAASqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EGTdj/AAAH+AAAAIAAAP8AAAAQAAAf4AAAAgAAA/wAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQZN2P8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo=";

  // src/background/managers/AudioManager.ts
  var ECHO_TAIL_MS = 800;
  var MIN_SPEECH_WATCHDOG_MS = 20000;
  var MAX_SPEECH_WATCHDOG_MS = 120000;
  var SPEECH_WATCHDOG_MS_PER_CHAR = 100;

  class AudioManager {
    session;
    speechWatchdogOverrideMs;
    processingSoundActive = false;
    processingSoundGeneration = 0;
    speakingUntil = 0;
    speechQueue = Promise.resolve();
    speechGeneration = 0;
    constructor(session, speechWatchdogOverrideMs) {
      this.session = session;
      this.speechWatchdogOverrideMs = speechWatchdogOverrideMs;
    }
    get hasSpeaker() {
      return Boolean(this.session.capabilities?.hasSpeaker);
    }
    isSpeaking() {
      return Date.now() < this.speakingUntil;
    }
    async speak(text) {
      if (!this.hasSpeaker)
        return;
      if (!text.trim())
        return;
      const generation = this.speechGeneration;
      const run = async () => {
        if (generation !== this.speechGeneration)
          return;
        this.speakingUntil = Number.POSITIVE_INFINITY;
        const watchdogMs = this.speechWatchdogOverrideMs ?? Math.min(MAX_SPEECH_WATCHDOG_MS, Math.max(MIN_SPEECH_WATCHDOG_MS, text.length * SPEECH_WATCHDOG_MS_PER_CHAR));
        let watchdog;
        let timedOut = false;
        try {
          await Promise.race([
            this.session.speaker.speak(text, { stopOtherAudio: true }),
            new Promise((resolve) => {
              watchdog = setTimeout(() => {
                timedOut = true;
                resolve();
              }, watchdogMs);
            })
          ]);
          if (timedOut) {
            console.warn(`speaker.speak did not settle within ${watchdogMs}ms; recovering speech queue`);
            this.session.speaker.stop();
          }
        } catch (error) {
          console.warn("speaker.speak failed:", error);
        } finally {
          if (watchdog)
            clearTimeout(watchdog);
          this.speakingUntil = Date.now() + ECHO_TAIL_MS;
        }
      };
      const queued = this.speechQueue.then(run, run);
      this.speechQueue = queued.catch(() => {
        return;
      });
      await queued;
    }
    playStartSound() {
      if (!this.hasSpeaker) {
        console.log("\uD83D\uDD07 start cue skipped — no speaker (display-only glasses)");
        return;
      }
      console.log("\uD83D\uDD14 playing activation cue");
      this.session.speaker.play({ audioUrl: START_SOUND_URL, stopOtherAudio: true }).catch((err) => {
        console.debug("Start sound failed:", err);
      });
    }
    startProcessingSound() {
      if (!this.hasSpeaker) {
        console.log("\uD83D\uDD07 processing loop skipped — no speaker (display-only glasses)");
        return;
      }
      if (this.processingSoundActive)
        return;
      console.log("\uD83D\uDD01 starting processing cue");
      this.processingSoundActive = true;
      const generation = ++this.processingSoundGeneration;
      this.playProcessingSound(generation);
    }
    async playProcessingSound(generation) {
      try {
        await this.session.speaker.play({ audioUrl: PROCESSING_SOUND_URL, stopOtherAudio: true });
      } catch {} finally {
        if (generation === this.processingSoundGeneration)
          this.processingSoundActive = false;
      }
    }
    stopProcessingSound() {
      if (!this.processingSoundActive)
        return;
      this.processingSoundActive = false;
      this.processingSoundGeneration++;
      try {
        this.session.speaker.stop();
      } catch {}
    }
    stop() {
      this.processingSoundActive = false;
      this.processingSoundGeneration++;
      this.speechGeneration++;
      this.speechQueue = Promise.resolve();
      try {
        this.session.speaker.stop();
      } catch {}
    }
  }

  // src/background/managers/MiniappsManager.ts
  var CACHE_TTL_MS = 30000;
  var UNSUPPORTED_RETRY_MS = 10 * 60 * 1000;
  var MAX_APPS = 24;

  class MiniappsManager {
    session;
    catalog = [];
    fetchedAt = 0;
    unsupportedUntil = 0;
    refreshing = false;
    constructor(session) {
      this.session = session;
    }
    getCatalog() {
      this.refreshIfStale();
      return this.catalog;
    }
    refreshIfStale() {
      if (this.refreshing)
        return;
      if (Date.now() < this.unsupportedUntil)
        return;
      if (Date.now() - this.fetchedAt < CACHE_TTL_MS)
        return;
      this.refreshing = true;
      this.refresh().finally(() => {
        this.refreshing = false;
      });
    }
    async refresh() {
      try {
        const miniapps = this.session.miniapps;
        if (!miniapps?.list) {
          this.unsupportedUntil = Date.now() + UNSUPPORTED_RETRY_MS;
          return;
        }
        const apps = await miniapps.list();
        this.catalog = apps.filter((a) => a.packageName !== "com.mentra.ai").slice(0, MAX_APPS).map((a) => ({
          packageName: a.packageName,
          name: a.name,
          ...a.description ? { description: a.description } : {},
          running: a.running,
          actions: (a.actions ?? []).map((rawAction) => {
            const act = rawAction;
            return {
              id: act.id,
              description: act.description,
              ...act.parameters ? { parameters: act.parameters } : {},
              ...act.outputSchema ? { outputSchema: act.outputSchema } : {}
            };
          })
        }));
        this.fetchedAt = Date.now();
        console.log(`\uD83D\uDCF1 miniapp catalog refreshed: ${this.catalog.length} apps`);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        if (/NOT_PERMITTED/i.test(message)) {
          this.unsupportedUntil = Date.now() + UNSUPPORTED_RETRY_MS;
          console.warn("\uD83D\uDCF1 miniapp catalog: not permitted on this host — app control disabled");
        } else {
          console.warn("\uD83D\uDCF1 miniapp catalog refresh failed:", message);
        }
      }
    }
  }

  // src/background/constants/config.ts
  var WORD_LIMITS = {
    speaker: {
      ["quick" /* QUICK */]: 17,
      ["standard" /* STANDARD */]: 50,
      ["detailed" /* DETAILED */]: 100
    },
    hud: {
      ["quick" /* QUICK */]: 15,
      ["standard" /* STANDARD */]: 15,
      ["detailed" /* DETAILED */]: 15
    }
  };
  var CONVERSATION_SETTINGS = {
    maxTurns: 30,
    maxAgeMs: 60 * 60 * 1000
  };
  var LOCATION_CACHE_SETTINGS = {
    minMovementDegrees: 0.01,
    geocodeCacheDurationMs: 10 * 60 * 1000,
    weatherCacheDurationMs: 30 * 60 * 1000
  };
  var PHOTO_SETTINGS = {
    enabled: true,
    previousPhotosToKeep: 2,
    captureWaitCapMs: 5000,
    visualCaptureWaitCapMs: 15000
  };

  // src/background/managers/MessageStore.ts
  class MessageStore {
    messages = [];
    seqCounter = 0;
    historyEnabled = false;
    truncatedBeforeSeq = 0;
    addUserMessage(content, opts) {
      const seq = ++this.seqCounter;
      const msg = {
        id: `u-${seq}`,
        seq,
        role: "user",
        senderId: "user",
        content,
        timestamp: new Date().toISOString(),
        image: opts?.image,
        imageSource: opts?.imageSource,
        imagePending: opts?.imagePending
      };
      this.messages.push(msg);
      return msg;
    }
    setMessageImage(id, image, source) {
      const msg = this.messages.find((m) => m.id === id);
      if (!msg)
        return null;
      msg.image = image;
      msg.imageSource = image ? source : undefined;
      msg.imagePending = false;
      return msg;
    }
    addAssistantMessage(content, sources, actions) {
      const seq = ++this.seqCounter;
      const msg = {
        id: `a-${seq}`,
        seq,
        role: "assistant",
        senderId: "mentra-ai",
        content,
        timestamp: new Date().toISOString(),
        ...sources && sources.length > 0 ? { sources } : {},
        ...actions && actions.length > 0 ? { actions } : {}
      };
      this.messages.push(msg);
      return msg;
    }
    updateMessage(id, content, sources) {
      const msg = this.messages.find((m) => m.id === id);
      if (!msg)
        return null;
      msg.content = content;
      if (sources && sources.length > 0)
        msg.sources = sources;
      return msg;
    }
    completeOauthActions(accountName, toolkit) {
      const changed = [];
      for (const msg of this.messages) {
        if (!msg.actions)
          continue;
        let didChange = false;
        msg.actions = msg.actions.map((action) => {
          const matches = action.kind === "oauth_connect" && !action.disabled && (!toolkit || !action.toolkit || action.toolkit.toLowerCase() === toolkit.toLowerCase());
          if (!matches)
            return action;
          didChange = true;
          return { ...action, disabled: true, label: `${accountName} linked` };
        });
        if (didChange)
          changed.push(msg);
      }
      return changed;
    }
    setRating(id, rating) {
      const msg = this.messages.find((m) => m.id === id);
      if (!msg)
        return null;
      msg.rating = msg.rating === rating ? undefined : rating;
      return msg;
    }
    list() {
      return this.messages.slice();
    }
    getTruncatedBeforeSeq() {
      return this.truncatedBeforeSeq;
    }
    getRecentTurns(limit) {
      if (!this.historyEnabled)
        return [];
      const now = Date.now();
      const maxAge = CONVERSATION_SETTINGS.maxAgeMs;
      const maxTurns = limit ?? CONVERSATION_SETTINGS.maxTurns;
      const turns = [];
      for (let i = 0;i < this.messages.length; i++) {
        const m = this.messages[i];
        if (m.role !== "user")
          continue;
        const next = this.messages[i + 1];
        if (!next || next.role !== "assistant")
          continue;
        const ts = new Date(m.timestamp);
        if (now - ts.getTime() >= maxAge)
          continue;
        turns.push({
          query: m.content,
          response: next.content,
          timestamp: ts,
          hadPhoto: m.image !== undefined,
          photoDataUrl: m.image
        });
      }
      return turns.slice(-maxTurns);
    }
    setChatHistoryEnabled(enabled) {
      this.historyEnabled = enabled;
    }
    isChatHistoryEnabled() {
      return this.historyEnabled;
    }
    clear() {
      this.messages = [];
    }
    destroy() {
      this.messages = [];
    }
  }

  // src/background/lib/glasses-format.ts
  function formatForGlasses(response) {
    return response.replace(/\r\n?/g, `
`).replace(/^\s*```[^\n]*$/gm, "").replace(/^#{1,6}\s+/gm, "").replace(/\*\*([^*]+)\*\*/g, "$1").replace(/__([^_]+)__/g, "$1").replace(/`([^`]+)`/g, "$1").replace(/^\s*[*+]\s+/gm, "- ").replace(/!?\[([^\]]+)\]\(([^)]+)\)/g, "$1 ($2)").replace(/\n{3,}/g, `

`).trim();
  }

  // src/background/managers/AnswerReader.ts
  class AnswerReader {
    session;
    publish;
    state = { status: "idle", mode: "auto", page: 0, total: 0, speed: "normal" };
    layout = null;
    text = "";
    token;
    timer;
    epoch = 0;
    queue = Promise.resolve();
    connected = true;
    connectedModel;
    disposed = false;
    lastSwipe = 0;
    unsubs = [];
    constructor(session, publish) {
      this.session = session;
      this.publish = publish;
      this.unsubs.push(session.input.onTouch(["swipe_up", "swipe_down"], (event) => {
        if (this.state.mode !== "manual" || !this.token || this.state.status !== "reading")
          return;
        const now = Date.now();
        if (now - this.lastSwipe < 350)
          return;
        this.lastSwipe = now;
        this.move(event.kind === "swipe_down" ? 1 : -1, false);
      }), session.glasses.onConnection((event) => {
        this.connectedModel = event.modelName;
        this.connected = event.connected;
        if (!event.connected)
          this.suspend("Glasses disconnected. Reconnect, then replay.");
        else if (this.modelChanged())
          this.suspend("Glasses changed. Reopen Mentra AI to continue.");
      }), session.onCapabilitiesChange(() => this.suspend("Glasses changed. Replay to continue.")));
    }
    getState() {
      return { ...this.state };
    }
    setSpeed(speed) {
      this.state.speed = speed;
      this.schedule();
      this.emit();
    }
    show(text, messageId) {
      this.cancel();
      if (this.disposed)
        return;
      this.text = text;
      this.layout = paginateAnswer(formatForGlasses(text), this.session.capabilities);
      this.state = {
        ...this.state,
        status: "loading",
        page: 1,
        total: this.layout.pages.length,
        mode: supportsPagingInput(this.session.capabilities) ? "manual" : "auto",
        messageId,
        notice: undefined
      };
      if (!this.connected || !this.session.capabilities?.hasDisplay || !this.layout.pages.length) {
        this.suspend("Connect glasses with a display to read this answer.");
        return;
      }
      if (this.modelChanged()) {
        this.suspend("Glasses changed. Reopen Mentra AI to continue.");
        return;
      }
      this.paint(0, true, false);
    }
    control(action) {
      if (!this.layout || this.disposed)
        return;
      switch (action) {
        case "replay":
          this.show(this.text, this.state.messageId);
          break;
        case "previous":
          this.move(-1, true);
          break;
        case "next":
          this.move(1, true);
          break;
        case "pause":
          this.clearTimer();
          this.state.status = "paused";
          this.emit();
          break;
        case "resume":
          this.paint(this.state.page - 1, true, false);
          break;
        case "stop":
          this.clear();
          break;
      }
    }
    cancel() {
      this.epoch++;
      this.clearTimer();
      this.token = undefined;
      this.state = { ...this.state, status: "idle", page: 0, total: 0, notice: undefined };
      this.layout = null;
      this.emit();
    }
    clear() {
      const token = this.token;
      const active = this.layout !== null;
      this.cancel();
      if (active)
        this.render([], token);
    }
    destroy() {
      this.cancel();
      this.disposed = true;
      for (const unsubscribe of this.unsubs)
        unsubscribe();
      this.unsubs = [];
    }
    suspend(notice) {
      this.epoch++;
      this.clearTimer();
      this.token = undefined;
      if (!this.layout)
        return;
      this.state.status = "paused";
      this.state.notice = notice;
      this.emit();
    }
    move(delta, explicit) {
      const index = this.state.page - 1 + delta;
      if (!this.layout || index < 0 || index >= this.layout.pages.length || this.state.status === "loading")
        return;
      this.paint(index, explicit, explicit && this.state.mode !== "manual");
    }
    modelChanged() {
      return Boolean(this.connectedModel && this.connectedModel !== this.session.capabilities?.modelName);
    }
    paint(index, explicit, pauseAfter) {
      this.clearTimer();
      if (this.modelChanged()) {
        this.suspend("Glasses changed. Reopen Mentra AI to continue.");
        return;
      }
      if (!this.connected) {
        this.suspend("Glasses disconnected. Reconnect, then replay.");
        return;
      }
      const epoch = this.epoch;
      const layout = this.layout;
      if (!layout?.pages[index] || !explicit && !this.token)
        return;
      this.state.status = "loading";
      this.emit();
      this.queue = this.queue.then(async () => {
        if (epoch !== this.epoch || this.disposed)
          return;
        const footer = layout.pages.length > 1 ? `
${index + 1}/${layout.pages.length}${this.state.mode === "manual" && index + 1 < layout.pages.length ? "  Swipe for more" : ""}` : "";
        const result = await this.render([{ type: "text", id: "answer", box: layout.box, text: `${layout.pages[index].text}${footer}` }], explicit ? undefined : this.token);
        if (epoch !== this.epoch || this.disposed) {
          if (result.displayToken)
            this.render([], result.displayToken);
          return;
        }
        if (result.status !== "displayed" || result.degraded || result.dropped?.length) {
          this.suspend("Reading paused. Tap replay to show the answer again.");
          return;
        }
        this.token = result.displayToken;
        this.state.page = index + 1;
        if (!this.token)
          this.state.mode = "phone";
        this.state.status = pauseAfter || this.state.status === "paused" || this.state.mode === "phone" ? "paused" : "reading";
        this.state.notice = this.token ? undefined : "Use the phone controls to turn pages.";
        this.schedule();
        this.emit();
      }).catch(() => this.suspend("Reading paused. Tap replay to try again."));
    }
    schedule() {
      this.clearTimer();
      if (this.state.status !== "reading" || this.state.mode !== "auto" || !this.token || !this.layout)
        return;
      const epoch = this.epoch;
      const index = this.state.page - 1;
      this.timer = setTimeout(() => {
        this.timer = undefined;
        if (epoch !== this.epoch)
          return;
        if (index + 1 < this.state.total) {
          this.paint(index + 1, false, false);
        } else {
          this.state.status = "finished";
          this.emit();
        }
      }, pageDwellMs(this.layout.pages[index].text, this.state.speed));
    }
    clearTimer() {
      if (this.timer !== undefined)
        clearTimeout(this.timer);
      this.timer = undefined;
    }
    emit() {
      this.publish(this.getState());
    }
    render(elements, ifDisplayToken) {
      return this.session.sendRequest({ type: MiniappRequestType.RENDER, view: "main", elements, ifDisplayToken }).catch(() => ({ status: "blocked" }));
    }
  }

  // src/background/lib/spinner.ts
  var SPINNER_SIZE = 30;
  var SPINNER_FRAMES = [
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlKSgkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABcHAAAAJl5eJgAAAAUQAAAAAAAAAAAAAAAAAAAAAAA2cGQFAAAmXl4mAAAEREwkAAAAAAAAAAAAAAAAAAAAAERwcD0AACZeXiYAACpMTC4AAAAAAAAAAAAAAAAAAAAAEXBwcBQAJl5eJgAOTExMDAAAAAAAAAAAAAAAAAAAAAAAOnBwTAAmXl4mADRMTCgAAAAAAAAAAAAAAAAAPk8UAAACY3BwIyZeXiYYTExDAgAACSMcAAAAAAAAABuCgoJEAwArcHBbJl5eJj5MTB0AAR46OjoMAAAAAAAACHSCgoJzMgBUcHAyXl4mTEw5ABYzOjo6NAQAAAAAAAAABkeCgoKCYiFwcGpeXkhMTBMsOjo6OiADAAAAAAAAAAAAABhZgoKCglBwcEpKTEwvOjo6OigLAAAAAAAAAAAAAAAAAAApaoKCgj4jAAAYJTo6Oi8SAAAAAAAAAAAAAA47Ozs7Ozs7O3uCKQAAAAASOmZmZmZmZmZmZhkAAAAAdJSUlJSUlJSUlHQAAAAAAADH////////////xwAAAAB0lJSUlJSUlJSUdAAAAAAAAMf////////////HAAAAAA47Ozs7Ozs7Sp2lNAAAAABK7eFqZmZmZmZmZhkAAAAAAAAAAAAANIalpaVYOgAARXLt7e3BSwAAAAAAAAAAAAAAAAAAHnClpaWlcbe3nZ3b25Pt7e3toSsAAAAAAAAAAAAACFqlpaWlfC63t67JydDb2zyy7e3t7YILAAAAAAAAAAuTpaWlkkAAire3UsnJYtvbpQBc0u3t7dMPAAAAAAAAIqWlpVYDAEe3t5VQyclQstvbVQAFe+3t7TEAAAAAAAAAT2QaAAAEore3OlDJyVBF29vCBQAAJZByAAAAAAAAAAAAAAAAAF+3t30AUMnJUACV29tyAAAAAAAAAAAAAAAAAAAAAAAct7e3IQBQyclQACjb29siAAAAAAAAAAAAAAAAAAAAAG+3t2QAAFDJyVAAAHjb24UAAAAAAAAAAAAAAAAAAAAAWLejCQAAUMnJUAAACsPbaQAAAAAAAAAAAAAAAAAAAAAAJgwAAABQyclQAAAADi0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAABSdnRQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgOxUAAAAAEw0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFpeSAAAAB9MTAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUl5cAAAAN0xMEQAAAAAAAAAAAAAAAAAAAAAbTC4AAAA+Xl4TAAZMTEIAAAAAAAAAAAAAAAAAAAAAAFNwcCoAACpeXicAHkxMKgAAAB4rDgAAAAAAAAAAAAAAOnBwcCIAF15eOgA1TEwTAAAjOjooAAAAAAAAAAAAAAAAQ3BwbRkDXl5OBExMRAAAJzo6OhgAAAAAAAAAAAAAAAAATHBwZBFMXl4cTEwsBSs6OjoWAAAAAAAAAAAAFBwAAAABVHBwXDheXjNMTBUwOjo4EQAAAAAAAAAAABaCgnBIIAAJXHBwVF5eS0xFNDo6NA0AAAAAAAAAAAAAIIKCgoKCdEsjZXBwT1Q2TDY6OjAJCT5zqN30VwAAAAAANV6CgoKCgoJ3aGYTAAAJNTpkmc7///////+fAAAAAAAAAAszW4KCgoKCDwAAAAAK1f/////////5xDgAAAAAAAAAAAAACDBYgF0AAAAAAADl////1J9qNQAAAAAAAAAAAAAePVx7lJSUhQAAAAAAAKrpoFcOAAAAAAAAAAAAACBykJSUlJSUlJR8HAAAAAAc7e3t7e2mXRMAAAAAAAAAXJSUlJSUlHdZe6WXFQAAJcjK2O3t7e3t7axgAAAAAAAyjoBiQyQFGYelpZm3g7Wo29vFQInT7e3t7e07AAAAAAAAAAAAACWUpaWUp7e0ycmk29u0EgA7hM3t7SgAAAAAAAAAAAAxoKWliDK3t3zJyXi029ukAQAAADQkAAAAAAAAAAAAPqWlpXwNare3Q8nJoiHE29uUAAAAAAAAAAAAAAAAAESlpaVwAQCjt7cLp8nJBzHU29uEAAAAAAAAAAAAAAAAcKWlYwAALbe3gAB9yckxAELb29txAAAAAAAAAAAAAAAoe1UAAABmt7dIAFPJyVsAAFLb26MAAAAAAAAAAAAAAAAAAAAAAJ63tw8AKcnJhQAAAFqVNQAAAAAAAAAAAAAAAAAAAAAot7eEAAAAxMmuAAAAAAAAAAAAAAAAAAAAAAAAAAAAABy3t0oAAACaycEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB8tAAAAACx9RAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKz4XAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtGPwAAAAdMTDYAAAAAAAAAAAAAAAAAAAAAAAAAAAAALV5eJwAAD0xMLwAAABAdBgAAAAAAAAAAAAAAAAAAAAAWXl5OAAAXTEwnAAAKOTooAAAAAAAAAAAAAAAAAAAAAABGXl4eAB9MTB8AACw6OiIAAAAAAAAAAAAAAAtNQwIAAB9eXkQAJ0xMFwAgOjowAQAAAAAAAAAAAAAAOHBwXRsAAE9eXhUvTEwPEzo6Og4AAAAAAAAAAAAAAAAfb3BwcDQAKV5eOzdMTAc1OjobAAAAO3seAAAAAAAAAAAUVnBwcE0LWF5eP0xLKDo6KAAAVb3//70AAAAAAAAAAAAAPXBwcGUyXl5HTEM6OjQHbtb/////qwAAAAAAAAAAAAAAJGZwcHBdXilGKzo6iPD/////02sAAAAAAAAnXFBCNScaDE1wcFQYAAAQLP3/////uVIAAAAAAAAAAGqCgoKCgoKCgHJUIAAAAABB////oDgAAAAAAAAAAAAASYKCgoKCgoKCgngAAAAAAAB83MSrk3phSDAXAAAAAAAADBooNUNQXmx5RAAAAAAAANvt7e3t7e3t7e2FAAAAAAAAAAAAACFdlJSUJgAAAAA+o9Dp7e3t7e3t7cEAAAAAAAAAAC9slJSUlJN8LwAAM6Tb25cWL0hgeZKnRwAAAAAAAD56lJSUlItPpaV7qWDJyNvb28dHAAAAAAAAAAAAAABjlJSUlHxAEJWlpaG3qsnJa8bb29t3AAAAAAAAAAAAAG6UlG0xAABxpaVytLeXycm9FZbb29uoJwAAAAAAAAAAEkciAAAATKWllhG3t4R+yclXAGXb29vYPAAAAAAAAAAAAAAAACilpaU1JLe3cSzJyakAADW129tuAAAAAAAAAAAAAAADiaWlWgA3t7deAJLJyUMAAASClhUAAAAAAAAAAAAAAGKlpX4AAEq3t0sAQMnJlQAAAAAAAAAAAAAAAAAAAAAAcaWjHQAAXre3OAAApsnJLwAAAAAAAAAAAAAAAAAAAAAQUy0AAABxt7clAABUyclhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIG3txIAAACHlRgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN5VnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFz4rAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2TEwHAAAAJysHAAAAAAAAAAAAAAAAAAAAAAkvGgAAAC9MTA8AABg6OhwAAAAAAAAAAAAAAAAAAAAAQF5dEQAAJ0xMFwAAMDo6DQAAAAAAAAAAAAAAAAAAAAA4Xl5IAAAfTEwfABM6OisAAAAAAAAAAAAAAAAAAAAAAAJOXl4zABdMTCcAKjo6EwAABZiuGQAAAAAAAAAAAAAAABdeXl4eD0xMLw06OjEAAD3T//+BAAAAAAAAAA02GgAAACteXlYKTEw3JDo6GQB2/////EYAAAAAAAAAU3BwUyUAAEBeXkFLTD86OjYYrv///8MtAAAAAAAAAABLcHBwcF4wCVVeXkNMRzo6Uef///+LAAAAAAAAAAAAAAAvXXBwcHBpPF5eRkYoOnn////oUgAAAAAAAAAAAAAAAAAAJFFwcHBwb0cbAAAPv///sBovSGB5kqdHAAAAAAAAAAAAABlGcHBwHQAAAABIvtDp7e3t7e3t7cEAAAAAAAwaKDVDUF5seUQAAAAAAADb7e3t7e3t7e3thQAAAABJgoKCgoKCgoKCeAAAAAAAAHzcxKuTemFIMBcAAAAAAGqCgoKCgoKCgHJuKgAAAAA429vbiTAAAAAAAAAAAAAAJ1xQQjUnGg9mlJRvKgAAOZfa29vb259GAAAAAAAAAAAAAAAAAAAwh5SUlKSlYKmWycl1ztvb29u1XAAAAAAAAAAAAAAAUZSUlIZYpaWqt6HJybYTX7jb29vbkwAAAAAAAAAAGnGUlJRlDpulpZe3tIvJyYkAAEmi29ujAAAAAAAAACmSlJSURABHpaVnhLe3FLfJyV0AAAAzahoAAAAAAAAAS5SUeyQAAIulpSRxt7ckQcnJyTAAAAAAAAAAAAAAAAAOZVgDAAA3paV4AF63tzcAbcnJpwQAAAAAAAAAAAAAAAAAAAAAAHqlpTUAS7e3SgAAmsnJeAAAAAAAAAAAAAAAAAAAAAAmpaWIAAA4t7deAAAkxsmJAAAAAAAAAAAAAAAAAAAAAFClpUUAACW3t3EAAAA3ZRMAAAAAAAAAAAAAAAAAAAAAFHpvAAAAEre3gQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZ5U3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0TAAAAAA0kFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMTEwfAAAALTo4AAAAAAAAAAAAAAAAAAAAAAAAAAAAABFMTDcAAAA5OjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEJMTAYADDo6JgAAAGmuPQAAAAAAAAAAAAAAF0YxAAAAKkxMHgAYOjoaAABf//++AAAAAAAAAAAAAABAXl45AAATTEw1ACQ6Og4ATP///4QAAAAAAAAAAAAAACdeXl5AAQBETEwEMDo6Ajr3//+ZAAAAAAAAAAAAAAAAACNeXl5GCCxMTBw6Oi8n5P//rAAAAAAAAAAAAAAAAAAAABxbXl5NFUxMMzo6I9H//78CAAAANCQAAAAAAAAAAAAAABVUXl5URUxLOjq+///SFQA7hM3t7SgAAAAAJmthSjMbBA5NXl5XTDY0Yf//5UCJ0+3t7e3tOwAAAABGcHBwcHBwWkNGXlYJAAAr6ezY7e3t7e3trGAAAAAAABhWbXBwcHBwcHBeEAAAAAAc7e3t7e2mXRMAAAAAAAAAAAAAFy5GXXBwcGUAAAAAAACq6aBXDgAAAAAAAAAAAAAAAAAAAAAIMFiAXQAAAAAAAMXb29u2iFstAAAAAAAAAAAAAAszW4KCgoKCDwAAAAAit9vb29vb29vWqDAAAAAAADVegoKCgoKCd4mHGQAAFbjJloOx29vb29vbiAAAAAAggoKCgoJ0SyOFlJSKlIO3usnJpR4INWOQvtJLAAAAABaCgnBIIAAMepSUb6WltLentMnJtC0AAAAAAAAAAAAAABQcAAAAAW+UlHljpaV8t7cypsnJwzwAAAAAAAAAAAAAAAAAAABklJSEFoWlpUO3t2oQl8nJyUsAAAAAAAAAAAAAAAAAWZSUjyEGpaWJC7e3owABiMnJyVMAAAAAAAAAAAAAAEyUlJQsACilpWcAgLe3LQAAecnJiQAAAAAAAAAAAAAAbpSUNwAAS6WlRABIt7dmAAAAaJYwAAAAAAAAAAAAAAAkZT0AAABtpaUiAA+3t54AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI+loQAAAIS3tygAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnqV/AAAASre3HAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ZyQAAAAALR8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYtLQYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAFAAAAFzo6FwAAABE1AAAAAAAAAAAAAAAAAAAAAAAkTEQEAAAXOjoXAAAM4/96AAAAAAAAAAAAAAAAAAAAAC5MTCoAABc6OhcAAIz//5sAAAAAAAAAAAAAAAAAAAAADExMTA4AFzo6FwAu////JwAAAAAAAAAAAAAAAAAAAAAAKExMNAAXOjoXAK7//4UAAAAAAAAAAAAAAAAALTkPAAACQ0xMGBc6OhdQ///iBQAAJZByAAAAAAAAABNeXl4xAgAdTEw+Fzo6F9D//2MABXvt7e0xAAAAAAAABlReXl5TJAA5TEwiOjpz///AAFzS7e3t0w8AAAAAAAAABDNeXl5eRxhMTEg6OvL//0Cy7e3t7YILAAAAAAAAAAAAABFAXl5eXjpMTC0t//+e7e3t7aErAAAAAAAAAAAAAAAAAAAeTV5eXi0YAABQe+3t7cFLAAAAAAAAAAAAAAstLS0tLS0tLVleHgAAAABK7eFqWFhYWFhYWBUAAAAAWHBwcHBwcHBwcFgAAAAAAACr29vb29vb29vbqwAAAABYcHBwcHBwcHBwWAAAAAAAAKvb29vb29vb29urAAAAAAstLS0tLS0tOnuCKQAAAAA/yb9aWFhYWFhYWBUAAAAAAAAAAAAAKWqCgoJHLwAAOmHJycmkPwAAAAAAAAAAAAAAAAAAGFmCgoKCXJSUgYG3t3zJycnJiSQAAAAAAAAAAAAABkeCgoKCYiWUlIylpa63tzOXycnJyW4JAAAAAAAAAAh0goKCczIAb5SUQqWlUre3igBOssnJybMNAAAAAAAAG4KCgkQDADmUlHlCpaVClbe3RwAEacnJySoAAAAAAAAAPk8UAAADg5SUL0KlpUI6t7eiBAAAH3pgAAAAAAAAAAAAAAAAAE2UlGUAQqWlQgB9t7dfAAAAAAAAAAAAAAAAAAAAAAAXlJSUGwBCpaVCACG3t7ccAAAAAAAAAAAAAAAAAAAAAFqUlFEAAEKlpUIAAGS3t28AAAAAAAAAAAAAAAAAAAAAR5SEBwAAQqWlQgAACaO3WAAAAAAAAAAAAAAAAAAAAAAAHwoAAABCpaVCAAAADCYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCBgRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUJA0AAAAAPysAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADg6LQAAAGj//ycAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMjo5AAAAuf//NwAAAAAAAAAAAAAAAAAAAAASNB8AAAAmOjoMABX//90AAAAAAAAAAAAAAAAAAAAAADlMTBwAABo6OhgAZP//jgAAAHqxOQAAAAAAAAAAAAAAJ0xMTBcADjo6JACy//8/AACP7e2iAAAAAAAAAAAAAAAALkxMShECOjowD///4wACoO3t7WIAAAAAAAAAAAAAAAAAM0xMRAwvOjpe//+UE7Lt7e1ZAAAAAAAAAAAADhQAAAABOUxMPiM6Oqz//0XD7e3mRwAAAAAAAAAAABBeXlE0FwAGP0xMOTo6+//p1e3t1DUAAAAAAAAAAAAAF15eXl5eVDcZRExMMTS3/9vt7cMkCDVjkL7SSwAAAAAAJkReXl5eXl5WRkUNAAAe2O2xg7Hb29vb29uIAAAAAAAAAAglQl5eXl5eCwAAAAAot9vb29vb29vWqDAAAAAAAAAAAAAABSJAXEMAAAAAAADF29vbtohbLQAAAAAAAAAAAAAXLkZdcHBwZQAAAAAAAJDGiEoMAAAAAAAAAAAAABhWbXBwcHBwcHBeFgAAAAAXycnJycmNTxAAAAAAAAAARnBwcHBwcFpDYYJ3EQAAH6ept8nJycnJyZJSAAAAAAAma2FKMxsEFGuCgniUapSKt7ekNnWzycnJyckyAAAAAAAAAAAAAB10goJ1h5SRpaWJt7eXDwAycK7JySIAAAAAAAAAAAAnfoKCayiUlGSlpWOWt7eJAQAAACwfAAAAAAAAAAAAMYKCgmEKVpSUNqWlhRykt7d8AAAAAAAAAAAAAAAAADaCgoJYAQCElJQJiaWlBimxt7duAAAAAAAAAAAAAAAAWYKCTgAAJZSUaABnpaUoADe3t7dfAAAAAAAAAAAAAAAfYUMAAABSlJQ6AESlpUsAAES3t4gAAAAAAAAAAAAAAAAAAAAAAICUlAwAIqWlbQAAAEt9LAAAAAAAAAAAAAAAAAAAAAAglJRrAAAAoaWPAAAAAAAAAAAAAAAAAAAAAAAAAAAAABeUlDwAAAB/pZ4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAABklAAAAACRnOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAj9BMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcrJwAAABn//7QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHDo6GAAAM///nQAAAEF4FwAAAAAAAAAAAAAAAAAAAAANOjowAABO//+CAAAq6u2iAAAAAAAAAAAAAAAAAAAAAAArOjoTAGj//2gAALXt7Y0AAAAAAAAAAAAAAAc0LQEAABM6OioAg///TQCB7e3EBQAAAAAAAAAAAAAAJkxMPxIAADE6Og2e//8yTe3t7TkAAAAAAAAAAAAAAAAVS0xMTCMAGTo6JLj//xjY7e1tAAAAM2oaAAAAAAAAAAAOOkxMTDQHNjo60//7o+3togAASaLb26MAAAAAAAAAAAAAKUxMTEUfOjrt/+Dt7dYXX7jb29vbkwAAAAAAAAAAAAAAGUVMTEw6Oobsse3tdc7b29vbtVwAAAAAAAAcQjowJhwTCTRMTDkPAABDstrb29vbn0YAAAAAAAAAAE1eXl5eXl5eXFM5FgAAAAA429vbiTAAAAAAAAAAAAAANV5eXl5eXl5eXlcAAAAAAABpu6aRfGdSPSgTAAAAAAAACRMdJzA6RE5XMQAAAAAAALrJycnJycnJyclxAAAAAAAAAAAAABlGcHBwHQAAAAA0ibHGycnJycnJyaQAAAAAAAAAACRRcHBwcG9iJQAAKom3t34TKD1SZ3yOPAAAAAAAAC9dcHBwcGk8goJhiU6lpLe3t6c7AAAAAAAAAAAAAABLcHBwcF4wDHaCgoKUiqWlWKa3t7dkAAAAAAAAAAAAAFNwcFMlAABZgoJakpR7paWbEX23t7eMIQAAAAAAAAAADTYaAAAAPIKCdg6UlGtnpaVHAFW3t7e1MgAAAAAAAAAAAAAAAB+CgoIqHZSUXCSlpYsAACyYt7dcAAAAAAAAAAAAAAADbIKCRwAtlJRMAHilpTcAAARtfRIAAAAAAAAAAAAAAE2CgmQAADyUlD0ANaWlegAAAAAAAAAAAAAAAAAAAAAAWYKAFwAATJSULQAAiKWlJgAAAAAAAAAAAAAAAAAAAAANQiQAAABblJQeAABFpaVQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGiUlA4AAABvehQAAAAAAAAAAAAAAAAAAAAAAAAAAAAALHhTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATNCPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC0//8ZAAAAn7AcAAAAAAAAAAAAAAAAAAAAAAYdEAAAAJ3//zMAAGTt7XIAAAAAAAAAAAAAAAAAAAAAKDo5CgAAgv//TgAAxO3tNwAAAAAAAAAAAAAAAAAAAAAiOjosAABo//9oAEzt7a8AAAAAAAAAAAAAAAAAAAAAAAEwOjogAE3//4MArO3tTwAABIKWFQAAAAAAAAAAAAAAAA46OjoTMv//njTt7ccAADW129tuAAAAAAAAAAklEgAAABs6OjUY//+4lO3tZwBl29vb2DwAAAAAAAAAOExMOBkAACg6Oij7/9Pt7d8Vltvb26gnAAAAAAAAAAAzTExMTEAhBjQ6OuD/7e3tfsbb29t3AAAAAAAAAAAAAAAgP0xMTExHKTo6e+yG7evb29vHRwAAAAAAAAAAAAAAAAAAGDdMTExMTCwQAAA9pNvblxYoPVJnfI48AAAAAAAAAAAAABEwTExMEwAAAAA+o7HGycnJycnJyaQAAAAAAAkTHScwOkROVzEAAAAAAAC6ycnJycnJycnJcQAAAAA1Xl5eXl5eXl5eVwAAAAAAAGm7ppF8Z1I9KBMAAAAAAE1eXl5eXl5eXFNUIAAAAAAvt7e3cygAAAAAAAAAAAAAHEI6MCYcEwtNcHBUIQAAL3y2t7e3t4U7AAAAAAAAAAAAAAAAAAAkZnBwcIGCTol7paVirLe3t7eXTQAAAAAAAAAAAAAAPXBwcGVFgoKKlIKlpZUQT5q3t7e3ewAAAAAAAAAAFFZwcHBNC3qCgnuUknKlpXEAAD2Ht7eIAAAAAAAAAB9vcHBwNAA4goJRa5SUEZalpUwAAAArWBYAAAAAAAAAOHBwXRsAAG2Cgh1clJQdNaWlpSgAAAAAAAAAAAAAAAALTUMCAAArgoJeAEyUlC0AWqWliQMAAAAAAAAAAAAAAAAAAAAAAGCCgioAPZSUPAAAfqWlYgAAAAAAAAAAAAAAAAAAAAAegoJrAAAtlJRMAAAdo6VxAAAAAAAAAAAAAAAAAAAAAD+CgjcAAB6UlFsAAAAtUxAAAAAAAAAAAAAAAAAAAAAAD2BXAAAADpSUaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU3gsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACs/AAAAADSUUQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAn//9oAAAAtu3jAAAAAAAAAAAAAAAAAAAAAAAAAAAAADf//7kAAADn7c4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN3//xUAMe3tnAAAAFqVNQAAAAAAAAAAAAAADiseAAAAjv//ZABi7e1rAABS29ujAAAAAAAAAAAAAAAoOjojAAA///+yAJPt7ToAQtvb23EAAAAAAAAAAAAAABg6OjonAADj//8Pxe3tCDHU29uEAAAAAAAAAAAAAAAAABY6OjorBZT//17t7b8hxNvblAAAAAAAAAAAAAAAAAAAABE4OjowRf//rO3tjrTb26QBAAAALB8AAAAAAAAAAAAAAA00Ojo06f/77e2k29u0EgAycK7JySIAAAAAGklCMiITAwkwOjqL/7fVxtvbxTZ1s8nJycnJMgAAAAAvTExMTExMPS0rOjUeAAAlyMq3ycnJycnJklIAAAAAABE6SkxMTExMTExACgAAAAAXycnJycmNTxAAAAAAAAAAAAAAEB8vP0xMTEQAAAAAAACQxohKDAAAAAAAAAAAAAAAAAAAAAAFIkBcQwAAAAAAAKS3t7eYckwmAAAAAAAAAAAAAAglQl5eXl5eCwAAAAAcmbe3t7e3t7ezjCgAAAAAACZEXl5eXl5eVmhmEwAAEZele22Ut7e3t7e3cgAAAAAXXl5eXl5UNxllcHBtdWqUmaWlhxkHLVN5n68+AAAAABBeXlE0FwAJXHBwVIKCkZSHlKWllCUAAAAAAAAAAAAAAA4UAAAAAVRwcFxOgoJklJQoiKWloDEAAAAAAAAAAAAAAAAAAABMcHBkEWmCgjaUlFYNfKWlpT4AAAAAAAAAAAAAAAAAQ3BwbRkFgoJsCZSUhAABcKWlpUQAAAAAAAAAAAAAADpwcHAiACCCglEAaJSUJQAAY6WlcAAAAAAAAAAAAAAAU3BwKgAAO4KCNgA6lJRSAAAAVXsoAAAAAAAAAAAAAAAbTC4AAABWgoIbAAyUlIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHGCfwAAAGuUlCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYJkAAAAPJSUFwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsURwAAAAAJRkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABe5uRcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADURAAAAX+3tXwAAAA4tAAAAAAAAAAAAAAAAAAAAAAB6/+MMAABf7e1fAAAKw9tpAAAAAAAAAAAAAAAAAAAAAJv//4wAAF/t7V8AAHjb24UAAAAAAAAAAAAAAAAAAAAAJ////y4AX+3tXwAo29vbIgAAAAAAAAAAAAAAAAAAAAAAhf//rgBf7e1fAJXb23IAAAAAAAAAAAAAAAAAHCMJAAAF4v//UF/t7V9F29vCBQAAH3pgAAAAAAAAAAw6OjoeAQBj///QX+3tX7Lb21UABGnJyckqAAAAAAAABDQ6OjozFgDA//9z7e1i29ulAE6yycnJsw0AAAAAAAAAAyA6Ojo6LED///Lt7dDb2zeXycnJyW4JAAAAAAAAAAAAAAsoOjo6Op7//7m529uIycnJyYkkAAAAAAAAAAAAAAAAAAASLzo6OntQAABFacnJyaQ/AAAAAAAAAAAAAAceHh4eHh4eHjc6EgAAAAA/yb9aSUlJSUlJSRIAAAAAO0xMTExMTExMTDsAAAAAAACPt7e3t7e3t7e3jwAAAAA7TExMTExMTExMOwAAAAAAAI+3t7e3t7e3t7ePAAAAAAceHh4eHh4eKlleHgAAAAA0pZ1KSUlJSUlJSRIAAAAAAAAAAAAAHk1eXl42IwAAL0+lpaWGNAAAAAAAAAAAAAAAAAAAEUBeXl5eRXBwZmaUlGalpaWlcB4AAAAAAAAAAAAABDNeXl5eRxxwcGqCgoyUlCp8paWlpVoIAAAAAAAAAAZUXl5eUyQAVHBwNIKCQpSUbwBAkqWlpZMLAAAAAAAAE15eXjECACtwcFs0goI0eZSUOQADVqWlpSIAAAAAAAAALTkPAAACY3BwIzSCgjQvlJSDAwAAGmRPAAAAAAAAAAAAAAAAADpwcEwANIKCNABllJRNAAAAAAAAAAAAAAAAAAAAAAARcHBwFAA0goI0ABuUlJQXAAAAAAAAAAAAAAAAAAAAAERwcD0AADSCgjQAAFGUlFoAAAAAAAAAAAAAAAAAAAAANnBkBQAANIKCNAAAB4SURwAAAAAAAAAAAAAAAAAAAAAAFwcAAAA0goI0AAAACh8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1mZg0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABRlDQAAAAANiUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOPttgAAAFnb2yEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzu3nAAAAn9vbMAAAAAAAAAAAAAAAAAAAAAA9rmkAAACc7e0xABLb270AAAAAAAAAAAAAAAAAAAAAAL7//18AAGvt7WIAVtvbegAAAGiWMAAAAAAAAAAAAAAAhP///0wAOu3tkwCZ29s2AAB5ycmJAAAAAAAAAAAAAAAAmf//9zoI7e3FDdvbwwABiMnJyVMAAAAAAAAAAAAAAAAArP//5Ce/7e1Q29t/EJfJyclLAAAAAAAAAAAACQ0AAAACv///0Y7t7ZTb2zumycnDPAAAAAAAAAAAAAo6OjIgDgAV0v//vu3t19vItMnJtC0AAAAAAAAAAAAADjo6Ojo6NCIn5f//xtWd27rJyaUeBy1TeZ+vPgAAAAAAGCo6Ojo6Ojo67OkrAAAauMmWbZS3t7e3t7dyAAAAAAAAAAUXKTo6Ojo6BwAAAAAimbe3t7e3t7ezjCgAAAAAAAAAAAAAAxUnOSoAAAAAAACkt7e3mHJMJgAAAAAAAAAAAAAQHy8/TExMRAAAAAAAAHaicD0KAAAAAAAAAAAAABE6SkxMTExMTExAEAAAAAATpaWlpaVzQQ4AAAAAAAAAL0xMTExMTD0tRl5WDQAAGYeJl6WlpaWlpXdDAAAAAAAaSUIyIhMDDk1eXldwUHVtlJSFLWCTpaWlpaUpAAAAAAAAAAAAABVUXl5UZnBugoJvlJR6DAApXI+lpRwAAAAAAAAAAAAcW15eTR5wcEyCgk55lJRvAQAAACQZAAAAAAAAAAAAI15eXkYIQXBwKYKCaRaElJRkAAAAAAAAAAAAAAAAACdeXl5AAQBkcHAGbIKCBSGPlJRZAAAAAAAAAAAAAAAAQF5eOQAAHHBwTgBRgoIgACyUlJRMAAAAAAAAAAAAAAAXRjEAAAA+cHAsADaCgjsAADeUlG4AAAAAAAAAAAAAAAAAAAAAAGFwcAkAG4KCVgAAAD1lJAAAAAAAAAAAAAAAAAAAAAAYcHBRAAAAf4JxAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFwcC4AAABkgn0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAABMcAAAAABxRLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAe7JBAAAAAAAAAAAAAAAAAAAAAAAAAAAAABywnwAAABXb25oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcu3tZAAALNvbhwAAADdlEwAAAAAAAAAAAAAAAAAAAAA37e3EAABD29twAAAkxsmJAAAAAAAAAAAAAAAAAAAAAACv7e1MAFrb21kAAJrJyXgAAAAAAAAAAAAAABmumAUAAE/t7awAcdvbQgBtycmnBAAAAAAAAAAAAAAAgf//0z0AAMft7TSI29srQcnJyTAAAAAAAAAAAAAAAABG/P///3YAZ+3tlJ7b2xS3ycldAAAAK1gWAAAAAAAAAAAtw////64Y3+3ttdvXi8nJiQAAPYe3t4gAAAAAAAAAAAAAi////+d+7e3M28DJybYTT5q3t7e3ewAAAAAAAAAAAAAAUuj////r7XPKlsnJYqy3t7e3l00AAAAAAAARKSQeGBILGrD//789AAA5l7a3t7e3hTsAAAAAAAAAAC86Ojo6Ojo6OXe+SAAAAAAvt7e3cygAAAAAAAAAAAAAITo6Ojo6Ojo6OjYAAAAAAABWmYl3ZlVEMiEQAAAAAAAABgwSGB4kKjA2IQAAAAAAAJilpaWlpaWlpaVdAAAAAAAAAAAAABEwTExMEwAAAAAqbpGipaWlpaWlpYYAAAAAAAAAABg3TExMTExHGwAAIW+UlGYPITJDVGZ0MQAAAAAAACA/TExMTEcpXl5GaDuCgZSUlIcwAAAAAAAAAAAAAAAzTExMTEAhCVVeXmJwaIKCRYaUlJRRAAAAAAAAAAAAADhMTDgZAABAXl5BbnBdgoJ6DmWUlJRxGgAAAAAAAAAACSUSAAAAK15eVgpwcFFRgoI4AESUlJSSKQAAAAAAAAAAAAAAABdeXl4eFnBwRR2Cgm0AACR7lJRLAAAAAAAAAAAAAAACTl5eMwAicHA6AF6CgisAAANYZQ4AAAAAAAAAAAAAADheXkgAAC5wcC4AKoKCYAAAAAAAAAAAAAAAAAAAAAAAQF5dEQAAOXBwIgAAa4KCHgAAAAAAAAAAAAAAAAAAAAAJLxoAAABFcHAWAAA3goI/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAE9wcAsAAABXYA8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAIVs/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQbJ7AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACa29sVAAAAh5UYAAAAAAAAAAAAAAAAAAAAABd4QQAAAIfb2ywAAFTJyWEAAAAAAAAAAAAAAAAAAAAAou3qKgAAcNvbQwAApsnJLwAAAAAAAAAAAAAAAAAAAACN7e21AABZ29taAEDJyZUAAAAAAAAAAAAAAAAAAAAAAAXE7e2BAELb23EAksnJQwAABG19EgAAAAAAAAAAAAAAADnt7e1NK9vbiCzJyakAACyYt7dcAAAAAAAAAB57OwAAAG3t7dgY29uefsnJVwBVt7e3tTIAAAAAAAAAvf//vVUAAKLt7aPX27XJyb0Rfbe3t4whAAAAAAAAAACr/////9ZuF9bt7cDbzMnJa6a3t7dkAAAAAAAAAAAAAABr0//////wiO3tscpzyci3t7enOwAAAAAAAAAAAAAAAAAAUrn//////bJDAAAzibe3fhMhMkNUZnQxAAAAAAAAAAAAADig////QQAAAAA0iZGipaWlpaWlpYYAAAAAAAYMEhgeJCowg28AAAAAAACYpaWlpaWlpaWlXQAAAAAhOjo6Ojo6Ojo6NgAAAAAAAFaZiXdmVUQyIRAAAAAAAC86Ojo6Ojo6OTM5FgAAAAAmlJSUXSEAAAAAAAAAAAAAESkkHhgSCwg0TEw5GAAAJWKTlJSUlGwvAAAAAAAAAAAAAAAAAAAZRUxMTF1eO2hhgoJPi5SUlJR6PgAAAAAAAAAAAAAAKUxMTEUyXl5ocGKCgnYMQHyUlJSUYwAAAAAAAAAADjpMTEw0B1heXl1wblqCglkAADFtlJRuAAAAAAAAABVLTExMIwApXl47UXBwDXaCgjwAAAAiRxIAAAAAAAAAJkxMPxIAAE9eXhVFcHAWKoKCgh8AAAAAAAAAAAAAAAAHNC0BAAAfXl5EADpwcCIAR4KCbAMAAAAAAAAAAAAAAAAAAAAAAEZeXh4ALnBwLgAAZIKCTQAAAAAAAAAAAAAAAAAAAAAWXl5OAAAicHA5AAAXgIJZAAAAAAAAAAAAAAAAAAAAAC1eXicAABZwcEUAAAAkQg0AAAAAAAAAAAAAAAAAAAAAC0Y/AAAAC3BwTwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP1shAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACU2AAAAACx9RAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAh29tZAAAAmsnBAAAAAAAAAAAAAAAAAAAAAAAAAAAAADDb258AAADEya4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL3b2xIAKcnJhQAAAEt9LAAAAAAAAAAAAAAAObF6AAAAetvbVgBTyclbAABEt7eIAAAAAAAAAAAAAACi7e2PAAA229uZAH3JyTEAN7e3t18AAAAAAAAAAAAAAGLt7e2gAgDD29sNp8nJBymxt7duAAAAAAAAAAAAAAAAAFnt7e2yE3/b21DJyaIcpLe3fAAAAAAAAAAAAAAAAAAAAEfm7e3DO9vblMnJeJa3t4kBAAAAJBkAAAAAAAAAAAAAADXU7e3VyNvXycmJt7eXDwApXI+lpRwAAAAAV/TdqHM+CSTD7e3b2521qLe3pC1gk6WlpaWlKQAAAACf////////zpmx7dgaAAAfp6mXpaWlpaWld0MAAAAAADjE+f/////////VKAAAAAATpaWlpaVzQQ4AAAAAAAAAAAAANWqf1P///+UAAAAAAAB2onA9CgAAAAAAAAAAAAAAAAAAAAADFUR2NAAAAAAAAIWUlJR7XD0eAAAAAAAAAAAAAAUXKTo6Ojo6BwAAAAAWfJSUlJSUlJSQciAAAAAAABgqOjo6Ojo6NUZFDQAADXeCYVl3lJSUlJSUXAAAAAAOOjo6Ojo0IhBETExPVFBweIKCaxQFJENigI4yAAAAAAo6OjIgDgAGP0xMOV5ebnBmdYKCdB0AAAAAAAAAAAAAAAkNAAAAATlMTD44Xl5McHAea4KCficAAAAAAAAAAAAAAAAAAAAzTExEDExeXilwcEEKYYKCgjEAAAAAAAAAAAAAAAAALkxMShEDXl5OBnBwZAABWIKCgjYAAAAAAAAAAAAAACdMTEwXABdeXjoATnBwHAAAToKCWQAAAAAAAAAAAAAAOUxMHAAAKl5eJwAscHA+AAAAQ2EfAAAAAAAAAAAAAAASNB8AAAA+Xl4TAAlwcGEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFJeXAAAAFFwcBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWl5IAAAALnBwEQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgOxUAAAAAHBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABSdnRQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC0OAAAAUMnJUAAAAAwmAAAAAAAAAAAAAAAAAAAAAABp28MKAABQyclQAAAJo7dYAAAAAAAAAAAAAAAAAAAAAIXb23gAAFDJyVAAAGS3t28AAAAAAAAAAAAAAAAAAAAAItvb2ygAUMnJUAAht7e3HAAAAAAAAAAAAAAAAAAAAAAActvblQBQyclQAH23t18AAAAAAAAAAAAAAAAAcpAlAAAFwtvbRVDJyVA6t7eiBAAAGmRPAAAAAAAAADHt7e17BQBV29uyUMnJUJW3t0cAA1alpaUiAAAAAAAAD9Pt7e3SXACl29tiyclSt7eKAECSpaWlkwsAAAAAAAAAC4Lt7e3tsjzb29DJya63ty58paWlpVoIAAAAAAAAAAAAACuh7e3t7ZPb252dt7dxpaWlpXAeAAAAAAAAAAAAAAAAAABLwe3t7XJFAAA6WKWlpYY0AAAAAAAAAAAAABlmZmZmZmZmauHtSgAAAAA0pZ1KOzs7Ozs7Ow4AAAAAx////////////8cAAAAAAAB0lJSUlJSUlJSUdAAAAADH////////////xwAAAAAAAHSUlJSUlJSUlJR0AAAAABlmZmZmZmZmZmY6EgAAAAApgns7Ozs7Ozs7Ow4AAAAAAAAAAAAAEi86OjolGAAAIz6CgoJqKQAAAAAAAAAAAAAAAAAACyg6Ojo6L0xMSkpwcFCCgoKCWRgAAAAAAAAAAAAAAyA6Ojo6LBNMTEheXmpwcCFigoKCgkcGAAAAAAAAAAQ0Ojo6MxYAOUxMJl5eMnBwVAAyc4KCgnQIAAAAAAAADDo6Oh4BAB1MTD4mXl4mW3BwKwADRIKCghsAAAAAAAAAHCMJAAACQ0xMGCZeXiYjcHBjAgAAFE8+AAAAAAAAAAAAAAAAAChMTDQAJl5eJgBMcHA6AAAAAAAAAAAAAAAAAAAAAAAMTExMDgAmXl4mABRwcHARAAAAAAAAAAAAAAAAAAAAAC5MTCoAACZeXiYAAD1wcEQAAAAAAAAAAAAAAAAAAAAAJExEBAAAJl5eJgAABWRwNgAAAAAAAAAAAAAAAAAAAAAAEAUAAAAmXl4mAAAABxcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlKSgkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABEfSwAAAAALR8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMHJmgAAAEq3txwAAAAAAAAAAAAAAAAAAAAAAAAAAAAArsnEAAAAhLe3KAAAAAAAAAAAAAAAAAAAAAA1lVoAAACFyckpAA+3t54AAAAAAAAAAAAAAAAAAAAAAKPb21IAAFvJyVMASLe3ZgAAAFV7KAAAAAAAAAAAAAAAcdvb20IAMcnJfQCAt7ctAABjpaVwAAAAAAAAAAAAAAAAhNvb1DEHycmnC7e3owABcKWlpUQAAAAAAAAAAAAAAAAAlNvbxCGiyclDt7dqDXylpaU+AAAAAAAAAAAAJDQAAAABpNvbtHjJyXy3tzKIpaWgMQAAAAAAAAAAACjt7c2EOwAStNvbpMnJtLenlKWllCUAAAAAAAAAAAAAO+3t7e3t04lAxdvbqLWDt5mlpYcZBSRDYoCOMgAAAAAAYKzt7e3t7e3YysglAAAVl6V7WXeUlJSUlJRcAAAAAAAAABNdpu3t7e3tHAAAAAAcfJSUlJSUlJSQciAAAAAAAAAAAAAADleg6aoAAAAAAACFlJSUe1w9HgAAAAAAAAAAAAA1ap/U////5QAAAAAAAF2AWDAIAAAAAAAAAAAAADjE+f/////////VCgAAAAAPgoKCgoJbMwsAAAAAAAAAn////////86ZZDo1CQAAE2Zod4KCgoKCgl41AAAAAABX9N2ocz4JCTA6OjZMNlRPcHBlI0t0goKCgoIgAAAAAAAAAAAAAA00Ojo0RUxLXl5UcHBcCQAgSHCCghYAAAAAAAAAAAARODo6MBVMTDNeXjhccHBUAQAAABwUAAAAAAAAAAAAFjo6OisFLExMHF5eTBFkcHBMAAAAAAAAAAAAAAAAABg6OjonAABETEwETl5eAxltcHBDAAAAAAAAAAAAAAAAKDo6IwAAE0xMNQA6Xl4XACJwcHA6AAAAAAAAAAAAAAAOKx4AAAAqTEweACdeXioAACpwcFMAAAAAAAAAAAAAAAAAAAAAAEJMTAYAE15ePgAAAC5MGwAAAAAAAAAAAAAAAAAAAAARTEw3AAAAXF5SAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxMTB8AAABIXloAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0TAAAAABU7IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZ5U3AAAAAAAAAAAAAAAAAAAAAAAAAAAAABiVhwAAABK3t4EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYcnJVAAAJbe3cQAAAC1TEAAAAAAAAAAAAAAAAAAAAAAvycmmAAA4t7deAAAdo6VxAAAAAAAAAAAAAAAAAAAAAACVyclAAEu3t0oAAH6lpWIAAAAAAAAAAAAAABWWggQAAEPJyZIAXre3NwBapaWJAwAAAAAAAAAAAAAAbtvbtTUAAKnJySxxt7ckNaWlpSgAAAAAAAAAAAAAAAA82Nvb22UAV8nJfoS3txGWpaVMAAAAIkcSAAAAAAAAAAAnqNvb25YVvcnJl7e0cqWlcQAAMW2UlG4AAAAAAAAAAAAAd9vb28Zrycmqt6GlpZUQQHyUlJSUYwAAAAAAAAAAAAAAR8fb29vIyWCpe6WlT4uUlJSUej4AAAAAAABHp5J5YEgvFpfb26QzAAAvfJOUlJSUbC8AAAAAAAAAAMHt7e3t7e3t6dCjPgAAAAAmlJSUXSEAAAAAAAAAAAAAhe3t7e3t7e3t7dsAAAAAAABEeWxeUEM1KBoMAAAAAAAAFzBIYXqTq8TcfAAAAAAAAHiCgoKCgoKCgoJJAAAAAAAAAAAAADig////QQAAAAAgVHKAgoKCgoKCgmoAAAAAAAAAAFK5//////0sEAAAGFRwcE0MGic1QlBcJwAAAAAAAGvT//////CIOjorRileXXBwcGYkAAAAAAAAAAAAAACr/////9ZuBzQ6OkNMR15eMmVwcHA9AAAAAAAAAAAAAL3//71VAAAoOjooS0w/Xl5YC01wcHBWFAAAAAAAAAAAHns7AAAAGzo6NQdMTDc7Xl4pADRwcHBvHwAAAAAAAAAAAAAAAA46OjoTD0xMLxVeXk8AABtdcHA4AAAAAAAAAAAAAAABMDo6IAAXTEwnAEReXh8AAAJDTQsAAAAAAAAAAAAAACI6OiwAAB9MTB8AHl5eRgAAAAAAAAAAAAAAAAAAAAAAKDo5CgAAJ0xMFwAATl5eFgAAAAAAAAAAAAAAAAAAAAAGHRAAAAAvTEwPAAAnXl4tAAAAAAAAAAAAAAAAAAAAAAAAAAAAADZMTAcAAAA/RgsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFz4rAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN5VnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACBt7cSAAAAb3oUAAAAAAAAAAAAAAAAAAAAABNlNwAAAHG3tyUAAEWlpVAAAAAAAAAAAAAAAAAAAAAAicnGJAAAXre3OAAAiKWlJgAAAAAAAAAAAAAAAAAAAAB4ycmaAABKt7dLADWlpXoAAAAAAAAAAAAAAAAAAAAAAASnycltADe3t14AeKWlNwAAA1hlDgAAAAAAAAAAAAAAADDJyclBJLe3cSSlpYsAACR7lJRLAAAAAAAAABpqMwAAAF3JybcUt7eEZ6WlRwBElJSUkikAAAAAAAAAo9vbokkAAInJyYu0t5elpZsOZZSUlHEaAAAAAAAAAACT29vb27hfE7bJyaG3qqWlWIaUlJRRAAAAAAAAAAAAAABctdvb29vOdcnJlqlgpaSUlJSHMAAAAAAAAAAAAAAAAAAARp/b29vb2pc5AAAqb5SUZg8aJzVCUFwnAAAAAAAAAAAAADCJ29vbOAAAAAAqbnKAgoKCgoKCgmoAAAAAABcwSGF6k6vE3HwAAAAAAAB4goKCgoKCgoKCSQAAAACF7e3t7e3t7e3t2wAAAAAAAER5bF5QQzUoGgwAAAAAAMHt7e3t7e3t6dC+SAAAAAAdcHBwRhkAAAAAAAAAAAAAR6eSeWBILxqw//+/DwAAG0dvcHBwcFEkAAAAAAAAAAAAAAAAAABS6P///3k6KEZGXl48aXBwcHBdLwAAAAAAAAAAAAAAi////+dROjpHTENeXlUJMF5wcHBwSwAAAAAAAAAALcP///+uGDY6Oj9MS0FeXkAAACVTcHBTAAAAAAAAAEb8////dgAZOjokN0xMClZeXisAAAAaNg0AAAAAAAAAgf//0z0AADE6Og0vTEwPHl5eXhcAAAAAAAAAAAAAAAAZrpgFAAATOjoqACdMTBcAM15eTgIAAAAAAAAAAAAAAAAAAAAAACs6OhMAH0xMHwAASF5eOAAAAAAAAAAAAAAAAAAAAAANOjowAAAXTEwnAAARXV5AAAAAAAAAAAAAAAAAAAAAABw6OhgAAA9MTC8AAAAaLwkAAAAAAAAAAAAAAAAAAAAABysnAAAAB0xMNgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKz4XAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB8tAAAAACRnOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAct7dKAAAAf6WeAAAAAAAAAAAAAAAAAAAAAAAAAAAAACi3t4QAAAChpY8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ63tw8AIqWlbQAAAD1lJAAAAAAAAAAAAAAAMJZoAAAAZre3SABEpaVLAAA3lJRuAAAAAAAAAAAAAACJycl5AAAtt7eAAGelpSgALJSUlEwAAAAAAAAAAAAAAFPJycmIAQCjt7cLiaWlBiGPlJRZAAAAAAAAAAAAAAAAAEvJycmXEGq3t0OlpYUWhJSUZAAAAAAAAAAAAAAAAAAAADzDycmmMre3fKWlY3mUlG8BAAAAHBQAAAAAAAAAAAAAAC20ycm0p7e0paVvlJR6DAAgSHCCghYAAAAAS9K+kGM1CB6lycm6t4OUipSUhSNLdIKCgoKCIAAAAACI29vb29vbsYOWybgVAAAZh4l3goKCgoKCXjUAAAAAADCo1tvb29vb29u3IgAAAAAPgoKCgoJbMwsAAAAAAAAAAAAALVuIttvb28UAAAAAAABdgFgwCAAAAAAAAAAAAAAAAAAAAAAOV6DpqgAAAAAAAGVwcHBdRi4XAAAAAAAAAAAAABNdpu3t7e3tHAAAAAAQXnBwcHBwcHBtVhgAAAAAAGCs7e3t7e3t2OzpKwAACVZeRkNacHBwcHBwRgAAAAA77e3t7e3TiUDl//9hNDZMV15eTQ4EGzNKYWsmAAAAACjt7c2EOwAV0v//vjo6S0xFVF5eVBUAAAAAAAAAAAAAACQ0AAAAAr///9EjOjozTEwVTV5eWxwAAAAAAAAAAAAAAAAAAACs///kJy86OhxMTCwIRl5eXiMAAAAAAAAAAAAAAAAAmf//9zoCOjowBExMRAABQF5eXicAAAAAAAAAAAAAAIT///9MAA46OiQANUxMEwAAOV5eQAAAAAAAAAAAAAAAvv//XwAAGjo6GAAeTEwqAAAAMUYXAAAAAAAAAAAAAAA9rmkAAAAmOjoMAAZMTEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADI6OQAAADdMTBEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAODotAAAAH0xMDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUJA0AAAAAEw0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCBgRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACYMAAAAQqWlQgAAAAofAAAAAAAAAAAAAAAAAAAAAABYt6MJAABCpaVCAAAHhJRHAAAAAAAAAAAAAAAAAAAAAG+3t2QAAEKlpUIAAFGUlFoAAAAAAAAAAAAAAAAAAAAAHLe3tyEAQqWlQgAblJSUFwAAAAAAAAAAAAAAAAAAAAAAX7e3fQBCpaVCAGWUlE0AAAAAAAAAAAAAAAAAYHofAAAEore3OkKlpUIvlJSDAwAAFE8+AAAAAAAAACrJyclpBABHt7eVQqWlQnmUlDkAA0SCgoIbAAAAAAAADbPJycmyTgCKt7dSpaVClJRvADJzgoKCdAgAAAAAAAAACW7JycnJlzO3t66lpYyUlCVigoKCgkcGAAAAAAAAAAAAACSJycnJyXy3t4GBlJRcgoKCglkYAAAAAAAAAAAAAAAAAAA/pMnJyWE6AAAvR4KCgmopAAAAAAAAAAAAABVYWFhYWFhYWr/JPwAAAAApgns6LS0tLS0tLQsAAAAAq9vb29vb29vb26sAAAAAAABYcHBwcHBwcHBwWAAAAACr29vb29vb29vbqwAAAAAAAFhwcHBwcHBwcHBYAAAAABVYWFhYWFhYauHtSgAAAAAeXlktLS0tLS0tLQsAAAAAAAAAAAAAS8Ht7e17UAAAGC1eXl5NHgAAAAAAAAAAAAAAAAAAK6Ht7e3tnv//LS1MTDpeXl5eQBEAAAAAAAAAAAAAC4Lt7e3tskD///I6OkhMTBhHXl5eXjMEAAAAAAAAAA/T7e3t0lwAwP//czo6IkxMOQAkU15eXlQGAAAAAAAAMe3t7XsFAGP//9AXOjoXPkxMHQACMV5eXhMAAAAAAAAAcpAlAAAF4v//UBc6OhcYTExDAgAADzktAAAAAAAAAAAAAAAAAIX//64AFzo6FwA0TEwoAAAAAAAAAAAAAAAAAAAAAAAn////LgAXOjoXAA5MTEwMAAAAAAAAAAAAAAAAAAAAAJv//4wAABc6OhcAACpMTC4AAAAAAAAAAAAAAAAAAAAAev/jDAAAFzo6FwAABERMJAAAAAAAAAAAAAAAAAAAAAAANREAAAAXOjoXAAAABRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYtLQYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ZyQAAAAAJRkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ6lfwAAADyUlBcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAj6WhAAAAa5SUIAAAAAAAAAAAAAAAAAAAAAAsfUsAAABtpaUiAAyUlIAAAAAAAAAAAAAAAAAAAAAAAIi3t0QAAEulpUQAOpSUUgAAAENhHwAAAAAAAAAAAAAAX7e3tzcAKKWlZwBolJQlAABOgoJZAAAAAAAAAAAAAAAAbre3sSkGpaWJCZSUhAABWIKCgjYAAAAAAAAAAAAAAAAAfLe3pByFpaU2lJRWCmGCgoIxAAAAAAAAAAAAHywAAAABibe3lmOlpWSUlChrgoJ+JwAAAAAAAAAAACLJya5wMgAPl7e3iaWlkZSHdYKCdB0AAAAAAAAAAAAAMsnJycnJs3U2pLe3ipRqlHiCgmsUBBszSmFrJgAAAAAAUpLJycnJycm3qacfAAARd4JhQ1pwcHBwcHBGAAAAAAAAABBPjcnJycnJFwAAAAAWXnBwcHBwcHBtVhgAAAAAAAAAAAAADEqIxpAAAAAAAABlcHBwXUYuFwAAAAAAAAAAAAAtW4i229vbxQAAAAAAAENcQCIFAAAAAAAAAAAAADCo1tvb29vb29u3KAAAAAALXl5eXl5CJQgAAAAAAAAAiNvb29vb27GDse3YHgAADUVGVl5eXl5eXkQmAAAAAABL0r6QYzUIJMPt7dv/tzQxTExEGTdUXl5eXl4XAAAAAAAAAAAAADXU7e3V6f/7Ojo5TEw/BgAXNFFeXhAAAAAAAAAAAABH5u3tw0X//6w6OiM+TEw5AQAAABQOAAAAAAAAAAAAWe3t7bITlP//Xjo6LwxETEwzAAAAAAAAAAAAAAAAAGLt7e2gAgDj//8PMDo6AhFKTEwuAAAAAAAAAAAAAAAAou3tjwAAP///sgAkOjoOABdMTEwnAAAAAAAAAAAAAAA5sXoAAACO//9kABg6OhoAABxMTDkAAAAAAAAAAAAAAAAAAAAAAN3//xUADDo6JgAAAB80EgAAAAAAAAAAAAAAAAAAAAA3//+5AAAAOToyAAAAAAAAAAAAAAAAAAAAAAAAAAAAACf//2gAAAAtOjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACs/AAAAAA0kFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU3gsAAAAAAAAAAAAAAAAAAAAAAAAAAAAABR6bwAAAA6UlGgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUKWlRQAAHpSUWwAAACRCDQAAAAAAAAAAAAAAAAAAAAAmpaWIAAAtlJRMAAAXgIJZAAAAAAAAAAAAAAAAAAAAAAB6paU1AD2UlDwAAGSCgk0AAAAAAAAAAAAAABJ9bQQAADelpXgATJSULQBHgoJsAwAAAAAAAAAAAAAAXLe3mCwAAIulpSRclJQdKoKCgh8AAAAAAAAAAAAAAAAytbe3t1UAR6WlZ2uUlA52goI8AAAAGjYNAAAAAAAAAAAhjLe3t30Rm6Wle5SSWoKCWQAAJVNwcFMAAAAAAAAAAAAAZLe3t6ZYpaWKlIKCgnYMMF5wcHBwSwAAAAAAAAAAAAAAO6e3t7ekpU6JYYKCPGlwcHBwXS8AAAAAAAA8jnxnUj0oE363t4kqAAAlYm9wcHBwUSQAAAAAAAAAAKTJycnJycnJxrGJNAAAAAAdcHBwRhkAAAAAAAAAAAAAccnJycnJycnJyboAAAAAAAAxV05EOjAnHRMJAAAAAAAAEyg9Umd8kaa7aQAAAAAAAFdeXl5eXl5eXl41AAAAAAAAAAAAADCJ29vbOAAAAAAWOVNcXl5eXl5eXk0AAAAAAAAAAEaf29vb29qyQwAADzlMTDQJExwmMDpCHAAAAAAAAFy129vb28517e2x7IY6OkxMTEUZAAAAAAAAAAAAAACT29vb27hfF9bt7eD/7To6H0VMTEwpAAAAAAAAAAAAAKPb26JJAACi7e2j+//TOjo2BzRMTEw6DgAAAAAAAAAAGmozAAAAbe3t2Bj//7gkOjoZACNMTExLFQAAAAAAAAAAAAAAADnt7e1NMv//ng06OjEAABI/TEwmAAAAAAAAAAAAAAAFxO3tgQBN//+DACo6OhMAAAEtNAcAAAAAAAAAAAAAAI3t7bUAAGj//2gAEzo6KwAAAAAAAAAAAAAAAAAAAAAAou3qKgAAgv//TgAAMDo6DQAAAAAAAAAAAAAAAAAAAAAXeEEAAACd//8zAAAYOjocAAAAAAAAAAAAAAAAAAAAAAAAAAAAALT//xkAAAAnKwcAAAAAAAAAAAAAAAAAAAAAAAAAAAAATNCPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALHhTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABolJQOAAAAV2APAAAAAAAAAAAAAAAAAAAAABBTLQAAAFuUlB4AADeCgj8AAAAAAAAAAAAAAAAAAAAAcaWjHQAATJSULQAAa4KCHgAAAAAAAAAAAAAAAAAAAABipaV+AAA8lJQ9ACqCgmAAAAAAAAAAAAAAAAAAAAAAAAOJpaVaAC2UlEwAXoKCKwAAAkNNCwAAAAAAAAAAAAAAACilpaU1HZSUXB2Cgm0AABtdcHA4AAAAAAAAABZYKwAAAEylpZYRlJRrUYKCOAA0cHBwbx8AAAAAAAAAiLe3hz0AAHGlpXKSlHuCgnoLTXBwcFYUAAAAAAAAAAB7t7e3t5pPEJWlpYKUioKCRWVwcHA9AAAAAAAAAAAAAABNl7e3t7esYqWle4lOgoFwcHBmJAAAAAAAAAAAAAAAAAAAO4W3t7e3tnwvAAAhVHBwTQsTHCYwOkIcAAAAAAAAAAAAAChzt7e3LwAAAAAgVFNcXl5eXl5eXk0AAAAAABMoPVJnfJGmu2kAAAAAAABXXl5eXl5eXl5eNQAAAABxycnJycnJycnJugAAAAAAADFXTkQ6MCcdEwkAAAAAAKTJycnJycnJxrGjPgAAAAATTExMMBEAAAAAAAAAAAAAPI58Z1I9KBaX29ukPQAAECxMTExMTDcYAAAAAAAAAAAAAAAAAABHx9vb2+vthux7OjopR0xMTEw/IAAAAAAAAAAAAAAAd9vb28Z+7e3t/+A6OjQGIUBMTExMMwAAAAAAAAAAJ6jb29uWFd/t7dP/+yg6OigAABk4TEw4AAAAAAAAADzY29vbZQBn7e2UuP//GDU6OhsAAAASJQkAAAAAAAAAbtvbtTUAAMft7TSe//8yEzo6Og4AAAAAAAAAAAAAAAAVloIEAABP7e2sAIP//00AIDo6MAEAAAAAAAAAAAAAAAAAAAAAAK/t7UwAaP//aAAALDo6IgAAAAAAAAAAAAAAAAAAAAA37e3EAABO//+CAAAKOTooAAAAAAAAAAAAAAAAAAAAAHLt7WQAADP//50AAAAQHQYAAAAAAAAAAAAAAAAAAAAAHLCfAAAAGf//tAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAj9BMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABklAAAAABxRLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXlJQ8AAAAZIJ9AAAAAAAAAAAAAAAAAAAAAAAAAAAAACCUlGsAAAB/gnEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAICUlAwAG4KCVgAAAC5MGwAAAAAAAAAAAAAAKHtVAAAAUpSUOgA2goI7AAAqcHBTAAAAAAAAAAAAAABwpaVjAAAllJRoAFGCgiAAInBwcDoAAAAAAAAAAAAAAESlpaVwAQCElJQJbIKCBRltcHBDAAAAAAAAAAAAAAAAAD6lpaV8DVaUlDaCgmkRZHBwTAAAAAAAAAAAAAAAAAAAADGgpaWIKJSUZIKCTlxwcFQBAAAAFA4AAAAAAAAAAAAAACWUpaWUh5SRgoJUcHBcCQAXNFFeXhAAAAAAPq+feVMtBxmHpaWZlGp1bXBwZRk3VF5eXl5eFwAAAAByt7e3t7e3lG17pZcRAAATZmhWXl5eXl5eRCYAAAAAACiMs7e3t7e3t7eZHAAAAAALXl5eXl5CJQgAAAAAAAAAAAAAJkxymLe3t6QAAAAAAABDXEAiBQAAAAAAAAAAAAAAAAAAAAAMSojGkAAAAAAAAERMTEw/Lx8QAAAAAAAAAAAAABBPjcnJycnJFwAAAAAKQExMTExMTExKOhEAAAAAAFKSycnJycnJt8rIJQAAHjU6Ky09TExMTExMLwAAAAAyycnJycmzdTbF29vG1bf/izo6MAkDEyIyQkkaAAAAACLJya5wMgAStNvbpO3t+//pNDo6NA0AAAAAAAAAAAAAAB8sAAAAAaTb27SO7e2s//9FMDo6OBEAAAAAAAAAAAAAAAAAAACU29vEIb/t7V7//5QFKzo6OhYAAAAAAAAAAAAAAAAAhNvb1DEI7e3FD///4wAAJzo6OhgAAAAAAAAAAAAAAHHb29tCADrt7ZMAsv//PwAAIzo6KAAAAAAAAAAAAAAAo9vbUgAAa+3tYgBk//+OAAAAHisOAAAAAAAAAAAAAAA1lVoAAACc7e0xABX//90AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM7t5wAAALn//zcAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4+22AAAAaP//JwAAAAAAAAAAAAAAAAAAAAAAAAAAAABRlDQAAAAAPysAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1mZg0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB8KAAAANIKCNAAAAAcXAAAAAAAAAAAAAAAAAAAAAABHlIQHAAA0goI0AAAFZHA2AAAAAAAAAAAAAAAAAAAAAFqUlFEAADSCgjQAAD1wcEQAAAAAAAAAAAAAAAAAAAAAF5SUlBsANIKCNAAUcHBwEQAAAAAAAAAAAAAAAAAAAAAATZSUZQA0goI0AExwcDoAAAAAAAAAAAAAAAAAT2QaAAADg5SULzSCgjQjcHBjAgAADzktAAAAAAAAACKlpaVWAwA5lJR5NIKCNFtwcCsAAjFeXl4TAAAAAAAAC5OlpaWSQABvlJRCgoI0cHBUACRTXl5eVAYAAAAAAAAACFqlpaWlfCqUlIyCgmpwcBxHXl5eXjMEAAAAAAAAAAAAAB5wpaWlpWaUlGZmcHBFXl5eXkARAAAAAAAAAAAAAAAAAAA0hqWlpU8vAAAjNl5eXk0eAAAAAAAAAAAAABJJSUlJSUlJSp2lNAAAAAAeXlkqHh4eHh4eHgcAAAAAj7e3t7e3t7e3t48AAAAAAAA7TExMTExMTExMOwAAAACPt7e3t7e3t7e3jwAAAAAAADtMTExMTExMTEw7AAAAABJJSUlJSUlJWr/JPwAAAAASOjceHh4eHh4eHgcAAAAAAAAAAAAAP6TJyclpRQAAUHs6OjovEgAAAAAAAAAAAAAAAAAAJInJycnJiNvbubn//546Ojo6KAsAAAAAAAAAAAAACW7JycnJlzfb29Dt7fL//0AsOjo6OiADAAAAAAAAAA2zycnJsk4ApdvbYu3tc///wAAWMzo6OjQEAAAAAAAAKsnJyWkEAFXb27Jf7e1f0P//YwABHjo6OgwAAAAAAAAAYHofAAAFwtvbRV/t7V9Q///iBQAACSMcAAAAAAAAAAAAAAAAAHLb25UAX+3tXwCu//+FAAAAAAAAAAAAAAAAAAAAAAAi29vbKABf7e1fAC7///8nAAAAAAAAAAAAAAAAAAAAAIXb23gAAF/t7V8AAIz//5sAAAAAAAAAAAAAAAAAAAAAadvDCgAAX+3tXwAADOP/egAAAAAAAAAAAAAAAAAAAAAALQ4AAABf7e1fAAAAETUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABe5uRcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsURwAAAAAHBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH2CZAAAAC5wcBEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcYJ/AAAAUXBwGAAAAAAAAAAAAAAAAAAAAAAkZT0AAABWgoIbAAlwcGEAAAAAAAAAAAAAAAAAAAAAAG6UlDcAADuCgjYALHBwPgAAADFGFwAAAAAAAAAAAAAATJSUlCwAIIKCUQBOcHAcAAA5Xl5AAAAAAAAAAAAAAAAAWZSUjyEFgoJsBnBwZAABQF5eXicAAAAAAAAAAAAAAAAAZJSUhBZpgoIpcHBBCEZeXl4jAAAAAAAAAAAAGSQAAAABb5SUeU6CgkxwcB5NXl5bHAAAAAAAAAAAABylpY9cKQAMepSUb4KCbnBmVF5eVBUAAAAAAAAAAAAAKaWlpaWlk2AthZSUbXVQcFdeXk0OAxMiMkJJGgAAAAAAQ3elpaWlpaWXiYcZAAANVl5GLT1MTExMTEwvAAAAAAAAAA5Bc6WlpaWlEwAAAAAQQExMTExMTExKOhEAAAAAAAAAAAAACj1wonYAAAAAAABETExMPy8fEAAAAAAAAAAAAAAmTHKYt7e3pAAAAAAAACo5JxUDAAAAAAAAAAAAACiMs7e3t7e3t7eZIgAAAAAHOjo6OjopFwUAAAAAAAAAcre3t7e3t5Rtlsm4GgAAK+nsOjo6Ojo6OioYAAAAAAA+r595Uy0HHqXJybrbndXG///lJyI0Ojo6OjoOAAAAAAAAAAAAAC20ycm0yNvX7e2+///SFQAOIDI6OgoAAAAAAAAAAAA8w8nJpjvb25Tt7Y7R//+/AgAAAA0JAAAAAAAAAAAAS8nJyZcQf9vbUO3tvyfk//+sAAAAAAAAAAAAAAAAAFPJycmIAQDD29sNxe3tCDr3//+ZAAAAAAAAAAAAAAAAicnJeQAANtvbmQCT7e06AEz///+EAAAAAAAAAAAAAAAwlmgAAAB629tWAGLt7WsAAF///74AAAAAAAAAAAAAAAAAAAAAAL3b2xIAMe3tnAAAAGmuPQAAAAAAAAAAAAAAAAAAAAAw29ufAAAA5+3OAAAAAAAAAAAAAAAAAAAAAAAAAAAAACHb21kAAAC27eMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACU2AAAAADSUUQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP1shAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9gVwAAAAtwcE8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAP4KCNwAAFnBwRQAAABovCQAAAAAAAAAAAAAAAAAAAAAegoJrAAAicHA5AAARXV5AAAAAAAAAAAAAAAAAAAAAAABggoIqAC5wcC4AAEheXjgAAAAAAAAAAAAAAA5lWAMAACuCgl4AOnBwIgAzXl5OAgAAAAAAAAAAAAAAS5SUeyQAAG2Cgh1FcHAWHl5eXhcAAAAAAAAAAAAAAAApkpSUlEQAOIKCUVFwcApWXl4rAAAAEiUJAAAAAAAAAAAacZSUlGUOeoKCXXBuQV5eQAAAGThMTDgAAAAAAAAAAAAAUZSUlIZFgoJocGJeXlUJIUBMTExMMwAAAAAAAAAAAAAAMIeUlJSBgjtoRl5eKUdMTExMPyAAAAAAAAAxdGZUQzIhD2aUlG8hAAAbR0xMTExMNxgAAAAAAAAAAIalpaWlpaWlopFuKgAAAAATTExMMBEAAAAAAAAAAAAAXaWlpaWlpaWlpZgAAAAAAAAhNjAqJB4YEgwGAAAAAAAAECEyRFVmd4mZVgAAAAAAADY6Ojo6Ojo6OjohAAAAAAAAAAAAAChzt7e3LwAAAABIvnc5Ojo6Ojo6Oi8AAAAAAAAAADuFt7e3t7aXOQAAPb///7AaCxIYHiQpEQAAAAAAAE2Xt7e3t6xiycmWynPt6////+hSAAAAAAAAAAAAAAB7t7e3t5pPE7bJycDbzO3tfuf///+LAAAAAAAAAAAAAIi3t4c9AACJycmL19u17e3fGK7////DLQAAAAAAAAAAFlgrAAAAXcnJtxTb256U7e1nAHb////8RgAAAAAAAAAAAAAAADDJyclBK9vbiDTt7ccAAD3T//+BAAAAAAAAAAAAAAAEp8nJbQBC29txAKzt7U8AAAWYrhkAAAAAAAAAAAAAAHjJyZoAAFnb21oATO3trwAAAAAAAAAAAAAAAAAAAAAAicnGJAAAcNvbQwAAxO3tNwAAAAAAAAAAAAAAAAAAAAATZTcAAACH29ssAABk7e1yAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJrb2xUAAACfsBwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQbJ7AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIVs/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPcHALAAAAP0YLAAAAAAAAAAAAAAAAAAAAAA1CJAAAAEVwcBYAACdeXi0AAAAAAAAAAAAAAAAAAAAAWYKAFwAAOXBwIgAATl5eFgAAAAAAAAAAAAAAAAAAAABNgoJkAAAucHAuAB5eXkYAAAAAAAAAAAAAAAAAAAAAAANsgoJHACJwcDoARF5eHwAAAS00BwAAAAAAAAAAAAAAAB+CgoIqFnBwRRVeXk8AABI/TEwmAAAAAAAAABJHIgAAADyCgnYNcHBRO15eKQAjTExMSxUAAAAAAAAAbpSUbTEAAFmCglpucF1eXlgHNExMTDoOAAAAAAAAAABjlJSUlHxADHaCgmJwaF5eMkVMTEwpAAAAAAAAAAAAAAA+epSUlJSLT4KCYWg7Xl1MTExFGQAAAAAAAAAAAAAAAAAAL2yUlJSUk2IlAAAYOUxMNAgLEhgeJCkRAAAAAAAAAAAAACFdlJSUJgAAAAAWOTM5Ojo6Ojo6Oi8AAAAAABAhMkRVZneJmVYAAAAAAAA2Ojo6Ojo6Ojo6IQAAAABdpaWlpaWlpaWlmAAAAAAAAG+DMCokHhgSDAYAAAAAAIalpaWlpaWlopGJNAAAAABB////oDgAAAAAAAAAAAAAMXRmVEMyIRN+t7eJMwAAQ7L9/////7lSAAAAAAAAAAAAAAAAAAA7p7e3t8jJc8qx7e2I8P/////TawAAAAAAAAAAAAAAZLe3t6ZrycnM28Dt7dYXbtb/////qwAAAAAAAAAAIYy3t7d9Eb3JybXb16Pt7aIAAFW9//+9AAAAAAAAADK1t7e3VQBXycl+ntvbGNjt7W0AAAA7ex4AAAAAAAAAXLe3mCwAAKnJySyI29srTe3t7TkAAAAAAAAAAAAAAAASfW0EAABDycmSAHHb20IAge3txAUAAAAAAAAAAAAAAAAAAAAAAJXJyUAAWtvbWQAAte3tjQAAAAAAAAAAAAAAAAAAAAAvycmmAABD29twAAAq6u2iAAAAAAAAAAAAAAAAAAAAAGHJyVQAACzb24cAAABBeBcAAAAAAAAAAAAAAAAAAAAAGJWHAAAAFdvbmgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAe7JBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
    "Qk32BwAAAAAAADYEAAAoAAAAHgAAAB4AAAABAAgAAAAAAMADAAATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABMcAAAAABU7IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARcHAuAAAASF5aAAAAAAAAAAAAAAAAAAAAAAAAAAAAABhwcFEAAABcXlIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGFwcAkAE15ePgAAAB80EgAAAAAAAAAAAAAAH2FDAAAAPnBwLAAnXl4qAAAcTEw5AAAAAAAAAAAAAABZgoJOAAAccHBOADpeXhcAF0xMTCcAAAAAAAAAAAAAADaCgoJYAQBkcHAGTl5eAxFKTEwuAAAAAAAAAAAAAAAAADGCgoJhCkFwcCleXkwMRExMMwAAAAAAAAAAAAAAAAAAACd+goJrHnBwTF5eOD5MTDkBAAAADQkAAAAAAAAAAAAAAB10goJ1ZnBuXl45TEw/BgAOIDI6OgoAAAAAMo6AYkMkBRRrgoJ4cFBUT0xMRBAiNDo6Ojo6DgAAAABclJSUlJSUd1lhgncNAAANRUY1Ojo6Ojo6KhgAAAAAACBykJSUlJSUlJR8FgAAAAAHOjo6OjopFwUAAAAAAAAAAAAAHj1ce5SUlIUAAAAAAAA0dkQVAwAAAAAAAAAAAAAAAAAAAAAKPXCidgAAAAAAAOX////Un2o1AAAAAAAAAAAAAA5Bc6WlpaWlEwAAAAAo1f/////////5xDgAAAAAAEN3paWlpaWll6mnHwAAGtjtsZnO////////nwAAAAAppaWlpaWTYC2kt7eotZ3b2+3twyQJPnOo3fRXAAAAABylpY9cKQAPl7e3icnJ19vI1e3t1DUAAAAAAAAAAAAAABkkAAAAAYm3t5Z4ycmU29s7w+3t5kcAAAAAAAAAAAAAAAAAAAB8t7ekHKLJyVDb238Tsu3t7VkAAAAAAAAAAAAAAAAAbre3sSkHycmnDdvbwwACoO3t7WIAAAAAAAAAAAAAAF+3t7c3ADHJyX0AmdvbNgAAj+3togAAAAAAAAAAAAAAiLe3RAAAW8nJUwBW29t6AAAAerE5AAAAAAAAAAAAAAAsfUsAAACFyckpABLb270AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAK7JxAAAAJ/b2zAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwcmaAAAAWdvbIQAAAAAAAAAAAAAAAAAAAAAAAAAAAABEfSwAAAAANiUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
  ];

  // src/background/managers/DisplayManager.ts
  var CANVAS_WIDTH = 576;
  var CANVAS_HEIGHT = 288;
  var SPINNER_X = CANVAS_WIDTH - SPINNER_SIZE;
  var SPINNER_Y = 0;
  var SPINNER_FRAME_MS = 125;

  class DisplayManager2 {
    session;
    spinnerTimer = null;
    spinnerFrame = 0;
    text = null;
    textClearTimer = null;
    spinnerBmp = null;
    reader;
    frameToken;
    frameEpoch = 0;
    frameQueue = Promise.resolve();
    constructor(session, publish = () => {}) {
      this.session = session;
      this.reader = new AnswerReader(session, publish);
    }
    get hasDisplay() {
      return Boolean(this.session.capabilities?.hasDisplay);
    }
    canvas() {
      const d = this.session.capabilities?.display;
      return { w: d?.width ?? CANVAS_WIDTH, h: d?.height ?? CANVAS_HEIGHT };
    }
    pushFrame(explicit = false, durationMs) {
      if (!this.hasDisplay)
        return;
      const { w, h } = this.canvas();
      const elements = [];
      if (this.text != null) {
        elements.push({ type: "text", id: "text", box: { x: 0, y: 0, w, h }, text: this.text });
      }
      if (this.spinnerBmp != null) {
        elements.push({
          type: "image",
          id: "spinner",
          box: { x: SPINNER_X, y: SPINNER_Y, w: SPINNER_SIZE, h: SPINNER_SIZE },
          data: this.spinnerBmp
        });
      }
      const epoch = this.frameEpoch;
      this.frameQueue = this.frameQueue.then(async () => {
        if (epoch !== this.frameEpoch || !explicit && !this.frameToken)
          return;
        const result = await this.session.sendRequest({
          type: MiniappRequestType.RENDER,
          view: "main",
          elements,
          durationMs,
          ifDisplayToken: explicit ? undefined : this.frameToken
        }).catch(() => ({ status: "blocked", displayToken: undefined }));
        if (epoch === this.frameEpoch) {
          this.frameToken = result.status === "displayed" ? result.displayToken : undefined;
        } else if (result.displayToken) {
          this.session.sendRequest({
            type: MiniappRequestType.RENDER,
            view: "main",
            elements: [],
            ifDisplayToken: result.displayToken
          }).catch(() => {});
        }
      });
    }
    setText(text, durationMs) {
      if (this.textClearTimer) {
        clearTimeout(this.textClearTimer);
        this.textClearTimer = null;
      }
      this.reader.cancel();
      this.frameEpoch++;
      this.frameToken = undefined;
      this.text = text;
      this.pushFrame(true, durationMs);
      if (text != null && durationMs) {
        this.textClearTimer = setTimeout(() => {
          this.textClearTimer = null;
          this.text = null;
          this.pushFrame();
        }, durationMs);
      }
    }
    showStatus(text, durationMs = 5000) {
      this.setText(text, durationMs);
    }
    showResponse(text, messageId) {
      this.resetTransient();
      this.reader.show(text, messageId);
    }
    resetTransient() {
      this.frameEpoch++;
      this.frameToken = undefined;
      if (this.textClearTimer)
        clearTimeout(this.textClearTimer);
      if (this.spinnerTimer)
        clearInterval(this.spinnerTimer);
      this.textClearTimer = null;
      this.spinnerTimer = null;
      this.text = null;
      this.spinnerBmp = null;
    }
    destroy() {
      this.resetTransient();
      this.reader.destroy();
    }
    showWelcome() {
      this.setText(`Mentra AI

Welcome to Mentra AI.
Say "Hey Mentra" followed by your question.`);
    }
    clear() {
      const token = this.frameToken;
      const active = this.text !== null || this.spinnerBmp !== null;
      this.reader.clear();
      this.resetTransient();
      if (active)
        this.session.sendRequest({ type: MiniappRequestType.RENDER, view: "main", elements: [], ifDisplayToken: token }).catch(() => {});
    }
    get spinnerRunning() {
      return this.spinnerTimer !== null;
    }
    startSpinner() {
      if (!this.hasDisplay)
        return false;
      if (this.spinnerTimer)
        return true;
      this.reader.cancel();
      this.frameEpoch++;
      this.frameToken = undefined;
      this.spinnerFrame = 0;
      const tick = () => {
        this.spinnerBmp = SPINNER_FRAMES[this.spinnerFrame % SPINNER_FRAMES.length];
        this.spinnerFrame++;
        this.pushFrame();
      };
      this.spinnerBmp = SPINNER_FRAMES[0];
      this.pushFrame(true);
      this.spinnerTimer = setInterval(tick, SPINNER_FRAME_MS);
      return true;
    }
    stopSpinner() {
      if (this.spinnerTimer) {
        clearInterval(this.spinnerTimer);
        this.spinnerTimer = null;
      }
      this.spinnerBmp = null;
      this.pushFrame();
    }
  }

  // src/background/lib/location-keywords.ts
  var LOCATION_KEYWORDS = [
    "where am i",
    "my location",
    "location",
    "my address",
    "current location",
    "my current address",
    "what city",
    "which city",
    "what town",
    "what state",
    "what country",
    "what neighborhood",
    "what area",
    "what street",
    "which street",
    "nearby",
    "near me",
    "around here",
    "close to me",
    "closest",
    "nearest",
    "in this area",
    "directions to",
    "how to get to",
    "navigate to",
    "route to",
    "how far",
    "distance to",
    "walking distance",
    "driving distance",
    "restaurants nearby",
    "coffee near",
    "food near",
    "stores near",
    "shops near",
    "places near",
    "things to do near",
    "what's around"
  ];
  var WEATHER_KEYWORDS = [
    "weather",
    "temperature",
    "forecast",
    "rain",
    "sunny",
    "cloudy",
    "snow",
    "humidity",
    "wind speed"
  ];
  function isLocationQuery(query) {
    const q = query.toLowerCase();
    if (LOCATION_KEYWORDS.some((kw) => q.includes(kw))) {
      return true;
    }
    if (WEATHER_KEYWORDS.some((kw) => q.includes(kw))) {
      return true;
    }
    return false;
  }
  function isWeatherQuery(query) {
    const q = query.toLowerCase();
    return WEATHER_KEYWORDS.some((kw) => q.includes(kw));
  }

  // src/background/managers/LocationManager.ts
  var GOOGLE_WEATHER_API_KEY = "";
  function parseAddress(address, road) {
    const parts = address.split(",").map((p) => p.trim()).filter(Boolean);
    const stateIdx = parts.findIndex((p) => /\d[\d-]*$/.test(p) && !/^\d/.test(p));
    let state = "Unknown";
    let city = "Unknown";
    let country = "Unknown";
    if (stateIdx >= 0) {
      state = parts[stateIdx].replace(/\s*\d[\d-]*$/, "").trim() || "Unknown";
      if (stateIdx >= 1)
        city = parts[stateIdx - 1];
      if (stateIdx + 1 < parts.length)
        country = parts[stateIdx + 1];
    } else {
      if (parts.length >= 1)
        country = parts[parts.length - 1];
      if (parts.length >= 2)
        state = parts[parts.length - 2];
      if (parts.length >= 3)
        city = parts[parts.length - 3];
      else if (parts.length === 2)
        city = parts[0];
    }
    const first = parts[0] ?? "";
    const streetAddress = stateIdx > 0 && /^\d/.test(first) ? first : road || undefined;
    return { streetAddress, neighborhood: undefined, city, state, country };
  }

  class LocationManager {
    session;
    currentLat = null;
    currentLng = null;
    userTimezone = LocationManager.runtimeTimezone();
    cachedContext = null;
    lastGeocodedLat = null;
    lastGeocodedLng = null;
    constructor(session) {
      this.session = session;
    }
    static runtimeTimezone() {
      try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone || null;
      } catch {
        return null;
      }
    }
    updateCoordinates(lat, lng) {
      this.currentLat = lat;
      this.currentLng = lng;
    }
    hasLocation() {
      return this.currentLat !== null && this.currentLng !== null;
    }
    getCoordinates() {
      if (!this.hasLocation())
        return null;
      return { lat: this.currentLat, lng: this.currentLng };
    }
    queryNeedsLocation(query) {
      return isLocationQuery(query) || isWeatherQuery(query);
    }
    queryNeedsWeather(query) {
      return isWeatherQuery(query);
    }
    async fetchContextIfNeeded(query) {
      if (!this.hasLocation())
        return null;
      const lat = this.currentLat;
      const lng = this.currentLng;
      const needsGeocoding = this.shouldRefreshGeocoding(lat, lng);
      const needsWeather = this.queryNeedsWeather(query) && this.shouldRefreshWeather();
      if (!needsGeocoding && !needsWeather && this.cachedContext) {
        return this.cachedContext;
      }
      if (!this.cachedContext || needsGeocoding) {
        await this.refreshGeocoding(lat, lng);
      }
      if (needsWeather && this.cachedContext) {
        await this.refreshWeather(lat, lng);
      }
      return this.cachedContext;
    }
    getCachedContext() {
      return this.cachedContext;
    }
    getTimezone() {
      return this.cachedContext?.timezone ?? this.userTimezone;
    }
    setTimezone(timezone) {
      this.userTimezone = timezone;
      if (this.cachedContext)
        this.cachedContext.timezone = timezone;
    }
    destroy() {
      this.cachedContext = null;
      this.currentLat = null;
      this.currentLng = null;
      this.lastGeocodedLat = null;
      this.lastGeocodedLng = null;
    }
    shouldRefreshGeocoding(lat, lng) {
      if (!this.cachedContext || this.lastGeocodedLat === null)
        return true;
      const cacheAge = Date.now() - this.cachedContext.geocodedAt;
      if (cacheAge > LOCATION_CACHE_SETTINGS.geocodeCacheDurationMs)
        return true;
      const latDiff = Math.abs(lat - this.lastGeocodedLat);
      const lngDiff = Math.abs(lng - this.lastGeocodedLng);
      return latDiff > LOCATION_CACHE_SETTINGS.minMovementDegrees || lngDiff > LOCATION_CACHE_SETTINGS.minMovementDegrees;
    }
    shouldRefreshWeather() {
      if (!this.cachedContext || !this.cachedContext.weather)
        return true;
      const cacheAge = Date.now() - this.cachedContext.weatherFetchedAt;
      return cacheAge > LOCATION_CACHE_SETTINGS.weatherCacheDurationMs;
    }
    async refreshGeocoding(lat, lng) {
      try {
        const result = await this.session.navigation.reverseGeocodeRoad({ lat, lng });
        if (!result.ok || !result.address) {
          console.warn(`\uD83D\uDCCD reverseGeocode failed: ${result.error ?? "no address"}`);
          this.initializeContextWithDefaults(lat, lng);
          return;
        }
        const parsed = parseAddress(result.address, result.road ?? undefined);
        this.cachedContext = {
          lat,
          lng,
          city: parsed.city,
          state: parsed.state,
          country: parsed.country,
          streetAddress: parsed.streetAddress,
          neighborhood: parsed.neighborhood,
          timezone: this.cachedContext?.timezone ?? this.userTimezone ?? undefined,
          geocodedAt: Date.now(),
          weatherFetchedAt: this.cachedContext?.weatherFetchedAt || 0,
          weather: this.cachedContext?.weather
        };
        this.lastGeocodedLat = lat;
        this.lastGeocodedLng = lng;
        console.log(`\uD83D\uDCCD geocoded ${lat.toFixed(4)},${lng.toFixed(4)} → ${parsed.streetAddress ?? parsed.city}, ${parsed.state}`);
      } catch (error) {
        console.error("Geocoding error:", error);
        this.initializeContextWithDefaults(lat, lng);
      }
    }
    async refreshWeather(lat, lng) {
      if (!GOOGLE_WEATHER_API_KEY || !this.cachedContext)
        return;
      try {
        const url = `https://weather.googleapis.com/v1/currentConditions:lookup?key=${GOOGLE_WEATHER_API_KEY}&location.latitude=${lat}&location.longitude=${lng}`;
        const response = await fetch(url, { headers: { Accept: "application/json" } });
        if (!response.ok)
          return;
        const data = await response.json();
        const tempCelsius = Math.round(data.temperature?.degrees ?? 0);
        const tempFahrenheit = Math.round(tempCelsius * 9 / 5 + 32);
        const condition = data.condition?.description || "Unknown";
        const humidity = data.humidity;
        const windSpeed = data.wind?.speed?.value ? Math.round(data.wind.speed.value * 2.237) : undefined;
        const windDir = data.wind?.direction?.degrees ? this.getWindDirection(data.wind.direction.degrees) : undefined;
        this.cachedContext.weather = {
          temperature: tempFahrenheit,
          temperatureCelsius: tempCelsius,
          condition,
          humidity,
          wind: windSpeed && windDir ? `${windSpeed} mph ${windDir}` : undefined
        };
        this.cachedContext.weatherFetchedAt = Date.now();
      } catch (error) {
        console.error("Weather error:", error);
      }
    }
    initializeContextWithDefaults(lat, lng) {
      this.cachedContext = {
        lat,
        lng,
        city: "Unknown",
        state: "Unknown",
        country: "Unknown",
        timezone: this.cachedContext?.timezone ?? this.userTimezone ?? undefined,
        geocodedAt: Date.now(),
        weatherFetchedAt: 0
      };
      this.lastGeocodedLat = lat;
      this.lastGeocodedLng = lng;
    }
    getWindDirection(degrees) {
      const directions = [
        "N",
        "NNE",
        "NE",
        "ENE",
        "E",
        "ESE",
        "SE",
        "SSE",
        "S",
        "SSW",
        "SW",
        "WSW",
        "W",
        "WNW",
        "NW",
        "NNW"
      ];
      return directions[Math.round(degrees / 22.5) % 16];
    }
  }

  // src/background/managers/NotificationManager.ts
  var MAX_NOTIFICATIONS = 20;
  var MAX_NOTIFICATION_AGE_MS = 5 * 60 * 1000;

  class NotificationManager {
    notifications = [];
    addNotification(notification) {
      this.notifications.push({ data: notification, timestamp: Date.now() });
      if (this.notifications.length > MAX_NOTIFICATIONS) {
        this.notifications = this.notifications.slice(-MAX_NOTIFICATIONS);
      }
    }
    getRecentNotifications(limit = 5) {
      const now = Date.now();
      return this.notifications.filter((n) => now - n.timestamp < MAX_NOTIFICATION_AGE_MS).slice(-limit).map((n) => n.data);
    }
    formatForPrompt(limit = 5) {
      const recent = this.getRecentNotifications(limit);
      if (recent.length === 0)
        return "No recent notifications.";
      try {
        return `Recent notifications:
${JSON.stringify(recent, null, 2)}`;
      } catch {
        return "Unable to format notifications.";
      }
    }
    hasNotifications() {
      const now = Date.now();
      return this.notifications.some((n) => now - n.timestamp < MAX_NOTIFICATION_AGE_MS);
    }
    clear() {
      this.notifications = [];
    }
    destroy() {
      this.clear();
    }
  }

  // src/background/managers/PhotoManager.ts
  function isValidInlineImage(dataUrl) {
    const match = /^data:(image\/[a-z0-9.+-]+);base64,([a-z0-9+/]+=*)$/i.exec(dataUrl);
    if (!match || match[2].length < 8)
      return false;
    const mime = match[1].toLowerCase();
    const head = match[2].slice(0, 16);
    if (mime === "image/jpeg" || mime === "image/jpg")
      return head.startsWith("/9j/");
    if (mime === "image/png")
      return head.startsWith("iVBORw0KGgo");
    if (mime === "image/gif")
      return head.startsWith("R0lGOD");
    if (mime === "image/webp")
      return head.startsWith("UklGR");
    if (mime === "image/avif")
      return head.includes("Z0eXBhdmlm");
    return false;
  }
  function managedPhotoUrl(url) {
    if (!url || !/^https?:\/\//i.test(url))
      return null;
    return url.replace(/^http:\/\//i, "https://");
  }

  class PhotoManager {
    session;
    currentPhoto = null;
    previousPhotos = [];
    constructor(session) {
      this.session = session;
    }
    get hasCamera() {
      return Boolean(this.session.capabilities?.hasCamera);
    }
    async takePhoto() {
      if (!PHOTO_SETTINGS.enabled || !this.hasCamera)
        return null;
      try {
        const raw = await this.session.camera.takePhoto({
          size: "low",
          mode: "photo",
          transferMethod: "ble",
          compress: "high",
          sound: false
        });
        const inline = raw.dataUrl && isValidInlineImage(raw.dataUrl) ? raw.dataUrl : undefined;
        const cloudUrl = managedPhotoUrl(raw.photoUrl);
        if (raw.dataUrl && !inline) {
          console.warn(`\uD83D\uDCF8 rejecting invalid inline photo requestId=${raw.requestId}`);
        }
        if (!inline && !cloudUrl) {
          console.warn(`\uD83D\uDCF8 capture returned no usable image requestId=${raw.requestId}`);
          return null;
        }
        const stored = {
          requestId: raw.requestId,
          ...inline ? { dataUrl: inline } : {},
          photoUrl: inline ?? cloudUrl,
          isLocal: Boolean(inline),
          mimeType: raw.mimeType || "image/jpeg",
          size: raw.size ?? 0,
          timestamp: Date.now()
        };
        console.log(`\uD83D\uDCF8 photo ${stored.isLocal ? "LOCAL" : "cloud URL"} ready requestId=${stored.requestId} size=${stored.size}`);
        return stored;
      } catch (error) {
        console.error("Failed to capture photo:", error);
        return null;
      }
    }
    commitPhoto(photo) {
      if (this.currentPhoto?.requestId === photo.requestId)
        return;
      if (this.currentPhoto) {
        this.previousPhotos.unshift(this.currentPhoto);
        this.previousPhotos = this.previousPhotos.slice(0, PHOTO_SETTINGS.previousPhotosToKeep);
      }
      this.currentPhoto = photo;
    }
    getPhotosForContext() {
      return [this.currentPhoto, ...this.previousPhotos].flatMap((photo) => photo?.dataUrl ? [photo.dataUrl] : []);
    }
    getPhotoUrlsForContext() {
      return [this.currentPhoto, ...this.previousPhotos].flatMap((photo) => photo && !photo.isLocal ? [photo.photoUrl] : []);
    }
    getCurrentPhoto() {
      return this.currentPhoto;
    }
    clear() {
      this.currentPhoto = null;
      this.previousPhotos = [];
    }
    destroy() {
      this.clear();
    }
  }

  // src/background/lib/tts-formatter.ts
  var ONES = [
    "zero",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "ten",
    "eleven",
    "twelve",
    "thirteen",
    "fourteen",
    "fifteen",
    "sixteen",
    "seventeen",
    "eighteen",
    "nineteen"
  ];
  var TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];
  function numberToWords(num) {
    if (!Number.isFinite(num))
      return String(num);
    const absNum = Math.abs(num);
    const isNegative = num < 0;
    if (!Number.isInteger(absNum)) {
      const [intPart, decPart] = absNum.toString().split(".");
      const intWords = numberToWords(parseInt(intPart, 10));
      const decWords = decPart.split("").map((d) => ONES[parseInt(d, 10)]).join(" ");
      return (isNegative ? "negative " : "") + intWords + " point " + decWords;
    }
    if (absNum < 20) {
      return (isNegative ? "negative " : "") + ONES[absNum];
    }
    if (absNum < 100) {
      const ten = Math.floor(absNum / 10);
      const one = absNum % 10;
      return (isNegative ? "negative " : "") + TENS[ten] + (one ? "-" + ONES[one] : "");
    }
    if (absNum < 1000) {
      const hundred = Math.floor(absNum / 100);
      const remainder = absNum % 100;
      return (isNegative ? "negative " : "") + ONES[hundred] + " hundred" + (remainder ? " " + numberToWords(remainder) : "");
    }
    if (absNum < 1e6) {
      const thousand = Math.floor(absNum / 1000);
      const remainder = absNum % 1000;
      return (isNegative ? "negative " : "") + numberToWords(thousand) + " thousand" + (remainder ? " " + numberToWords(remainder) : "");
    }
    if (absNum < 1e9) {
      const million = Math.floor(absNum / 1e6);
      const remainder = absNum % 1e6;
      return (isNegative ? "negative " : "") + numberToWords(million) + " million" + (remainder ? " " + numberToWords(remainder) : "");
    }
    return (isNegative ? "negative " : "") + absNum.toString();
  }
  function formatForTTS(text) {
    let result = text;
    result = result.replace(/(\d+(?:\.\d+)?)\s*°\s*F\b/gi, (_, num) => {
      return numberToWords(parseFloat(num)) + " degrees fahrenheit";
    });
    result = result.replace(/(\d+(?:\.\d+)?)\s*°\s*C\b/gi, (_, num) => {
      return numberToWords(parseFloat(num)) + " degrees celsius";
    });
    result = result.replace(/(\d+(?:\.\d+)?)\s*°/g, (_, num) => {
      return numberToWords(parseFloat(num)) + " degrees";
    });
    result = result.replace(/\$(\d+(?:,\d{3})*(?:\.\d{2})?)/g, (_, num) => {
      const cleanNum = num.replace(/,/g, "");
      const parts = cleanNum.split(".");
      let words = numberToWords(parseInt(parts[0], 10)) + " dollars";
      if (parts[1] && parseInt(parts[1], 10) > 0) {
        words += " and " + numberToWords(parseInt(parts[1], 10)) + " cents";
      }
      return words;
    });
    result = result.replace(/(\d+(?:\.\d+)?)\s*%/g, (_, num) => {
      return numberToWords(parseFloat(num)) + " percent";
    });
    result = result.replace(/(\d{1,2}):(\d{2})(?:\s*(AM|PM|am|pm))?/g, (_, hours, minutes, ampm) => {
      const h = parseInt(hours, 10);
      const m = parseInt(minutes, 10);
      let timeWords = numberToWords(h);
      if (m === 0) {
        timeWords += " o'clock";
      } else if (m < 10) {
        timeWords += " oh " + numberToWords(m);
      } else {
        timeWords += " " + numberToWords(m);
      }
      if (ampm) {
        timeWords += " " + ampm.toUpperCase().split("").join(" ");
      }
      return timeWords;
    });
    result = result.replace(/\b(\d+(?:\.\d+)?)\b/g, (_, num) => {
      return numberToWords(parseFloat(num));
    });
    result = result.replace(/\be\.g\./gi, "for example");
    result = result.replace(/\bi\.e\./gi, "that is");
    result = result.replace(/\betc\./gi, "et cetera");
    result = result.replace(/\bvs\./gi, "versus");
    result = result.replace(/\bDr\./gi, "Doctor");
    result = result.replace(/\bMr\./gi, "Mister");
    result = result.replace(/\bMrs\./gi, "Missus");
    result = result.replace(/\bMs\./gi, "Miss");
    result = result.replace(/\bSt\./gi, "Street");
    result = result.replace(/\bAve\./gi, "Avenue");
    result = result.replace(/\bBlvd\./gi, "Boulevard");
    result = result.replace(/\bkm\b/gi, "kilometers");
    result = result.replace(/\bmi\b/gi, "miles");
    result = result.replace(/\bmph\b/gi, "miles per hour");
    result = result.replace(/\bkph\b/gi, "kilometers per hour");
    result = result.replace(/\blbs?\b/gi, "pounds");
    result = result.replace(/\bkg\b/gi, "kilograms");
    result = result.replace(/\bft\b/gi, "feet");
    result = result.replace(/\bcm\b/gi, "centimeters");
    result = result.replace(/\bmm\b/gi, "millimeters");
    result = result.replace(/\s+/g, " ").trim();
    return result;
  }

  // src/background/lib/action-result.ts
  var TRANSIENT_STATUSES = new Set([
    "accepted",
    "active",
    "listening",
    "pending",
    "processing",
    "queued",
    "recording",
    "running",
    "saving",
    "started",
    "starting",
    "stopping",
    "translating"
  ]);
  var TERMINAL_STATUSES = new Set(["complete", "completed", "done", "ok", "stopped", "succeeded", "success"]);
  var USER_FACING_FIELDS = ["message", "text", "result", "translation"];
  function normalizedStatus(value) {
    return typeof value === "string" ? value.trim().toLowerCase() : null;
  }
  function displayableText(value) {
    const trimmed = value.trim();
    if (!trimmed)
      return null;
    const status = normalizedStatus(trimmed);
    if (status && (TRANSIENT_STATUSES.has(status) || TERMINAL_STATUSES.has(status)))
      return null;
    try {
      const parsed = JSON.parse(trimmed);
      if (parsed !== null && typeof parsed === "object")
        return null;
    } catch {}
    return trimmed.slice(0, 400);
  }
  function formatActionResult(result) {
    if (result === undefined || result === null)
      return null;
    if (typeof result === "string") {
      return displayableText(result);
    }
    if (typeof result === "number" || typeof result === "boolean")
      return String(result);
    if (typeof result === "object" && !Array.isArray(result)) {
      const record = result;
      const status = normalizedStatus(record.status);
      if (status && TRANSIENT_STATUSES.has(status))
        return null;
      for (const field of USER_FACING_FIELDS) {
        const value = record[field];
        if (typeof value !== "string")
          continue;
        const text = displayableText(value);
        if (text)
          return text;
      }
    }
    return null;
  }

  // src/background/lib/device-command-results.ts
  var MAX_RESULT_JSON_CHARS = 8000;
  var RESULT_PREVIEW_CHARS = 2000;
  function displayableText2(value) {
    if (typeof value !== "string")
      return null;
    const text = value.trim().replace(/\s+/g, " ");
    if (!text)
      return null;
    if (text.startsWith("{") || text.startsWith("[")) {
      try {
        const parsed = JSON.parse(text);
        if (parsed !== null && typeof parsed === "object")
          return null;
      } catch {}
    }
    return text.slice(0, 240);
  }
  function compactActionResult(result) {
    if (result === undefined)
      return;
    try {
      const json = JSON.stringify(result);
      if (json === undefined || json.length <= MAX_RESULT_JSON_CHARS)
        return result;
      return { truncated: true, preview: json.slice(0, RESULT_PREVIEW_CHARS) };
    } catch {
      return { unserializable: true };
    }
  }
  function safeActionErrorMessage(value) {
    return displayableText2(value) ?? "The action reported a failure.";
  }
  function semanticActionError(result) {
    if (!result || typeof result !== "object" || Array.isArray(result))
      return null;
    const record = result;
    const failed = record.ok === false || ["error", "failed", "failure"].includes(String(record.status ?? "").toLowerCase());
    if (!failed)
      return null;
    if (typeof record.error === "string" && record.error.trim())
      return safeActionErrorMessage(record.error);
    if (record.error && typeof record.error === "object") {
      const message = record.error.message;
      if (typeof message === "string" && message.trim())
        return safeActionErrorMessage(message);
    }
    if (typeof record.message === "string" && record.message.trim())
      return safeActionErrorMessage(record.message);
    return "The action reported a failure.";
  }
  function fallbackDeviceCommandResponse(commands, results) {
    const failed = results.find((result) => !result.ok);
    if (failed) {
      const reason = displayableText2(failed.error?.message);
      return reason ? `That didn't work — ${reason}` : "That didn't work — the action failed.";
    }
    if (commands.length === 1 && commands[0].type === "invoke_action") {
      const text = formatActionResult(results[0]?.result);
      if (text)
        return text;
      if (commands[0].actionId === "start_navigation") {
        const record = results[0]?.result;
        const destination = record?.destination;
        const name = typeof destination?.name === "string" ? destination.name.trim() : typeof destination?.address === "string" ? destination.address.trim() : "";
        return name ? `Navigation started to ${name}.` : "Navigation started.";
      }
    }
    return "I completed the action, but couldn't summarize the result.";
  }

  // src/background/lib/agent-actions.ts
  function accountName(reply) {
    if (/\bgmail\b/i.test(reply))
      return "Gmail";
    if (/\bgoogle calendar\b/i.test(reply))
      return "Google Calendar";
    if (/\bcalendar\b/i.test(reply))
      return "Calendar";
    return "Service";
  }
  function accountNameFromToolkit(toolkit) {
    const normalized = toolkit.trim().toLowerCase();
    if (normalized === "gmail")
      return "Gmail";
    if (normalized === "googlecalendar" || normalized === "google_calendar")
      return "Google Calendar";
    const words = toolkit.trim().replace(/[_-]+/g, " ").split(/\s+/).filter(Boolean);
    if (!words.length)
      return "Service";
    return words.map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(" ");
  }
  function effectiveReplyActions(_reply, actions) {
    return actions?.length ? actions : undefined;
  }
  function toMessageActions(actions, _reply) {
    if (!actions?.length)
      return;
    const mapped = actions.filter((action) => action.type === "open_url" && action.url).map((action) => {
      const account = action.toolkit ? accountNameFromToolkit(action.toolkit) : null;
      return {
        type: "open_url",
        kind: action.kind,
        url: action.url,
        ...action.toolkit ? { toolkit: action.toolkit } : {},
        label: action.label ?? (action.kind === "oauth_connect" ? account ? `Link ${account} account` : "Link account" : "Open link")
      };
    });
    return mapped.length ? mapped : undefined;
  }
  function connectedAccountFromReply(reply) {
    const normalized = reply.replace(/[’]/g, "'");
    if (/\b(?:is not|isn't|isnt|not|never)\s+(?:yet\s+)?(?:connected|linked)\b/i.test(normalized))
      return null;
    if (!/\b(?:connected|linked|connection successful)\b/i.test(normalized))
      return null;
    return accountName(normalized);
  }
  function stripActionUrls(reply, actions) {
    let clean = reply;
    for (const action of actions ?? []) {
      if (action.type === "open_url" && action.url)
        clean = clean.split(action.url).join("");
    }
    return clean.replace(/:[ \t]*(?=\n|$)/g, ".").replace(/\n[ \t]*\n(?:[ \t]*\n)+/g, `

`).trim();
  }

  // src/background/lib/photo-capture.ts
  function selectPhotoWaitCapMs(visualQuery, ordinaryWaitCapMs, visualWaitCapMs) {
    return visualQuery ? visualWaitCapMs : ordinaryWaitCapMs;
  }
  async function resolvePhotoCapture(capture, waitCapMs) {
    let timeoutId;
    try {
      const result = await Promise.race([
        capture.then((photo) => ({ photo, status: photo ? "ready" : "failed" })).catch(() => ({ photo: null, status: "failed" })),
        new Promise((resolve) => {
          timeoutId = setTimeout(() => resolve({ photo: null, status: "timed_out" }), waitCapMs);
        })
      ]);
      return result;
    } finally {
      if (timeoutId)
        clearTimeout(timeoutId);
    }
  }

  // src/background/lib/wake-word.ts
  var WAKE_GREETINGS = ["hey", "hay", "hi", "ok", "okay", "hello"];
  var WAKE_NAMES = [
    "mentora",
    "mentrop",
    "mentra",
    "mantra",
    "mintra",
    "muntra",
    "montra",
    "myntra",
    "mendra",
    "mentor"
  ];
  var WAKE_WORDS = WAKE_GREETINGS.flatMap((greeting) => WAKE_NAMES.map((name) => `${greeting} ${name}`));
  var WAKE_PATTERNS = WAKE_WORDS.map((ww) => {
    let pattern = "(?:^|[^a-z])";
    for (let i = 0;i < ww.length; i++) {
      const ch = ww[i];
      if (ch === " ") {
        pattern += ",?\\s+";
      } else {
        pattern += ch;
        const next = ww[i + 1];
        if (next && next !== " ") {
          pattern += "\\s*";
        }
      }
    }
    pattern += "(?![a-z])";
    return new RegExp(pattern, "i");
  });
  function detectWakeWord(text) {
    const lowerText = text.toLowerCase().trim();
    for (let i = 0;i < WAKE_PATTERNS.length; i++) {
      const match = lowerText.match(WAKE_PATTERNS[i]);
      if (match && match.index !== undefined) {
        let query = text.slice(match.index + match[0].length).trim();
        query = query.replace(/^[,.\s]+/, "").trim();
        return {
          detected: true,
          query,
          wakeWordUsed: WAKE_WORDS[i]
        };
      }
    }
    return {
      detected: false,
      query: text.trim()
    };
  }
  var WAKE_WORD_TRAILING_FRAGMENTS = (() => {
    const suffixes = [];
    for (const ww of WAKE_WORDS) {
      const lastWord = ww.split(" ").pop() || "";
      for (let len = 1;len < lastWord.length; len++) {
        suffixes.push(lastWord.slice(-len));
      }
    }
    const escaped = suffixes.map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    return new RegExp(`^(?:${escaped.join("|")})[,.!?;:]+\\s*`, "i");
  })();
  function removeWakeWord(text) {
    const result = detectWakeWord(text);
    return result.query;
  }
  function stripWakeWordResidue(text) {
    return text.replace(WAKE_WORD_TRAILING_FRAGMENTS, "").trim();
  }
  function isExplicitVisionQuery(query) {
    return /\b(what (?:am i|are we) looking at|what (?:is|are) (?:this|that|these|those)|what (?:kind|type|brand|make|model|colou?r|size)(?: of [^?.!]{1,60})? (?:is|are) (?:this|that|these|those)|what do you see|describe (?:this|that|what you see)|look at (?:this|that)|read (?:this|that|it)|what does (?:this|that|it) say|identify (?:this|that)|what(?:'s| is) in front of me|how many [^?.!]{1,60} in front of me|can you see (?:this|that)|translate (?:this|that))\b/i.test(query);
  }

  // src/background/managers/QueryProcessor.ts
  var WEB_SEARCH_HINTS = /\b(price|cost|worth|stock|stocks|crypto|bitcoin|weather|forecast|temperature|news|score|scores|latest|current(ly)?|today|tonight|right now|recent|update|who won|election|results?|exchange rate|how much is)\b/i;
  function likelyNeedsWebSearch(query) {
    return WEB_SEARCH_HINTS.test(query);
  }

  class QueryProcessor {
    deps;
    outputEpoch = 0;
    processing = false;
    get isProcessing() {
      return this.processing;
    }
    cancelOutput() {
      this.outputEpoch++;
      this.processing = false;
    }
    constructor(deps) {
      this.deps = deps;
    }
    async processQuery(query, _speakerId, prePhoto) {
      const epoch = ++this.outputEpoch;
      this.processing = true;
      try {
        return await this.runQuery(query, prePhoto, () => epoch === this.outputEpoch);
      } finally {
        if (epoch === this.outputEpoch)
          this.processing = false;
      }
    }
    async runQuery(query, prePhoto, current) {
      const { session, emit } = this.deps;
      const pipelineStart = Date.now();
      const lap = (label) => console.log(`⏱️ [${label}] +${Date.now() - pipelineStart}ms`);
      const hasDisplay = Boolean(session.capabilities?.hasDisplay);
      const hasCamera = Boolean(session.capabilities?.hasCamera);
      const hasSpeakers = Boolean(session.capabilities?.hasSpeaker);
      console.log(`\uD83C\uDF9B️ capabilities: hasDisplay=${hasDisplay} hasCamera=${hasCamera} hasSpeaker=${hasSpeakers} model=${session.capabilities?.modelName ?? "unknown"}`);
      this.deps.audio.startProcessingSound();
      this.deps.display.showStatus("Processing...", 1e4);
      const expectPhoto = hasCamera && PHOTO_SETTINGS.enabled && this.deps.getIncludePhotosWithQueries();
      const resolvedPrePhoto = expectPhoto && prePhoto && !(prePhoto instanceof Promise) ? prePhoto : null;
      const photoInFlight = expectPhoto && prePhoto instanceof Promise ? prePhoto : null;
      const glassesModel = session.capabilities?.modelName || undefined;
      const userMsg = this.deps.messages.addUserMessage(query, {
        image: resolvedPrePhoto?.photoUrl,
        imageSource: resolvedPrePhoto ? glassesModel : undefined,
        imagePending: expectPhoto && !resolvedPrePhoto
      });
      emit({ type: "message", ...userMsg });
      emit({ type: likelyNeedsWebSearch(query) ? "searching" : "processing" });
      lap("EMIT-USER-MSG");
      let photoDataUrls = [];
      let photoUrls = [];
      let hasPhoto = false;
      let photoCaptureStatus = "not_requested";
      let isLocalCapture = false;
      if (expectPhoto) {
        let photo = resolvedPrePhoto;
        if (photo)
          photoCaptureStatus = "ready";
        if (!photo) {
          const capture = photoInFlight ?? this.deps.photo.takePhoto().catch(() => null);
          const visualQuery = isExplicitVisionQuery(query);
          const waitCapMs = selectPhotoWaitCapMs(visualQuery, PHOTO_SETTINGS.captureWaitCapMs, PHOTO_SETTINGS.visualCaptureWaitCapMs);
          console.log(`\uD83D\uDCF8 photo wait cap=${waitCapMs}ms visual=${visualQuery}`);
          const captureResult = await resolvePhotoCapture(capture, waitCapMs);
          photo = captureResult.photo;
          photoCaptureStatus = captureResult.status;
          if (captureResult.status === "timed_out") {
            console.warn(`\uD83D\uDCF8 photo not ready within ${waitCapMs}ms — continuing text-only`);
          } else if (captureResult.status === "failed") {
            console.warn("\uD83D\uDCF8 photo capture failed");
          }
          lap("PHOTO-CAPTURE");
        } else {
          lap("PHOTO-FROM-CACHE");
        }
        if (photo) {
          this.deps.photo.commitPhoto(photo);
          photoDataUrls = this.deps.photo.getPhotosForContext();
          photoUrls = this.deps.photo.getPhotoUrlsForContext();
          hasPhoto = true;
          isLocalCapture = photo.isLocal === true;
        }
        if (!resolvedPrePhoto) {
          const updated = this.deps.messages.setMessageImage(userMsg.id, photo?.photoUrl, glassesModel);
          if (updated)
            emit({ type: "message", ...updated });
        }
      }
      if (isLocalCapture)
        photoUrls = [];
      console.log(`\uD83D\uDCE4 user msg id=${userMsg.id} mode=${isLocalCapture ? "local" : "cloud"} ` + `agentDataUrls=${photoDataUrls.length} agentPhotoUrls=${photoUrls.length}`);
      try {
        const locationData = await session.location.getOnce();
        if (locationData) {
          console.log(`\uD83D\uDCCD coords: ${locationData.lat.toFixed(4)},${locationData.lng.toFixed(4)}`);
          this.deps.location.updateCoordinates(locationData.lat, locationData.lng);
          await this.deps.location.fetchContextIfNeeded(query);
        } else {
          console.warn("\uD83D\uDCCD location.getOnce() returned no data");
        }
      } catch (error) {
        console.warn("\uD83D\uDCCD Failed to get location:", error);
      }
      const locCtx = this.deps.location.getCachedContext();
      console.log(`\uD83D\uDCCD location context: ${locCtx ? `${locCtx.city}, ${locCtx.state}` : "none"}`);
      lap("LOCATION-FETCH");
      const localTime = this.getLocalTime();
      const hasPhotos = hasPhoto;
      const context = {
        hasDisplay,
        supportsAnswerPaging: true,
        hasSpeakers,
        hasCamera,
        hasPhotos,
        photoCaptureStatus,
        glassesType: hasDisplay ? "display" : "camera",
        modelName: session.capabilities?.modelName || undefined,
        location: this.deps.location.getCachedContext(),
        localTime,
        timezone: this.deps.location.getTimezone() ?? undefined,
        notifications: this.deps.notifications.formatForPrompt(),
        conversationHistory: [],
        ...this.deps.getMiniappCatalog().length ? { miniapps: this.deps.getMiniappCatalog() } : {}
      };
      lap("BUILD-CONTEXT");
      const agentPhotos = isLocalCapture && photoDataUrls.length > 0 ? photoDataUrls : undefined;
      if (!current())
        return "";
      this.deps.display.showStatus("Thinking...", 1e4);
      if (agentPhotos) {
        const p = agentPhotos[0];
        const comma = p.indexOf(",");
        console.log(`\uD83D\uDD0E agent image[0]: ${p.slice(0, comma)} b64head="${p.slice(comma + 1, comma + 13)}" len=${p.length}`);
      }
      let response;
      let sources;
      let followUpsPending = false;
      let actions;
      let deviceCommands;
      let deviceCommandBatchId;
      try {
        const result = await generateResponse({
          session,
          requestId: `r-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`,
          query,
          photos: agentPhotos,
          photoUrls: photoUrls.length > 0 ? photoUrls : undefined,
          model: this.deps.getModel(),
          sessionId: this.deps.getSessionId(),
          context,
          onToolCall: (toolName) => {
            if (current() && toolName === "search") {
              this.deps.display.showStatus("Searching...", 1e4);
              emit({ type: "searching" });
            }
          }
        });
        response = result.response;
        sources = result.sources;
        followUpsPending = result.followUpsPending ?? false;
        deviceCommands = result.deviceCommands;
        deviceCommandBatchId = result.deviceCommandBatchId;
        actions = result.actions;
      } catch (error) {
        console.error("Agent error:", error);
        response = "I'm sorry, I had trouble processing that. Please try again.";
      }
      if (!current())
        return response;
      lap("AI-GENERATE-RESPONSE");
      if (deviceCommands?.length) {
        if (!deviceCommandBatchId) {
          console.error("\uD83D\uDCF1 agent protocol error: device commands arrived without a batch id");
          response = "I couldn't complete that action. Please try again.";
        } else {
          this.deps.display.showStatus("Working...", 35000);
          const executionResults = await this.executeDeviceCommands(deviceCommands);
          try {
            response = await finalizeDeviceCommands(session, deviceCommandBatchId, executionResults);
          } catch (error) {
            console.warn("\uD83D\uDCF1 device result finalization failed:", error instanceof Error ? error.message : String(error));
            response = fallbackDeviceCommandResponse(deviceCommands, executionResults);
          }
        }
        lap("DEVICE-COMMANDS");
      }
      if (!current())
        return response;
      actions = effectiveReplyActions(response, actions);
      const messageActions = toMessageActions(actions, response);
      response = stripActionUrls(response, actions);
      const connectedAccount = connectedAccountFromReply(response);
      if (connectedAccount) {
        for (const updated of this.deps.messages.completeOauthActions(connectedAccount)) {
          emit({ type: "message", ...updated });
        }
      }
      const aiMsg = this.deps.messages.addAssistantMessage(response, sources, messageActions);
      emit({ type: "message", ...aiMsg });
      emit({ type: "idle" });
      lap("EMIT-AI-MSG");
      if (followUpsPending)
        this.startFollowUpPump("delegation");
      this.deps.audio.stopProcessingSound();
      this.outputResponse(response, hasSpeakers, hasDisplay, aiMsg.id);
      lap("OUTPUT-TO-GLASSES");
      console.log(`⏱️ [PIPELINE-DONE] Total: ${Date.now() - pipelineStart}ms`);
      return response;
    }
    async executeDeviceCommands(commands) {
      const { session } = this.deps;
      const results = [];
      for (const cmd of commands) {
        const startedAt = Date.now();
        const label = cmd.type === "invoke_action" ? `${cmd.packageName}/${cmd.actionId}` : `${cmd.type} ${cmd.packageName}`;
        try {
          if (cmd.type === "start_app") {
            await session.miniapps.start(cmd.packageName);
            console.log(`\uD83D\uDCF1 started ${cmd.packageName}`);
            results.push({
              commandId: cmd.commandId,
              ok: true,
              result: { status: "started" },
              durationMs: Date.now() - startedAt
            });
          } else if (cmd.type === "stop_app") {
            await session.miniapps.stop(cmd.packageName);
            console.log(`\uD83D\uDCF1 stopped ${cmd.packageName}`);
            results.push({
              commandId: cmd.commandId,
              ok: true,
              result: { status: "stopped" },
              durationMs: Date.now() - startedAt
            });
          } else {
            const result = await session.actions.invoke(cmd.packageName, cmd.actionId, cmd.params, {
              timeoutMs: 30000
            });
            console.log(`\uD83D\uDCF1 invoked ${label}`);
            const semanticError = semanticActionError(result);
            results.push({
              commandId: cmd.commandId,
              ok: !semanticError,
              result: compactActionResult(result),
              ...semanticError ? { error: { message: semanticError } } : {},
              durationMs: Date.now() - startedAt
            });
          }
        } catch (err) {
          const message = safeActionErrorMessage(err instanceof Error ? err.message : String(err));
          console.warn(`\uD83D\uDCF1 device command failed (${label}):`, message);
          const code = err && typeof err === "object" && typeof err.code === "string" ? err.code : undefined;
          results.push({
            commandId: cmd.commandId,
            ok: false,
            error: { ...code ? { code } : {}, message },
            durationMs: Date.now() - startedAt
          });
        }
      }
      return results;
    }
    followUpPumpActive = false;
    startFollowUpPump(reason) {
      if (this.followUpPumpActive)
        return;
      this.followUpPumpActive = true;
      console.log(`\uD83E\uDD1D follow-up pump started (${reason})`);
      this.runFollowUpPump(reason).finally(() => {
        this.followUpPumpActive = false;
        console.log("\uD83E\uDD1D follow-up pump stopped");
      });
    }
    async runFollowUpPump(reason) {
      const { session } = this.deps;
      const PUMP_CAP_MS = 18 * 60 * 1000;
      const deadline = Date.now() + PUMP_CAP_MS;
      let waitSeconds = reason === "session-start" ? 0 : 20;
      let transportFailures = 0;
      while (Date.now() < deadline) {
        const page = await fetchFollowUps(session, waitSeconds);
        waitSeconds = 20;
        if (!page) {
          if (++transportFailures >= 3)
            return;
          await new Promise((r) => setTimeout(r, 5000));
          continue;
        }
        transportFailures = 0;
        for (const followUp of page.followUps) {
          const delivered = await this.deliverFollowUp(followUp);
          if (delivered)
            await ackFollowUp(session, followUp.id, this.deps.getSessionId());
        }
        if (page.followUps.length === 0 && page.working === 0)
          return;
      }
      console.warn("\uD83E\uDD1D follow-up pump hit its lifetime cap — stopping");
    }
    async deliverFollowUp(followUp) {
      const { session, emit } = this.deps;
      const HOLD_POLL_MS = 1000;
      const HOLD_CAP_MS = 120000;
      const holdDeadline = Date.now() + HOLD_CAP_MS;
      while (this.deps.isBusy() && Date.now() < holdDeadline) {
        await new Promise((r) => setTimeout(r, HOLD_POLL_MS));
      }
      const latest = await fetchFollowUps(session, 0);
      if (!latest) {
        console.log(`\uD83E\uDD1D deferring unverified follow-up ${followUp.id}`);
        return false;
      }
      if (!latest.followUps.some((candidate) => candidate.id === followUp.id)) {
        console.log(`\uD83E\uDD1D skipping superseded follow-up ${followUp.id}`);
        return false;
      }
      console.log(`\uD83E\uDD1D delivering follow-up (${followUp.reply.length} chars)`);
      const effectiveActions = effectiveReplyActions(followUp.reply, followUp.actions);
      const reply = stripActionUrls(followUp.reply, effectiveActions);
      const actions = toMessageActions(effectiveActions, followUp.reply);
      const connectedAccount = followUp.connectedToolkit ? accountNameFromToolkit(followUp.connectedToolkit) : connectedAccountFromReply(reply);
      if (connectedAccount) {
        for (const updated of this.deps.messages.completeOauthActions(connectedAccount, followUp.connectedToolkit)) {
          emit({ type: "message", ...updated });
        }
      }
      const aiMsg = this.deps.messages.addAssistantMessage(reply, undefined, actions);
      emit({ type: "message", ...aiMsg });
      const hasDisplay = Boolean(session.capabilities?.hasDisplay);
      const hasSpeakers = Boolean(session.capabilities?.hasSpeaker);
      this.outputResponse(reply, hasSpeakers, hasDisplay, aiMsg.id);
      return true;
    }
    getLocalTime() {
      const timezone = this.deps.location.getTimezone();
      const options = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true
      };
      try {
        if (timezone)
          options.timeZone = timezone;
        return new Date().toLocaleString("en-US", options);
      } catch {
        delete options.timeZone;
        return new Date().toLocaleString("en-US", options);
      }
    }
    outputResponse(response, hasSpeakers, hasDisplay, messageId) {
      if (hasDisplay) {
        this.deps.display.showResponse(response, messageId);
      }
      if (hasSpeakers) {
        const spoken = formatForTTS(response);
        console.log(`\uD83D\uDD0A speaking ${spoken.length} chars to glasses`);
        this.deps.audio.speak(spoken).catch((error) => console.debug("Speech output failed:", error));
      } else {
        console.log("\uD83D\uDD07 hasSpeaker=false — not speaking response");
      }
    }
  }

  // src/background/managers/StorageManager.ts
  var SETTINGS_KEY = "settings";

  class StorageManager {
    session;
    cache = { ...DEFAULT_SETTINGS };
    writes = Promise.resolve();
    constructor(session) {
      this.session = session;
    }
    async load() {
      try {
        const raw = await this.session.storage.get(SETTINGS_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          this.cache = { ...DEFAULT_SETTINGS, ...parsed, readingSpeed: readingSpeed(parsed.readingSpeed) };
        }
      } catch (error) {
        console.warn("Failed to load settings, using defaults:", error);
        this.cache = { ...DEFAULT_SETTINGS };
      }
      return this.cache;
    }
    get() {
      return { ...this.cache };
    }
    set(patch) {
      const write = this.writes.then(async () => {
        const next = { ...this.cache, ...patch, readingSpeed: readingSpeed(patch.readingSpeed ?? this.cache.readingSpeed) };
        await this.session.storage.set(SETTINGS_KEY, JSON.stringify(next));
        this.cache = next;
        return this.get();
      });
      this.writes = write.then(() => {}, () => {});
      return write;
    }
    async setTheme(theme) {
      await this.set({ theme });
    }
  }

  // src/background/managers/TranscriptionManager.ts
  var DEFAULT_TRANSCRIPTION_TIMING = {
    interimFallbackMs: 1e4,
    finalGraceMs: 2000,
    incompleteFinalGraceMs: 3500,
    listeningWatchdogMs: 30000
  };

  class TranscriptionManager {
    session;
    photo;
    audio;
    callbacks;
    timing;
    unsubscribe = null;
    isListening = false;
    isProcessing = false;
    activeSpeakerId = undefined;
    confirmedTranscript = "";
    currentUtteranceText = "";
    lastConfirmedUtteranceId = undefined;
    transcriptionStartTime = 0;
    manualCutWordCount = -1;
    currentUtteranceWordCount = 0;
    pendingPhoto = null;
    lastProcessedWords = [];
    lastProcessedTime = 0;
    DUPLICATE_WINDOW_MS = 1e4;
    DUPLICATE_WORD_COUNT = 3;
    silenceTimeout;
    maxListeningTimeout;
    lastArmedTranscript = "";
    destroyed = false;
    constructor(session, photo, audio, callbacks, timing = DEFAULT_TRANSCRIPTION_TIMING) {
      this.session = session;
      this.photo = photo;
      this.audio = audio;
      this.callbacks = callbacks;
      this.timing = timing;
    }
    setup() {
      this.destroyed = false;
      this.unsubscribe = this.session.transcription.on((data) => {
        this.handleTranscription(data);
      });
      console.log("\uD83C\uDFA4 TranscriptionManager ready");
    }
    get listening() {
      return this.isListening;
    }
    get processing() {
      return this.isProcessing;
    }
    destroy() {
      this.destroyed = true;
      this.clearTimers();
      this.unsubscribe?.();
      this.unsubscribe = null;
      this.resetState();
    }
    getFullTranscript() {
      const raw = (this.confirmedTranscript + " " + this.currentUtteranceText).trim();
      const cleaned = stripWakeWordResidue(removeWakeWord(raw));
      return cleaned ? cleaned.charAt(0).toUpperCase() + cleaned.slice(1) : cleaned;
    }
    async handleTranscription(data) {
      const { isFinal } = data;
      const speakerId = data.speakerId;
      console.log(`\uD83C\uDFA4 [TRANSCRIPT] ${isFinal ? "FINAL  " : "interim"} | "${data.text}"` + (speakerId ? ` (speaker: ${speakerId})` : ""));
      let text = data.text;
      const words = text.split(/\s+/).filter(Boolean);
      this.currentUtteranceWordCount = isFinal ? 0 : words.length;
      if (this.manualCutWordCount >= 0) {
        if (words.length <= this.manualCutWordCount) {
          this.manualCutWordCount = Math.min(this.manualCutWordCount, words.length);
          if (isFinal)
            this.manualCutWordCount = -1;
          return;
        }
        text = words.slice(this.manualCutWordCount).join(" ").replace(/^[,.\s-]+/, "").trim();
        if (isFinal)
          this.manualCutWordCount = -1;
      }
      this.callbacks.onTranscript?.(text, isFinal ?? false);
      if (this.isProcessing)
        return;
      const wakeResult = detectWakeWord(text);
      if (!this.isListening) {
        if (!wakeResult.detected)
          return;
        if (this.isDuplicateQuery(wakeResult.query)) {
          console.log(`⏱️ [WAKE] Ignoring duplicate wake word: "${text}"`);
          return;
        }
        console.log(`⏱️ [WAKE] Wake word detected: "${text}"`);
        this.callbacks.onWakeWord?.("voice");
        this.startListening(speakerId);
      }
      const cleanText = removeWakeWord(text);
      const utteranceId = data.utteranceId;
      if (isFinal) {
        if (utteranceId && utteranceId === this.lastConfirmedUtteranceId) {} else {
          this.confirmedTranscript = (this.confirmedTranscript + " " + cleanText).trim();
          this.lastConfirmedUtteranceId = utteranceId;
        }
        this.currentUtteranceText = "";
      } else {
        this.currentUtteranceText = cleanText;
      }
      const fullNow = this.getFullTranscript();
      const changed = fullNow !== this.lastArmedTranscript;
      if (isFinal) {
        this.lastArmedTranscript = fullNow;
        this.resetSilenceTimeout(this.looksIncomplete(fullNow) ? this.timing.incompleteFinalGraceMs : this.timing.finalGraceMs);
        this.resetListeningWatchdog();
      } else if (changed) {
        this.lastArmedTranscript = fullNow;
        this.resetSilenceTimeout(this.timing.interimFallbackMs);
        this.resetListeningWatchdog();
      }
      if (this.isListening) {
        this.callbacks.onListeningUpdate?.(this.getFullTranscript());
      }
    }
    startManualListening() {
      if (this.isProcessing)
        return;
      console.log("⏱️ [WAKE] Manual activation (no wake word)");
      this.callbacks.onWakeWord?.("manual");
      const cutWordCount = this.currentUtteranceWordCount;
      this.startListening();
      this.manualCutWordCount = cutWordCount;
      if (cutWordCount > 0) {
        console.log(`✂️ [WAKE] Tap mid-utterance — dropping first ${cutWordCount} pre-tap words`);
      }
    }
    cancelListening() {
      if (!this.isListening || this.isProcessing)
        return false;
      console.log("\uD83D\uDED1 [WAKE] Listening cancelled by user");
      this.resetState();
      return true;
    }
    submitNow() {
      if (!this.isListening || this.isProcessing)
        return false;
      if (this.getFullTranscript().length === 0)
        return false;
      console.log("⚡ [WAKE] Listening submitted by user (eager finalize)");
      this.clearTimers();
      this.processCurrentQuery();
      return true;
    }
    startListening(speakerId) {
      this.isListening = true;
      this.activeSpeakerId = speakerId;
      this.confirmedTranscript = "";
      this.currentUtteranceText = "";
      this.lastConfirmedUtteranceId = undefined;
      this.manualCutWordCount = -1;
      this.transcriptionStartTime = Date.now();
      const shouldCapture = Boolean(this.session.capabilities?.hasCamera) && (this.callbacks.shouldCapturePhotos?.() ?? true);
      this.pendingPhoto = shouldCapture ? this.photo.takePhoto().catch(() => null) : null;
      this.resetListeningWatchdog();
    }
    resetListeningWatchdog() {
      if (this.maxListeningTimeout)
        clearTimeout(this.maxListeningTimeout);
      this.maxListeningTimeout = setTimeout(() => {
        if (this.isListening && !this.isProcessing) {
          const query = this.getFullTranscript();
          console.log(`⏰ Listening watchdog reached (${this.timing.listeningWatchdogMs}ms without activity)`);
          if (query)
            this.processCurrentQuery();
          else
            this.resetState();
        }
      }, this.timing.listeningWatchdogMs);
    }
    static TRAILING_CONTINUATION_WORDS = new Set([
      "and",
      "or",
      "but",
      "so",
      "then",
      "plus",
      "also",
      "the",
      "a",
      "an",
      "my",
      "your",
      "our",
      "their",
      "his",
      "her",
      "to",
      "of",
      "for",
      "with",
      "at",
      "by",
      "into",
      "over",
      "under",
      "between",
      "near",
      "versus",
      "vs",
      "is",
      "are",
      "was",
      "were",
      "be",
      "being",
      "um",
      "uh",
      "uhh",
      "umm",
      "er",
      "ah",
      "hmm",
      "what",
      "whats",
      "how",
      "hows",
      "why",
      "when",
      "where",
      "who",
      "can",
      "could",
      "should",
      "would",
      "will",
      "does",
      "did",
      "i",
      "im",
      "very",
      "really",
      "more",
      "less",
      "most",
      "least",
      "some",
      "any",
      "best",
      "worst",
      "top",
      "favorite",
      "many"
    ]);
    looksIncomplete(transcript) {
      const trimmed = transcript.trim();
      if (!trimmed)
        return false;
      if (/[?!]$/.test(trimmed))
        return false;
      if (/[,\-–—:;]$/.test(trimmed))
        return true;
      const lastWord = trimmed.split(/\s+/).pop().toLowerCase().replace(/[^a-z']/g, "").replace(/'/g, "");
      return TranscriptionManager.TRAILING_CONTINUATION_WORDS.has(lastWord);
    }
    resetSilenceTimeout(ms) {
      if (this.silenceTimeout) {
        clearTimeout(this.silenceTimeout);
        console.log(`⏹️ silence timer STOPPED (re-arming)`);
      }
      console.log(`▶️ silence timer STARTED (${ms}ms)`);
      this.silenceTimeout = setTimeout(() => {
        console.log(`⏰ silence timer FIRED (${ms}ms elapsed) → finalizing query`);
        if (this.isListening && !this.isProcessing && this.getFullTranscript().length > 0) {
          this.processCurrentQuery();
        }
      }, ms);
    }
    async processCurrentQuery() {
      if (this.isProcessing)
        return;
      const query = this.getFullTranscript();
      if (!query) {
        this.resetState();
        return;
      }
      this.isProcessing = true;
      this.clearTimers();
      this.lastProcessedWords = this.extractWords(query);
      this.lastProcessedTime = Date.now();
      console.log(`⏱️ [SILENCE] Query ready: "${query}" (${Date.now() - this.transcriptionStartTime}ms since wake)`);
      const hasCamera = Boolean(this.session.capabilities?.hasCamera) && (this.callbacks.shouldCapturePhotos?.() ?? true);
      const photoPromise = this.pendingPhoto ?? (hasCamera ? this.photo.takePhoto().catch(() => null) : null);
      this.pendingPhoto = null;
      if (this.destroyed) {
        console.log("\uD83D\uDED1 Session destroyed before query handoff, aborting");
        return;
      }
      try {
        await this.callbacks.onQueryReady(query, this.activeSpeakerId, photoPromise);
      } catch (error) {
        console.error("Error processing query:", error);
      } finally {
        this.resetState();
      }
    }
    resetState() {
      this.isListening = false;
      this.isProcessing = false;
      this.activeSpeakerId = undefined;
      this.confirmedTranscript = "";
      this.currentUtteranceText = "";
      this.lastConfirmedUtteranceId = undefined;
      this.transcriptionStartTime = 0;
      this.lastArmedTranscript = "";
      this.manualCutWordCount = -1;
      this.pendingPhoto = null;
      this.clearTimers();
    }
    clearTimers() {
      if (this.silenceTimeout) {
        clearTimeout(this.silenceTimeout);
        this.silenceTimeout = undefined;
        console.log(`\uD83D\uDED1 silence timer CLEARED`);
      }
      if (this.maxListeningTimeout) {
        clearTimeout(this.maxListeningTimeout);
        this.maxListeningTimeout = undefined;
      }
    }
    extractWords(query) {
      return query.toLowerCase().replace(/[^\w\s]/g, "").split(/\s+/).filter((w) => w.length > 0).slice(0, this.DUPLICATE_WORD_COUNT);
    }
    isDuplicateQuery(query) {
      if (this.lastProcessedWords.length === 0)
        return false;
      if (Date.now() - this.lastProcessedTime > this.DUPLICATE_WINDOW_MS)
        return false;
      const incomingWords = this.extractWords(query);
      if (incomingWords.length === 0)
        return false;
      const wordsToCompare = Math.min(incomingWords.length, this.lastProcessedWords.length);
      for (let i = 0;i < wordsToCompare; i++) {
        if (incomingWords[i] !== this.lastProcessedWords[i])
          return false;
      }
      return true;
    }
  }

  // src/background/MentraAIController.ts
  class MentraAIController {
    session;
    ui;
    audio;
    display;
    location;
    notifications;
    photo;
    storage;
    messages;
    miniapps;
    transcription;
    query;
    unsubs = [];
    started = false;
    cloudSettings = { ...DEFAULT_CLOUD_SETTINGS };
    sessionId = `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    constructor(session) {
      this.session = session;
      this.ui = session.ui;
      this.audio = new AudioManager(session);
      this.display = new DisplayManager2(session, (state) => this.ui.send("reader:update", state));
      this.location = new LocationManager(session);
      this.notifications = new NotificationManager;
      this.photo = new PhotoManager(session);
      this.storage = new StorageManager(session);
      this.messages = new MessageStore;
      this.miniapps = new MiniappsManager(session);
      this.query = new QueryProcessor({
        session,
        audio: this.audio,
        display: this.display,
        location: this.location,
        notifications: this.notifications,
        photo: this.photo,
        messages: this.messages,
        getModel: () => this.storage.get().model,
        getIncludePhotosWithQueries: () => this.cloudSettings.includePhotosWithQueries,
        getSessionId: () => this.sessionId,
        getMiniappCatalog: () => this.miniapps.getCatalog(),
        isBusy: () => this.transcription.listening || this.transcription.processing || this.query.isProcessing,
        emit: (event) => this.emit(event)
      });
      this.transcription = new TranscriptionManager(session, this.photo, this.audio, {
        shouldCapturePhotos: () => this.cloudSettings.includePhotosWithQueries,
        onQueryReady: async (q, speakerId, prePhoto) => {
          await this.query.processQuery(q, speakerId, prePhoto);
        },
        onWakeWord: (source) => {
          this.query.cancelOutput();
          this.display.clear();
          this.emit({ type: "wake_word", source });
          this.audio.playStartSound();
          if (this.cloudSettings.gigaAgentEnabled)
            wakeGigaAgent(this.session);
          this.miniapps.refreshIfStale();
        },
        onListeningUpdate: (full) => this.display.showStatus(`Listening...

${full}`, 5000),
        onTranscript: (text, isFinal) => this.ui.send("debug:transcript", { text, isFinal })
      });
    }
    async start() {
      if (this.started)
        return;
      this.started = true;
      const caps = this.session.capabilities;
      console.log(`\uD83D\uDD76️ Connected glasses: ${caps?.modelName ?? "none"}`, {
        modelName: caps?.modelName ?? null,
        hasDisplay: Boolean(caps?.hasDisplay),
        hasCamera: Boolean(caps?.hasCamera),
        hasSpeaker: Boolean(caps?.hasSpeaker)
      });
      const settings = await this.storage.load();
      this.messages.setChatHistoryEnabled(settings.chatHistoryEnabled);
      this.display.reader.setSpeed(settings.readingSpeed);
      const cloud = await fetchCloudSettings(this.session);
      if (cloud) {
        this.cloudSettings = cloud;
        if (cloud.gigaAgentEnabled || cloud.composioEnabled)
          this.query.startFollowUpPump("session-start");
      }
      this.miniapps.refreshIfStale();
      this.transcription.setup();
      this.wireRpcHandlers();
      this.wireUILifecycle();
      this.display.showWelcome();
      this.session.onBeforeDisconnect(() => this.dispose());
    }
    wireNotifications() {}
    wireRpcHandlers() {
      this.ui.handle("chat:get-history", () => this.messages.list());
      this.ui.handle("chat:clear", () => {
        this.query.cancelOutput();
        this.display.clear();
        this.messages.clear();
        this.emit({ type: "history", messages: [] });
      });
      this.ui.handle("chat:ask", async ({ query }) => {
        const trimmed = query.trim();
        if (!trimmed)
          return;
        await this.query.processQuery(trimmed);
      });
      this.ui.handle("chat:start-listening", () => {
        this.transcription.startManualListening();
      });
      this.ui.handle("chat:cancel-listening", () => {
        if (this.transcription.cancelListening()) {
          this.emit({ type: "idle" });
        }
      });
      this.ui.handle("chat:submit-listening", () => {
        this.transcription.submitNow();
      });
      this.ui.handle("chat:open-url", ({ url }) => {
        this.session.system.openUrl(url);
      });
      this.ui.handle("chat:rate", ({ messageId, rating }) => {
        this.messages.setRating(messageId, rating);
      });
      this.ui.handle("reader:get", () => this.display.reader.getState());
      this.ui.handle("reader:control", ({ action }) => {
        if (!this.transcription.listening && !this.transcription.processing && !this.query.isProcessing)
          this.display.reader.control(action);
        return this.display.reader.getState();
      });
      this.ui.handle("reader:read", ({ messageId }) => {
        if (this.transcription.listening || this.transcription.processing || this.query.isProcessing)
          return;
        const message = this.messages.list().find((entry) => entry.id === messageId && entry.role === "assistant");
        if (message)
          this.display.showResponse(message.content, message.id);
      });
      this.ui.handle("settings:get", () => this.storage.get());
      this.ui.handle("device:get-capabilities", () => ({
        hasDisplay: Boolean(this.session.capabilities?.hasDisplay),
        hasAutomaticPaging: Boolean(this.session.capabilities?.hasDisplay) && !supportsPagingInput(this.session.capabilities),
        hasCamera: Boolean(this.session.capabilities?.hasCamera)
      }));
      this.ui.handle("settings:cloud-get", () => {
        fetchCloudSettings(this.session).then((cloud) => {
          if (cloud)
            this.cloudSettings = cloud;
        });
        return this.cloudSettings;
      });
      this.ui.handle("settings:cloud-set", async (patch) => {
        const merged = await updateCloudSettings(this.session, patch);
        const gigaJustEnabled = merged.gigaAgentEnabled && !this.cloudSettings.gigaAgentEnabled;
        const composioJustEnabled = merged.composioEnabled && !this.cloudSettings.composioEnabled;
        this.cloudSettings = merged;
        if (gigaJustEnabled || composioJustEnabled)
          this.query.startFollowUpPump("session-start");
        return merged;
      });
      this.ui.handle("settings:set", async (patch) => {
        const merged = await this.storage.set(patch);
        if (patch.chatHistoryEnabled !== undefined) {
          this.messages.setChatHistoryEnabled(merged.chatHistoryEnabled);
        }
        this.display.reader.setSpeed(merged.readingSpeed);
        this.ui.send("settings:update", merged);
        return merged;
      });
      this.ui.handle("settings:set-theme", async (theme) => {
        const merged = await this.storage.set({ theme });
        this.ui.send("settings:update", merged);
      });
      this.ui.handle("debug:speak", async ({ text }) => {
        const caps = this.session.capabilities;
        const capabilities = {
          modelName: caps?.modelName,
          hasSpeaker: Boolean(caps?.hasSpeaker),
          hasDisplay: Boolean(caps?.hasDisplay),
          hasCamera: Boolean(caps?.hasCamera)
        };
        if (!capabilities.hasSpeaker) {
          return { accepted: false, completed: null, capabilities, error: "Glasses report no speaker" };
        }
        try {
          const result = await this.session.speaker.speak(text, { stopOtherAudio: true });
          return { accepted: true, completed: result?.completed ?? null, capabilities };
        } catch (error) {
          return {
            accepted: false,
            completed: null,
            capabilities,
            error: error instanceof Error ? error.message : String(error)
          };
        }
      });
      this.ui.handle("debug:spinner", ({ action }) => {
        if (!this.session.capabilities?.hasDisplay) {
          return { running: false, error: "Glasses report no display" };
        }
        if (action === "start") {
          return { running: this.display.startSpinner() };
        }
        this.display.stopSpinner();
        return { running: false };
      });
    }
    wireUILifecycle() {
      this.unsubs.push(this.ui.onOpen(() => {
        this.ui.send("reader:update", this.display.reader.getState());
        this.emit({
          type: "history",
          messages: this.messages.list(),
          truncatedBeforeSeq: this.messages.getTruncatedBeforeSeq()
        });
      }));
    }
    emit(event) {
      this.ui.send("chat:event", event);
    }
    dispose() {
      this.query.cancelOutput();
      this.display.destroy();
      this.transcription.destroy();
      this.photo.destroy();
      this.location.destroy();
      this.notifications.destroy();
      this.messages.destroy();
      for (const unsub of this.unsubs) {
        try {
          unsub();
        } catch {}
      }
      this.unsubs = [];
    }
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    new MentraAIController(session).start();
  });
})();
